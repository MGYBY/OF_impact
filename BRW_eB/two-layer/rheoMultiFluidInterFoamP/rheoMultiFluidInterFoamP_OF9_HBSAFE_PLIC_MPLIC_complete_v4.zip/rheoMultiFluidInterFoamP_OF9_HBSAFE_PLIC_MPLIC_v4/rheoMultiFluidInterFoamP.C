/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2021 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

Application
    rheoMultiFluidInterFoamP

Description
    OpenFOAM Foundation 9 physical-pressure port of
    rheoMultiFluidInterFoamP for n incompressible immiscible phases.

    The solver advances mechanical pressure p and represents gravity as
    +rho*g.  Ordinary translational cyclic pressure boundaries can therefore
    be used in a bed-aligned periodic domain with a streamwise gravity
    component.

    Each phase is assigned a RheoTool OF90 constitutive equation.  The VOF
    and moving-mesh framework is rebased on OpenFOAM-9
    multiphaseInterFoam.  This application is intentionally laminar: the
    complete stress is supplied by the phase constitutive equations.

\*---------------------------------------------------------------------------*/

#include "sparseMatrixSolvers.H"

#include "fvCFD.H"
#include "dynamicFvMesh.H"
#include "multiphaseMixture.H"
#include "pimpleControl.H"
#include "pressureReference.H"
#include "fvModels.H"
#include "fvConstraints.H"
#include "CorrectPhi.H"

int main(int argc, char *argv[])
{
    #include "postProcess.H"

    #include "setRootCaseLists.H"
    #include "createTime.H"
    #include "createDynamicFvMesh.H"
    #include "initContinuityErrs.H"
    #include "createDyMControls.H"
    #include "createFields.H"
    #include "createSolver.H"
    #include "initCorrectPhi.H"
    #include "createUfIfPresent.H"

    #include "CourantNo.H"
    #include "setInitialDeltaT.H"

    const surfaceScalarField& rhoPhi(mixture.rhoPhi());

    Info<< "\nUsing physical pressure p and explicit gravity +rho*g."
        << "\nStarting time loop\n" << endl;

    while (pimple.run(runTime))
    {
        #include "readDyMControls.H"
        #include "CourantNo.H"
        #include "alphaCourantNo.H"
        #include "setDeltaT.H"

        runTime++;

        Info<< "Time = " << runTime.timeName() << nl << endl;

        while (pimple.loop())
        {
            if (pimple.firstPimpleIter() || moveMeshOuterCorrectors)
            {
                const scalar timeBeforeMeshUpdate = runTime.elapsedCpuTime();

                fvModels.preUpdateMesh();
                mesh.update();

                if (mesh.changing())
                {
                    Info<< "Execution time for mesh.update() = "
                        << runTime.elapsedCpuTime() - timeBeforeMeshUpdate
                        << " s" << endl;

                    MRF.update();

                    if (correctPhi)
                    {
                        #include "correctPhi.H"
                    }

                    if (checkMeshCourantNo)
                    {
                        #include "meshCourantNo.H"
                    }
                }
            }

            fvModels.correct();

            // Phase fractions are transported and all RheoTool phase
            // constitutive equations are corrected inside mixture.solve().
            mixture.solve();
            rho = mixture.rho();

            #include "UEqn.H"

            while (pimple.correct())
            {
                #include "pEqn.H"
            }
        }

        runTime.write();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
    }

    Info<< "End\n" << endl;
    return 0;
}

// ************************************************************************* //
