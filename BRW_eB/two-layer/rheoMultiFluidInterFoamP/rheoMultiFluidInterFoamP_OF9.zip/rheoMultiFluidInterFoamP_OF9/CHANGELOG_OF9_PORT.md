# OpenFOAM 9 port changelog

## Compatibility/API

- rebased loop and field infrastructure on Foundation OpenFOAM 9;
- migrated `fvOptions` to `fvModels` and `fvConstraints`;
- adopted `pressureReference`;
- adopted OF9 `MULES::limitSum`;
- adopted OF9 `regIOobject::read()` path;
- updated Make include paths and libraries;
- added build-time Foundation-9 environment guard.

## Pressure/cyclic formulation

- retained solved physical pressure `p`;
- retained explicit `+rho*g` body force;
- removed all active `p_rgh`, `gh`, `ghf` and `hRef` paths;
- ported initial and moving-mesh flux correction to physical `p`;
- supplied ordinary cyclic `p` patches in the regression tutorial.

## Rheology

- replaced the customized OF70 constitutive dependency by official OF90;
- one OF90 constitutive equation per phase;
- phase alpha passed to the OF90 correction method;
- GNF `tau()` double-count protection;
- excluded the bundled/customized OF7 Herschel-Bulkley source file.

## Interface treatment

- retained phase-specific surface-tension decomposition;
- retained VOF smoothing only in curvature evaluation;
- retained raw-alpha phase-normal artificial compression;
- retained SIMPLEC;
- added runtime validation of `sigma_ij = Sigma_i + Sigma_j`;
- changed the tutorial upper boundary from a wall to an atmospheric open patch.
