`constant` folder
