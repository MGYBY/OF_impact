#!/usr/bin/env python3
"""Independent scalar checks for the OF9 HerschelBulkleySafe closure.

This script mirrors only the scalar constitutive law.  It does not use
OpenFOAM and therefore cannot replace compilation or CFD validation.
"""

from __future__ import annotations

import math
from dataclasses import dataclass


TINY = 1.0e-300


@dataclass(frozen=True)
class HB:
    eta0: float
    tau0: float
    k: float
    n: float
    regularized: bool = False
    m: float = 1.0

    def validate(self) -> None:
        if not self.eta0 > 0.0:
            raise ValueError("eta0 must be positive")
        if self.tau0 < 0.0 or self.k < 0.0:
            raise ValueError("tau0 and k must be non-negative")
        if not self.n > 0.0:
            raise ValueError("n must be positive")
        if self.regularized and not self.m > 0.0:
            raise ValueError("m must be positive when regularized")
        if self.tau0 == 0.0 and self.k == 0.0:
            raise ValueError("tau0 and k cannot both be zero")

    def eta(self, gamma_dot: float) -> float:
        self.validate()
        gamma = max(float(gamma_dot), TINY)
        eta = 0.0

        if self.k > 0.0:
            log_term = math.log(self.k) + (self.n - 1.0) * math.log(gamma)
            if log_term >= math.log(self.eta0):
                return self.eta0
            eta += math.exp(log_term)

        if self.tau0 > 0.0:
            if self.regularized:
                eta_y = self.tau0 * (-math.expm1(-self.m * gamma)) / gamma
            else:
                eta_y = self.tau0 / gamma
            eta += eta_y

        return min(self.eta0, max(0.0, eta))


def close(actual: float, expected: float, rtol: float = 5.0e-13) -> None:
    scale = max(1.0, abs(expected))
    if abs(actual - expected) > rtol * scale:
        raise AssertionError(f"actual={actual:.17g}, expected={expected:.17g}")


def main() -> None:
    results: list[tuple[str, float, float]] = []

    pure_pl = HB(eta0=25.0, tau0=0.0, k=1.38, n=0.2)
    actual = pure_pl.eta(1.0e-300)
    expected = 25.0
    close(actual, expected)
    results.append(("pure power law at vanishing shear -> eta0", actual, expected))

    actual = pure_pl.eta(10.0)
    expected = 1.38 * 10.0 ** (-0.8)
    close(actual, expected)
    results.append(("pure power law at gamma=10", actual, expected))

    newtonian = HB(eta0=1.0, tau0=0.0, k=0.001, n=1.0)
    actual = newtonian.eta(0.0)
    expected = 0.001
    close(actual, expected)
    results.append(("Newtonian limit", actual, expected))

    bingham = HB(eta0=100.0, tau0=15.0, k=2.0, n=1.0)
    actual = bingham.eta(2.0)
    expected = 2.0 + 15.0 / 2.0
    close(actual, expected)
    results.append(("bounded unregularized Bingham", actual, expected))

    regularized = HB(
        eta0=1000.0,
        tau0=15.0,
        k=2.0,
        n=1.0,
        regularized=True,
        m=50.0,
    )
    actual = regularized.eta(1.0e-20)
    expected = 2.0 + 15.0 * 50.0
    close(actual, expected, rtol=2.0e-12)
    results.append(("Papanastasiou zero-shear limit", actual, expected))

    x = 1.0e-20
    naive = 1.0 - math.exp(-x)
    safe = -math.expm1(-x)
    if naive != 0.0 or not safe > 0.0:
        raise AssertionError("expected the cancellation demonstration to distinguish formulas")

    print("HerschelBulkleySafe independent scalar reference")
    print("formula: eta=min(eta0, k*gamma^(n-1) + yield contribution)")
    print()
    for name, actual, expected in results:
        print(f"PASS  {name}")
        print(f"      actual   = {actual:.16e}")
        print(f"      expected = {expected:.16e}")
    print()
    print("PASS  cancellation-safe Papanastasiou numerator")
    print(f"      naive 1-exp(-1e-20) = {naive:.16e}")
    print(f"      -expm1(-1e-20)      = {safe:.16e}")
    print(f"checks: {len(results) + 1} passed, 0 failed")


if __name__ == "__main__":
    main()
