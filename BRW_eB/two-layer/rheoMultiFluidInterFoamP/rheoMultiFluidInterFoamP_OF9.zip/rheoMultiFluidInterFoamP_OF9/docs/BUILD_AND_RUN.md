# Build and run guide

## Prerequisites

- Ubuntu/Linux environment with OpenFOAM Foundation 9 compiled or installed;
- official RheoTool OF90 compiled successfully in that same OF9 environment;
- Eigen, PETSc and HYPRE settings used by the RheoTool build;
- a working baseline `rheoInterFoam` executable is strongly recommended.

Do not build this port while an OpenFOAM 7, OpenFOAM.com or another Foundation
version is sourced.

## 1. Source the environment

```bash
source /path/to/OpenFOAM-9/etc/bashrc
foamVersion
printf '%s\n' "$WM_PROJECT_VERSION"     # must be 9
```

Source or export the variables from your working RheoTool environment:

```bash
export RHEOTOOL_SRC=/path/to/rheoTool/of90/src/libs
export EIGEN_RHEO=/path/to/Eigen
export PETSC_DIR=/path/to/petsc
export PETSC_ARCH=<arch-name>
```

If your RheoTool installation created the traditional source link

```text
$FOAM_USER_SRC/libs/libRheoTool
```

then `RHEOTOOL_SRC` may be omitted.

## 2. Check the environment

```bash
./tools/check_environment.sh
```

Resolve every missing header, library and command before compilation.

## 3. Compile

```bash
./Allwclean
./Allwmake 2>&1 | tee log.Allwmake
```

Expected products:

```text
$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so
$FOAM_USER_APPBIN/rheoMultiFluidInterFoamP
```

Check:

```bash
command -v rheoMultiFluidInterFoamP
ldd "$(command -v rheoMultiFluidInterFoamP)" | tee log.ldd
! grep -q 'not found' log.ldd
```

## 4. Run the static audit

```bash
python3 tools/static_audit.py
```

This must report zero failures.

## 5. Run the supplied tutorial

```bash
cd tutorials/periodicSteadyUniformPowerLaw
./Allrun
```

The script restores `0/`, runs `blockMesh`, `setFields`, `checkMesh`, and then
the solver.

## Dictionary structure

Each phase still needs two layers of rheological information:

```foam
mud
{
    // Base OpenFOAM viscosity object retained for transport API compatibility
    transportModel Newtonian;
    nu  [0 2 -1 0 0 0 0] ...;
    rho [1 -3 0 0 0 0 0] ...;

    // Active RheoTool OF90 constitutive equation
    parameters
    {
        type HerschelBulkley;
        rho  rho  [1 -3 0 0 0 0 0] ...;
        eta0 eta0 [1 -1 -1 0 0 0 0] ...;
        tau0 tau0 [1 -1 -2 0 0 0 0] ...;
        k    k    [1 -1 -1 0 0 0 0] ...;
        n    n    [0 0 0 0 0 0 0] ...;
        PapanastasiouRegularization true;
        m    m    [0 0 1 0 0 0 0] ...;
    }
}
```

For the unregularized model, `m` is not read.

## Surface-tension dictionary

The port retains both the physical pairwise values and the decomposed values:

```foam
sigmas
(
    (mud air) 0.07
);

sigmasPh
(
    (mud mud) 0.035
    (air air) 0.035
);
```

At startup the solver checks

```text
sigma_mud-air = Sigma_mud + Sigma_air
```

for every pair.  The check can be disabled explicitly with
`checkSigmaDecomposition false`, but that is not recommended.

## Frequent failures

### `constitutiveEq.H: No such file or directory`

Set `RHEOTOOL_SRC` to the **`of90/src/libs`** directory, not the repository
root.

### `libHYPRE...so: cannot open shared object file`

Source the same PETSc/HYPRE environment used for RheoTool and ensure its
library directory is in `LD_LIBRARY_PATH`.

### `undefined reference` to RheoTool classes

Confirm that OF90—not OF70—libraries are in `$FOAM_USER_LIBBIN`, clean the
solver, and rebuild.

### Case searches for `p_rgh`

The case is still using an old field or function object.  Replace the primary
pressure field by dynamic `p` and update `fvSolution`, `fvSchemes`, sampling and
post-processing entries.

### `Inconsistent surface-tension decomposition`

Correct `sigmasPh`; do not simply duplicate the pairwise value for both phases.
