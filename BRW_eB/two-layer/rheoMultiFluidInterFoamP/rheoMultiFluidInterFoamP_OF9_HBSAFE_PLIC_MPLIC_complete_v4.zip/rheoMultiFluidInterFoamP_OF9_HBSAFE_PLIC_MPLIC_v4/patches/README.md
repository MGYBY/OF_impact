# Source comparison patches

These are review aids.  Build the complete source tree rather than attempting
to assemble the solver from individual patches.

- `PLIC_MPLIC_V3_TO_HBSAFE_V4.patch`: focused complete diff from the previous
  PLIC/MPLIC v3 package to this HBSAFE v4 package.
- `PLIC_MPLIC_COMPATIBILITY.patch`: earlier focused patch that introduced the
  OF9 geometric-VOF compatibility layer.
- `OF9_V2_TO_PLIC_MPLIC_V3_FULL.diff`: earlier v2-to-v3 review diff.
- `FROM_UPLOADED_OF7_P_SOURCE.diff`: high-level provenance comparison against
  the uploaded OF7 physical-pressure solver.
- `AGAINST_OF9_MULTIPHASEINTERFOAM_SOURCE.diff`: comparison against stock OF9
  `multiphaseInterFoam`.

Directory layouts differ across releases, so older provenance diffs are not
expected to apply with one generic `patch -pN` command.
