# `HerschelBulkleySafe` for RheoTool OF90

## Purpose

`HerschelBulkleySafe` is a package-local, runtime-selectable generalized-
Newtonian constitutive equation for the OpenFOAM Foundation 9 version of
`rheoMultiFluidInterFoamP`.

It is compiled into:

```text
$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so
```

It does **not** replace or patch the installed RheoTool OF90
`HerschelBulkley` class.  The standard and safe models may coexist:

```foam
type HerschelBulkley;
```

or:

```foam
type HerschelBulkleySafe;
```

The official OF90 model already avoids the historical OF7 `+1e-8`
denominator error in the unregularized branch.  The package-local model adds:

- cancellation-safe Papanastasiou evaluation using `std::expm1`;
- overflow-safe power-law evaluation before applying the viscosity cap;
- explicit dimensions and parameter-range checks;
- the correct finite regularized limit at vanishing strain rate;
- optional strain-rate, total-stress and stress-invariant output fields; and
- the same model name and user-facing behavior in the revised OF7 and OF9
  packages.

## Constitutive equations

Let

```text
gammaDot = sqrt(2 D:D)
D        = 0.5*(grad(U) + grad(U)^T)
```

using RheoTool's invariant convention.

Without Papanastasiou regularization, the dynamic apparent viscosity is

```text
eta = min(eta0, K*gammaDot^(n-1) + tau0/gammaDot).
```

With Papanastasiou regularization,

```text
eta = min
      (
          eta0,
          K*gammaDot^(n-1)
        + tau0*(-expm1(-m*gammaDot))/gammaDot
      ).
```

The safe numerator

```cpp
-std::expm1(-m*gammaDot)
```

is mathematically equal to `1-exp(-m*gammaDot)` but remains accurate when
`m*gammaDot` is extremely small.

The important limiting cases are:

```text
tau0 = 0, 0 < n < 1       pure shear-thinning power law
n = 1, tau0 > 0            bounded Bingham model
tau0 = 0, n = 1            Newtonian limit
```

For regularized Bingham flow (`n=1`),

```text
eta(gammaDot -> 0) = min(eta0, K + tau0*m).
```

For an unregularized shear-thinning power law,

```text
eta(gammaDot -> 0) = eta0.
```

## RheoTool OF90 stress semantics

The class returns:

```cpp
isGNF() == true
```

and exposes its dynamic viscosity through the protected `eta()` interface.
RheoTool OF90's phase-weighted `divTauS(U, alpha)` therefore supplies the
complete generalized-Newtonian stress divergence.

The custom mixture must retain the following rule:

```cpp
divTau += phase.divTauS(U, boundedAlpha);

if (!phase.isGNF())
{
    tauMF += boundedAlpha*phase.tau();
}
```

Do not add `tau()` for `HerschelBulkleySafe`; doing so would count the same
physical stress twice.

## Build

Source OpenFOAM 9 and the same official RheoTool OF90 environment used by a
working `rheoInterFoam` build:

```bash
source /opt/openfoam9/etc/bashrc

export RHEOTOOL_SRC=/path/to/rheoTool/of90/src/libs
export EIGEN_RHEO=/path/to/Eigen
export PETSC_DIR=/path/to/petsc
export PETSC_ARCH=arch-linux-c-opt
```

Check the OF90 API before compilation:

```bash
./tools/check_environment.sh
./tools/check_rheotool_api.sh
```

Then build:

```bash
./Allwclean
./Allwmake 2>&1 | tee log.Allwmake
```

Confirm that the runtime class is present:

```bash
nm -D -C \
    "$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so" \
  | grep HerschelBulkleySafe
```

Confirm the executable links to the expected custom and RheoTool libraries:

```bash
solver=$(command -v rheoMultiFluidInterFoamP)
ldd "$solver" | tee log.ldd
! grep -q 'not found' log.ldd
```

## General dictionary rule

The outer OpenFOAM phase viscosity is retained as a compatibility object.  The
actual active rheology is selected in `parameters/type`:

```foam
mud
{
    transportModel Newtonian;
    nu              [0 2 -1 0 0 0 0] 0.0208333333333;
    rho             [1 -3 0 0 0 0 0] 1200;

    parameters
    {
        type        HerschelBulkleySafe;

        rho         rho  [1 -3 0 0 0 0 0] 1200;
        eta0        eta0 [1 -1 -1 0 0 0 0] 25;
        tau0        tau0 [1 -1 -2 0 0 0 0] 0;
        k           k    [1 -1 -1 0 0 0 0] 1.38;
        n           n    [0 0 0 0 0 0 0] 0.2;

        PapanastasiouRegularization false;

        writeShearRate              true;
        writeStress                 true;
        writeSecondInvariantTauDev  true;
    }
}
```

The two `rho` entries must agree.  The dimensions follow the official OF90
convention: `k` is entered with dynamic-viscosity dimensions, and RheoTool
supplies unit-time factors internally when `n != 1`.

## Pure power-law example

```foam
mud
{
    transportModel Newtonian;
    nu              [0 2 -1 0 0 0 0] 0.0207986688852;
    rho             [1 -3 0 0 0 0 0] 1202;

    parameters
    {
        type        HerschelBulkleySafe;

        rho         rho  [1 -3 0 0 0 0 0] 1202;
        eta0        eta0 [1 -1 -1 0 0 0 0] 25.0;
        tau0        tau0 [1 -1 -2 0 0 0 0] 0.0;
        k           k    [1 -1 -1 0 0 0 0] 1.380;
        n           n    [0 0 0 0 0 0 0] 0.20;

        PapanastasiouRegularization false;

        writeShearRate              true;
        writeStress                 true;
        writeSecondInvariantTauDev  true;
    }
}
```

This is the default rheology in both periodic normal-flow tutorials.

## Bounded, unregularized Bingham example

```foam
mud
{
    transportModel Newtonian;
    nu              [0 2 -1 0 0 0 0] 0.0833333333333;
    rho             [1 -3 0 0 0 0 0] 1200;

    parameters
    {
        type        HerschelBulkleySafe;

        rho         rho  [1 -3 0 0 0 0 0] 1200;
        eta0        eta0 [1 -1 -1 0 0 0 0] 100;
        tau0        tau0 [1 -1 -2 0 0 0 0] 15;
        k           k    [1 -1 -1 0 0 0 0] 2;
        n           n    [0 0 0 0 0 0 0] 1;

        PapanastasiouRegularization false;
    }
}
```

The model evaluates:

```text
eta = min(eta0, K + tau0/gammaDot).
```

## Papanastasiou-regularized Herschel--Bulkley example

```foam
mud
{
    transportModel Newtonian;
    nu              [0 2 -1 0 0 0 0] 0.0833333333333;
    rho             [1 -3 0 0 0 0 0] 1200;

    parameters
    {
        type        HerschelBulkleySafe;

        rho         rho  [1 -3 0 0 0 0 0] 1200;
        eta0        eta0 [1 -1 -1 0 0 0 0] 100;
        tau0        tau0 [1 -1 -2 0 0 0 0] 15;
        k           k    [1 -1 -1 0 0 0 0] 2;
        n           n    [0 0 0 0 0 0 0] 0.6;

        PapanastasiouRegularization true;
        m           m    [0 0 1 0 0 0 0] 50;

        writeShearRate              true;
        writeStress                 true;
        writeSecondInvariantTauDev  true;
    }
}
```

The illustrative value `m=50 s` is not universal.  Increase `m` in a
sensitivity study; a sharper regularization is normally more numerically
stiff.

## Newtonian limit

```foam
parameters
{
    type        HerschelBulkleySafe;

    rho         rho  [1 -3 0 0 0 0 0] 1000;
    eta0        eta0 [1 -1 -1 0 0 0 0] 0.001;
    tau0        tau0 [1 -1 -2 0 0 0 0] 0;
    k           k    [1 -1 -1 0 0 0 0] 0.001;
    n           n    [0 0 0 0 0 0 0] 1;

    PapanastasiouRegularization false;
}
```

For an ordinary Newtonian phase, the official RheoTool `Newtonian` class is
simpler and should normally be preferred.

## Parameter checks

The class rejects:

- non-positive `rho` or `eta0`;
- negative `tau0` or `k`;
- non-positive `n`;
- a non-positive or dimensionally incorrect `m` when regularization is active;
- `tau0=0` and `k=0` simultaneously; and
- incorrect dimensions for the main material coefficients.

## Output fields

For a phase named `mud`, the class can write:

```text
eta.mud
 gammaDot.mud
 tauTotal.mud
 IItauD.mud
```

The actual names are formed as `eta + phaseName`, etc.; with the phase naming
used in this solver this normally appears with a dot separator.

- `eta.mud`: dynamic apparent viscosity, Pa s; always `AUTO_WRITE`.
- `gammaDot.mud`: strain-rate invariant, 1/s.
- `tauTotal.mud`: complete deviatoric generalized-Newtonian stress, Pa.
- `IItauD.mud`: `|dev(tauTotal)|/sqrt(2)`, Pa.

The transported API field `tau.mud` remains zero and is not written because a
GNF has no separately transported polymeric stress.

Disable optional diagnostics to reduce output:

```foam
writeShearRate              false;
writeStress                 false;
writeSecondInvariantTauDev  false;
```

## Recommended validation sequence

1. Run `tools/hb_safe_reference.py`.
2. Build and confirm the runtime symbol with `nm`.
3. Run the one-cell-streamwise normal-flow tutorial.
4. Compare the phase-fraction-weighted mean and maximum liquid velocity with:

   ```text
   Umean = 0.242975383711 m/s
   Umax  = 0.283471280996 m/s
   ```

5. Compare `HerschelBulkley` and `HerschelBulkleySafe` for the unregularized
   pure-power-law case; they should agree to solver tolerances.
6. Test a regularized Bingham case initialized at exact rest and verify the
   low-shear limit against `min(eta0, K + tau0*m)`.
7. Perform mesh, time-step, viscosity-cap and regularization-parameter
   sensitivity studies before scientific use.

## Limitations

- The model is algebraic and does not create a sharp unyielded solid region.
- A viscosity cap and Papanastasiou regularization alter the ideal yield
  surface and must be subjected to sensitivity studies.
- Constitutive objects are selected at startup; restart after changing the
  model type or material parameters.
- The package has passed source/header checks, but final linking and CFD
  acceptance remain local tasks in a complete OpenFOAM 9 + RheoTool OF90
  installation.
