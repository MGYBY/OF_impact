# OpenFOAM 9 port changelog

## Compatibility/API

- rebased loop and field infrastructure on Foundation OpenFOAM 9;
- migrated `fvOptions` to `fvModels` and `fvConstraints`;
- adopted `pressureReference`;
- adopted OF9 `MULES::limitSum`;
- adopted OF9 `regIOobject::read()` path;
- updated Make include paths and libraries;
- added build-time Foundation-9 environment guard.

## Pressure/cyclic formulation

- retained solved physical pressure `p`;
- retained explicit `+rho*g` body force;
- removed all active `p_rgh`, `gh`, `ghf` and `hRef` paths;
- ported initial and moving-mesh flux correction to physical `p`;
- supplied ordinary cyclic `p` patches in the regression tutorial.

## Rheology

- replaced the customized OF70 constitutive dependency by official OF90;
- one OF90 constitutive equation per phase;
- phase alpha passed to the OF90 correction method;
- GNF `tau()` double-count protection;
- excluded the bundled/customized OF7 Herschel-Bulkley source file.

## Interface treatment

- retained phase-specific surface-tension decomposition;
- retained VOF smoothing only in curvature evaluation;
- retained raw-alpha phase-normal artificial compression;
- retained SIMPLEC;
- added runtime validation of `sigma_ij = Sigma_i + Sigma_j`;
- changed the tutorial upper boundary from a wall to an atmospheric open patch.

## Build-script correction

- Removed shell nounset mode (`set -u`) from the top-level `Allwmake`.
- Reason: OpenFOAM 9's `AllwmakeParseArguments` uses intentionally unset
  variables for its default target and is not nounset-safe.
- This correction changes only build-script behavior, not solver source.

## PLIC/MPLIC compatibility update

- classified OF9 `interfaceCompression`, `noInterfaceCompression`, `PLIC`,
  `PLICU`, `MPLIC` and `MPLICU` as self-contained phase-fraction schemes;
- disabled the legacy pairwise compression flux for those schemes to prevent
  double sharpening;
- retained the published phase-normal pairwise compression for algebraic
  schemes such as `vanLeer01`;
- made `cAlpha` optional for self-contained OF9 schemes and mandatory for the
  legacy algebraic branch;
- passed an explicitly ungrouped copy of the common `phi` to PLIC/MPLIC so the
  OF9 velocity lookup resolves the common field `U`;
- registered a temporary phase-specific `nHatf` while constructing PLIC/PLICU
  fluxes, enabling the standard OF9 interface-compression fallback syntax;
- added a fatal dictionary check that rejects PLIC/MPLIC/interfaceCompression
  on the already-compressive `div(phirb,alpha)` flux;
- linked `libtwoPhaseMixture` explicitly, which contains the OF9 run-time
  constructors for the PLIC-family schemes;
- corrected the legacy tutorial entry to `div(phirb,alpha) Gauss linear;`;
- added an MPLIC tutorial and switchable PLIC/PLICU/MPLICU/interfaceCompression
  dictionary templates.

## v4: package-local `HerschelBulkleySafe`

- added an OF90 runtime-selectable `HerschelBulkleySafe` class to the custom
  mixture library;
- retained the OF90 `correct(alpha, gradU)` signature and thermal multiplier;
- retained generalized-Newtonian semantics (`isGNF() == true`), so the full
  phase stress continues to come from `divTauS(U, alpha)`;
- used `-std::expm1(-m*gammaDot)` for cancellation-safe Papanastasiou
  regularization;
- evaluated the power-law term in logarithmic form before applying `eta0` to
  avoid startup overflow for strongly shear-thinning fluids;
- added explicit range and dimensions checks for `rho`, `eta0`, `tau0`, `k`,
  `n`, and `m`;
- added optional `gammaDot`, `tauTotal`, and `IItauD` diagnostics;
- added an OF90 API checker that rejects an OF70/of70_plus header tree;
- changed both supplied normal-flow tutorials to select
  `HerschelBulkleySafe`;
- added an independent scalar constitutive-reference script and expanded the
  static audit and documentation.
