# Changelog

## OF7 complete v3 — 2026-08-03

- completed the previously missing revised `phase.H`;
- compiled `HerschelBulkleySafe.C` through the custom library Makefile;
- replaced fixed RheoTool source paths by `RHEOTOOL_SRC`;
- removed the unused turbulence object from the laminar solver path;
- made the safe constitutive model explicitly isothermal;
- included the missing optional legacy patch source;
- added complete build, source-map, formulation, dictionary, validation,
  provenance and limitation documentation;
- replaced the nested old tutorial archive by two visible case directories;
- added environment, analytical-reference and static-audit tools.
