# Verification status

## What has been completed

### 1. Direct source comparison

The port was developed by comparing:

- the uploaded OpenFOAM-7 physical-pressure solver;
- the uploaded parent `rheoMultiFluidInterFoam` source;
- the uploaded OpenFOAM-7 and OpenFOAM-9 source trees;
- the official RheoTool OF90 source interfaces;
- the 2022 solver paper and the 2025 application paper.

### 2. Static audit

`tools/static_audit.py` checks 33 high-risk invariants.  The packaged result is
33 passed and 0 failed.  It covers OF9 API migration, physical pressure,
RheoTool ownership, GNF double-count protection, surface-tension decomposition,
curvature-only smoothing, MULES, SIMPLEC, tutorial cyclic pressure and rejection
of known OF7-only tokens.

### 3. Header/object compilation

The following translation units compiled successfully with `g++ -std=c++14`
against the **actual uploaded OpenFOAM-9 headers**:

```text
multiphaseMixture/phase/phase.C
multiphaseMixture/alphaContactAngle/alphaContactAngleFvPatchScalarField.C
multiphaseMixture/multiphaseMixture.C
rheoMultiFluidInterFoamP.C
```

The check used minimal signature-compatible RheoTool API headers because a full
compiled OF90 installation and its external libraries were not present in this
runtime.  Those signatures were cross-checked against official OF90
`constitutiveEq` and `sparseSolver` declarations.

This proves that the custom source passes the OpenFOAM-9 C++ header/API stage.
It does not prove final linking or runtime behavior.

### 4. Mathematical regression checks

- `tools/pressure_identity_check.py` shows second-order convergence of the
  continuous physical-pressure identity.
- `tools/power_law_reference.py` reproduces
  `Umean = 0.242975383711 m/s` and `Umax = 0.283471280996 m/s` for the supplied
  power-law film parameters.

## What has not been completed

- final `wmake` linking against compiled OF9 and RheoTool OF90 libraries;
- execution of `blockMesh`, `setFields`, `checkMesh` and the solver;
- Newtonian regression against stock `multiphaseInterFoam`;
- numerical normal-flow comparison against the analytical power-law profile;
- dynamic-mesh or parallel execution;
- viscoelastic and three-phase validation;
- contact-angle verification;
- hydrostatic spurious-current comparison with the original `p_rgh` solver.

## Evidence files

```text
developmentEvidence/static_audit.txt
developmentEvidence/library_header_compile.log
developmentEvidence/solver_header_compile.log
developmentEvidence/pressure_identity_check.txt
developmentEvidence/power_law_reference.txt
```

## Claim boundary

The defensible current statement is:

> The modified source is an OpenFOAM-9 compatibility port that passes static
> migration checks and translation-unit compilation against OF9 headers.  It
> still requires final local linking and staged CFD validation before being
> treated as a production solver.
