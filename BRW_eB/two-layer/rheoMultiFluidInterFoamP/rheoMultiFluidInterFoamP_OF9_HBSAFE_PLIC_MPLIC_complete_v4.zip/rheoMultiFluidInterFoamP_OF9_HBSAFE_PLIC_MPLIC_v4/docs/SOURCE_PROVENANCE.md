# Source provenance

## Local source lineage

```text
OpenFOAM-9 multiphaseInterFoam
    + multiFluid/rheoMultiFluid interface methodology
    + physical-pressure P formulation
    + official RheoTool OF90 interfaces
    + corrected GNF stress ownership
    + OF9 PLIC/MPLIC integration
    + package-local HerschelBulkleySafe
    = rheoMultiFluidInterFoamP_OF9_HBSAFE_PLIC_MPLIC_v4
```

The v4 working base is the previously delivered:

```text
rheoMultiFluidInterFoamP_OF9_PLIC_MPLIC_v3
```

The focused v3-to-v4 review diff is stored under `patches/`.

## External build dependency

The package uses the official public RheoTool OF90 interfaces, notably:

```text
of90/src/libs/constitutiveEquations/constitutiveEqs/constitutiveEq/
of90/src/libs/constitutiveEquations/constitutiveEqs/GNF/HerschelBulkley/
of90/src/libs/thermo/
```

RheoTool source and binaries are not redistributed in this package.

## `HerschelBulkleySafe` derivation

The local class follows the official OF90 constructor, runtime-selection,
`correct(alpha, gradU)`, `eta()`, `isGNF()`, and thermal-multiplier interfaces.
Its additional implementation logic is package-specific:

- `expm1` evaluation of the Papanastasiou numerator;
- logarithmic power-law evaluation before the viscosity cap;
- dimensions/range validation; and
- optional diagnostic fields.

The official RheoTool library is not patched.  This separation allows the
standard `HerschelBulkley` and local `HerschelBulkleySafe` types to coexist.

## License

The solver and local model are distributed under the GPL terms stated in
`COPYING` and the individual source headers.  The public RheoTool dependency
has its own upstream copyright and GPL notices.
