# Source file map

| File | Responsibility |
|---|---|
| `rheoMultiFluidInterFoamP.C` | OF9 time loop, mesh update, phase/momentum/pressure workflow |
| `createFields.H` | physical `p`, `U`, `phi`, mixture, `rho`, gravity, pressure reference, OF9 models/constraints |
| `createSolver.H` | RheoTool sparse solvers for `p` and `U` |
| `UEqn.H` | conservative variable-density momentum equation, RheoTool stress, `+rho*g`, capillary and pressure predictor |
| `pEqn.H` | physical-pressure SIMPLEC/PIMPLE correction and flux update |
| `initCorrectPhi.H` | initial OF9 flux correction |
| `correctPhi.H` | dynamic-mesh flux correction using physical `p` |
| `multiphaseMixture/phase/phase.*` | phase fraction, base OF viscosity, OF90 constitutive equation and density |
| `multiphaseMixture/multiphaseMixture.*` | MULES transport, OF9 PLIC/MPLIC compatibility, density flux, surface tension, smoothing and phase stress assembly |
| `multiphaseMixture/alphaContactAngle/*` | OF9-compatible multiphase contact-angle boundary class |
| `Make/*` | OF9 application build and explicit PLIC/MPLIC runtime-library link |
| `multiphaseMixture/Make/*` | custom library build and explicit PLIC/MPLIC runtime-library link |
| `tutorials/periodicSteadyUniformPowerLaw` | cyclic physical-pressure power-law case using the legacy published phase-normal compression branch |
| `tutorials/periodicSteadyUniformPowerLawMPLIC` | cyclic geometric-VOF smoke case plus switchable PLIC/PLICU/MPLIC/MPLICU/interfaceCompression templates |
| `tutorials/periodicSteadyUniformPowerLawMPLIC/selectVoFScheme` | installs matching `fvSchemes` and `fvSolution` for each VOF branch |
| `docs/PLIC_MPLIC_COMPATIBILITY.md` | root cause, implementation policy, dictionary syntax and n-phase limitation |
| `tools/static_audit.py` | source/case migration and geometric-VOF invariant audit |
| `tools/check_environment.sh` | local OF9/RheoTool build preflight |
| `tools/pressure_identity_check.py` | continuous pressure/gravity identity regression |
| `tools/power_law_reference.py` | analytical normal-flow reference values |
| `patches/PLIC_MPLIC_COMPATIBILITY.patch` | focused review patch from the previous OF9 port to this update |
