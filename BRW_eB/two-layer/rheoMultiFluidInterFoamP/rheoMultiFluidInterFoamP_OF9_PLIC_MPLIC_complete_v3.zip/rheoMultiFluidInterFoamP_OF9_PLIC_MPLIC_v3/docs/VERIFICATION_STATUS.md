# Verification status

## Completed checks

### 1. Direct source comparison

The port and the PLIC/MPLIC compatibility update were developed by comparing:

- the uploaded OpenFOAM-7 physical-pressure solver;
- the uploaded parent `rheoMultiFluidInterFoam` source;
- the uploaded OpenFOAM-7 and OpenFOAM-9 source trees;
- the official RheoTool OF90 public interfaces;
- the OpenFOAM-9 `alphaScheme.H`, PLIC, PLICU, MPLIC, MPLICU and
  `interfaceCompression` implementations;
- the 2022 solver paper and the 2025 application paper.

### 2. Static audit

`tools/static_audit.py` checks **52 high-risk invariants**.  The packaged result
is:

```text
52 passed
0 failed
```

The checks cover:

- OpenFOAM-9 API migration;
- solved physical pressure and the sign of `rho*g`;
- OF90 constitutive ownership and the GNF double-stress guard;
- phase-specific surface tension and curvature-only smoothing;
- SIMPLEC and OF9 MULES phase-sum limiting;
- PLIC/PLICU/MPLIC/MPLICU scheme detection;
- bypass of the separate legacy compression flux for self-contained OF9 VOF
  schemes;
- optional `cAlpha` for geometric schemes;
- the ungrouped common flux used by MPLIC to resolve `U`;
- temporary phase-specific `nHatf` registration required by the normal PLIC
  fallback;
- rejection of PLIC-family schemes on `div(phirb,alpha)`;
- explicit `libtwoPhaseMixture` linkage;
- supplied legacy and geometric tutorial dictionaries.

### 3. Translation-unit compilation against OpenFOAM-9 headers

The following custom translation units compiled successfully as relocatable
objects using the **actual uploaded OpenFOAM-9 headers**:

```text
multiphaseMixture/phase/phase.C
multiphaseMixture/alphaContactAngle/alphaContactAngleFvPatchScalarField.C
multiphaseMixture/multiphaseMixture.C
rheoMultiFluidInterFoamP.C
```

The PLIC/MPLIC-specific source branch was present during these checks.  A full
compiled OF90 installation was unavailable in the packaging runtime, so the
header gate used minimal declaration-only headers containing only the official
OF90 signatures called by this port.  No stub implementation was linked into a
solver.

This establishes C++/OpenFOAM-9 header compatibility.  It does not establish
final shared-library linkage or runtime behavior.

### 4. Mathematical and source regressions

- `tools/pressure_identity_check.py` shows second-order convergence of the
  physical-pressure identity.
- `tools/power_law_reference.py` reproduces
  `Umean = 0.242975383711 m/s` and `Umax = 0.283471280996 m/s` for the supplied
  power-law film.
- Shell scripts pass `sh -n`.
- Python utilities pass `python3 -m py_compile`.
- The VOF selector was exercised for `legacy`, `interfaceCompression`, `PLIC`,
  `PLICU`, `MPLIC` and `MPLICU`; each choice installs the intended
  `fvSchemes`/`fvSolution` pair.

## Checks that remain local acceptance gates

The packaging runtime did not contain a complete compiled OpenFOAM-9 +
RheoTool OF90 + PETSc/HYPRE stack.  The following have therefore **not** been
claimed:

- final `wmake` linking of the custom library and executable;
- `ldd` verification in the user's installation;
- execution of `blockMesh`, `setFields`, `checkMesh` or the solver;
- one-step or long-time PLIC/PLICU/MPLIC/MPLICU runs;
- Newtonian regression against stock OF9 solvers;
- normal-flow profile convergence;
- dynamic-mesh, contact-angle, parallel, viscoelastic or triple-junction
  validation;
- hydrostatic/spurious-current comparison with the original `p_rgh` solver.

## Evidence files

```text
developmentEvidence/static_audit.txt
developmentEvidence/library_header_compile_PLIC_MPLIC.log
developmentEvidence/solver_header_compile_PLIC_MPLIC.log
developmentEvidence/HEADER_COMPILE_METHOD.md
developmentEvidence/pressure_identity_check.txt
developmentEvidence/power_law_reference.txt
```

## Claim boundary

The defensible current statement is:

> This is an OpenFOAM Foundation 9 source-level compatibility update that
> integrates the OF9 PLIC-family schemes into the custom n-phase transport loop,
> passes 52 static checks, and passes translation-unit compilation against OF9
> headers.  Final local linking and staged CFD tests remain mandatory before
> production or scientific use.
