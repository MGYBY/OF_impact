/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2021 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

\*---------------------------------------------------------------------------*/

#include "phase.H"

Foam::phase::phase
(
    const word& phaseName,
    const dictionary& phaseDict,
    const volVectorField& U,
    const surfaceScalarField& phi
)
:
    volScalarField
    (
        IOobject
        (
            IOobject::groupName("alpha", phaseName),
            U.mesh().time().timeName(),
            U.mesh(),
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        U.mesh()
    ),
    name_(phaseName),
    phaseDict_(phaseDict),
    nuModel_
    (
        viscosityModel::New
        (
            IOobject::groupName("nu", phaseName),
            phaseDict_,
            U,
            phi
        )
    ),
    constitutiveEq_
    (
        constitutiveEq::New
        (
            word("." + phaseName),
            U,
            phi,
            phaseDict_.subDict("parameters")
        )
    ),
    rho_("rho", dimDensity, phaseDict_)
{}


Foam::autoPtr<Foam::phase> Foam::phase::clone() const
{
    NotImplemented;
    return autoPtr<phase>(nullptr);
}


void Foam::phase::correct()
{
    // RheoTool OF90 accepts an optional colour function.  Passing this
    // phase fraction is important for differential constitutive models and
    // is harmless for algebraic GNF models.
    constitutiveEq_->correct(this);
}


bool Foam::phase::read(const dictionary& phaseDict)
{
    phaseDict_ = phaseDict;

    // Runtime re-reading of the stock viscosity and density is supported.
    // RheoTool constitutive equations are selected at construction time;
    // changing their model type requires restarting the case.
    if (nuModel_->read(phaseDict_))
    {
        phaseDict_.lookup("rho") >> rho_;
        return true;
    }

    return false;
}

// ************************************************************************* //
