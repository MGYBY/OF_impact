# License

Unless a source-file header states another compatible GNU GPL version, the
new and modified files in this package are distributed under the GNU General
Public License, version 3 or later.

This software is provided without warranty; without even the implied warranty
of merchantability or fitness for a particular purpose. See the GNU GPL for
full terms.

OpenFOAM, RheoTool, and the upstream rheoMultiFluidInterFoam source retain
their own copyright notices and GPL terms.
