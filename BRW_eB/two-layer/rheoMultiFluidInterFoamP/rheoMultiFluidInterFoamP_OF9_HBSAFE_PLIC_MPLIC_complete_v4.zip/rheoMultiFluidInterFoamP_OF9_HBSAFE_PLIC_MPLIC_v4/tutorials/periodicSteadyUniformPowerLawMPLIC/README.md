# Periodic power-law film with OF9 PLIC/MPLIC and HBSAFE

This is the geometric-interface companion to
`periodicSteadyUniformPowerLaw`.  It uses the same physical-pressure periodic
film and the same package-local:

```foam
type HerschelBulkleySafe;
```

MPLIC is active by default:

```foam
div(phi,alpha)      Gauss MPLIC;
div(phirb,alpha)    Gauss linear;
```

The geometric alpha solver deliberately omits `cAlpha`.  The solver reads
`cAlpha` only when the legacy algebraic branch is selected.

## Select a VOF scheme

```bash
./selectVoFScheme MPLIC
./selectVoFScheme MPLICU
./selectVoFScheme PLIC
./selectVoFScheme PLICU
./selectVoFScheme interfaceCompression
./selectVoFScheme legacy
```

PLIC uses the standard OF9 fallback syntax:

```foam
div(phi,alpha)    Gauss PLIC interfaceCompression vanLeer 1;
```

## Run

```bash
./selectVoFScheme MPLIC
./Allclean
./Allrun 2>&1 | tee log.Allrun.MPLIC
```

The log should identify MPLIC as a self-contained OF9 VOF scheme and state that
the separate legacy pairwise-compression branch is disabled.

## Checks

For every selected scheme, compare:

- alpha boundedness and phase-sum error;
- phase volume;
- phase-weighted liquid discharge and maximum velocity;
- cyclic face-flux matching;
- interface thickness and spurious velocity;
- `eta.mud`, `gammaDot.mud`, `tauTotal.mud`, and `IItauD.mud`;
- time-step and grid convergence.

Do not place PLIC, MPLIC or direct `interfaceCompression` under
`div(phirb,alpha)`.  That flux is already the explicit legacy compression flux
and must use a conventional interpolation such as `Gauss linear`.

This is a smoke/regression case, not a completed CFD validation.  See:

```text
../../docs/HERSCHELBULKLEY_SAFE.md
../../docs/PLIC_MPLIC_COMPATIBILITY.md
../../docs/LOCAL_ACCEPTANCE_TESTS.md
```
