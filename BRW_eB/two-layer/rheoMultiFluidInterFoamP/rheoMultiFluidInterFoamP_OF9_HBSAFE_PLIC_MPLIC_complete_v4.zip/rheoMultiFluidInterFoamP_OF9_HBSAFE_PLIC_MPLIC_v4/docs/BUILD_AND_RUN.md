# Build and run guide

## Prerequisites

- Linux/Ubuntu with OpenFOAM Foundation 9 sourced;
- official RheoTool OF90 compiled in the same OF9 environment;
- the Eigen, PETSc and HYPRE settings used by that RheoTool build;
- preferably, a working OF90 `rheoInterFoam` baseline.

Do not build while OpenFOAM 7, OpenFOAM.com, or another Foundation release is
active.

## 1. Source OpenFOAM 9

```bash
source /opt/openfoam9/etc/bashrc

printf 'WM_PROJECT_VERSION=%s\n' "$WM_PROJECT_VERSION"
printf 'WM_OPTIONS=%s\n' "$WM_OPTIONS"
command -v wmake
```

`WM_PROJECT_VERSION` must be `9` or `9.*`.

## 2. Export the RheoTool OF90 build environment

```bash
export RHEOTOOL_SRC=/path/to/rheoTool/of90/src/libs
export EIGEN_RHEO=/path/to/Eigen
export PETSC_DIR=/path/to/petsc
export PETSC_ARCH=arch-linux-c-opt
```

If the conventional link exists,

```text
$FOAM_USER_SRC/libs/libRheoTool
```

`RHEOTOOL_SRC` may be omitted.

## 3. Preflight checks

```bash
./tools/check_environment.sh
./tools/check_rheotool_api.sh
```

The API checker must report:

```text
constitutive correct API             OF90 pointer-argument signature
phase-weighted GNF API               divTauS and isGNF present
RheoTool OF90 API/header consistency check passed.
```

A header tree exposing only the OF70 no-argument `correct()` API is not
compatible with this OF9 package.

## 4. Compile

```bash
./Allwclean
./Allwmake 2>&1 | tee log.Allwmake
```

Expected products:

```text
$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so
$FOAM_USER_APPBIN/rheoMultiFluidInterFoamP
```

The top-level `Allwmake` deliberately uses `set -e`, not `set -eu`, because
OpenFOAM 9's `AllwmakeParseArguments` uses intentionally unset variables for
the default target.

## 5. Verify the runtime class and linked libraries

```bash
nm -D -C \
    "$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so" \
  | grep HerschelBulkleySafe
```

Then:

```bash
solver=$(command -v rheoMultiFluidInterFoamP)

ldd "$solver" | tee log.ldd
! grep -q 'not found' log.ldd

grep -E \
    'librheoMultiFluidInterFoamP9|libconstitutiveEquations|libthermoRheoTool|libtwoPhaseMixture' \
    log.ldd
```

## 6. Run package checks

```bash
python3 tools/static_audit.py | tee log.static-audit
python3 tools/hb_safe_reference.py | tee log.hb-safe-reference
python3 tools/pressure_identity_check.py | tee log.pressure-identity
python3 tools/power_law_reference.py | tee log.power-law-reference
```

Every script must return zero.

## 7. Select `HerschelBulkleySafe`

The active constitutive equation belongs inside the phase `parameters` block:

```foam
mud
{
    // Compatibility OpenFOAM viscosity object.
    transportModel Newtonian;
    nu              [0 2 -1 0 0 0 0] 0.0207986688852;
    rho             [1 -3 0 0 0 0 0] 1202;

    parameters
    {
        type        HerschelBulkleySafe;

        rho         rho  [1 -3 0 0 0 0 0] 1202;
        eta0        eta0 [1 -1 -1 0 0 0 0] 25;
        tau0        tau0 [1 -1 -2 0 0 0 0] 0;
        k           k    [1 -1 -1 0 0 0 0] 1.38;
        n           n    [0 0 0 0 0 0 0] 0.2;

        PapanastasiouRegularization false;

        writeShearRate              true;
        writeStress                 true;
        writeSecondInvariantTauDev  true;
    }
}
```

Do not set the outer `transportModel` to `HerschelBulkley`.  The phase-level
OpenFOAM object is retained only for compatibility; the actual momentum
rheology is selected by `parameters/type`.

See `HERSCHELBULKLEY_SAFE.md` for power-law, Bingham, regularized
Herschel--Bulkley and Newtonian examples.

## 8. Run the legacy-compression tutorial

```bash
cd tutorials/periodicSteadyUniformPowerLaw
./Allclean
./Allrun 2>&1 | tee log.Allrun
```

The case uses `HerschelBulkleySafe` in the pure-power-law limit.

## 9. Run a geometric-VOF tutorial

```bash
cd tutorials/periodicSteadyUniformPowerLawMPLIC

./selectVoFScheme MPLIC
./Allclean
./Allrun 2>&1 | tee log.Allrun.MPLIC
```

The selector also accepts:

```text
PLIC  PLICU  MPLICU  interfaceCompression  legacy
```

For a self-contained geometric scheme:

```foam
div(phi,alpha)      Gauss MPLIC;
div(phirb,alpha)    Gauss linear;
```

Do not put PLIC, MPLIC or `interfaceCompression` on `div(phirb,alpha)`.
The PLIC/MPLIC policy is documented in `PLIC_MPLIC_COMPATIBILITY.md`.

## 10. Normal-flow targets

For the supplied liquid parameters:

```text
rho = 1202 kg/m3
K   = 1.38 Pa s^n
n   = 0.2
H   = 0.00602890842 m
gx  = 0.5886 m/s2
```

the analytical values are:

```text
Umean = 0.242975383711 m/s
Umax  = 0.283471280996 m/s
```

Use phase-fraction-weighted integration; do not include the air velocity in the
liquid mean.

## Surface-tension dictionaries

The physical and decomposed values must satisfy:

```text
sigma_ij = Sigma_i + Sigma_j.
```

Example:

```foam
sigmas
(
    (mud air) 0.07
);

sigmasPh
(
    (mud mud) 0.035
    (air air) 0.035
);
```

## Frequent failures

### `Unknown constitutiveEq type HerschelBulkleySafe`

The custom library is stale or not loaded.  Clean and rebuild, then inspect the
symbol with `nm` and the executable with `ldd`.

### OF70/OF90 `correct()` signature errors

Run:

```bash
./tools/check_rheotool_api.sh
```

Set `RHEOTOOL_SRC` to `rheoTool/of90/src/libs`, not `of70` or a customized
`of70_plus` tree.

### Missing `m`

When:

```foam
PapanastasiouRegularization true;
```

is selected, provide:

```foam
m m [0 0 1 0 0 0 0] 50;
```

### `libHYPRE...so` not found

Source the same PETSc/HYPRE runtime environment used to build RheoTool and
correct `LD_LIBRARY_PATH` before running the solver.

### Unknown PLIC/MPLIC interpolation scheme

Confirm both Make/options files link `-ltwoPhaseMixture`, rebuild the custom
library and executable, and inspect `ldd`.

### Lookup for `U.<group>` or missing `nHatf`

An older mixture library is loaded or a geometric scheme was incorrectly
assigned to `div(phirb,alpha)`.  Rebuild this package and retain
`div(phirb,alpha) Gauss linear;`.

### `Inconsistent surface-tension decomposition`

Correct `sigmasPh`; do not duplicate the complete pairwise tension for both
phases.
