# `rheoMultiFluidInterFoamP` for OpenFOAM Foundation 9

This is the **HBSAFE + PLIC/MPLIC v4** source package for the physical-pressure
`rheoMultiFluidInterFoamP` solver.

```text
OpenFOAM Foundation 9
+ official RheoTool OF90
+ package-local HerschelBulkleySafe
+ physical pressure p
+ PLIC/PLICU/MPLIC/MPLICU compatibility
```

The solver is intended primarily for laminar, streamwise-periodic free-surface
power-law and Herschel--Bulkley calculations on inclined domains.  Mechanical
pressure `p` is solved directly and gravity appears as `+rho*g`, allowing
ordinary translational `cyclic` pressure patches.

## Major features

- OpenFOAM-9 `pimple.run(runTime)`, `fvModels`, `fvConstraints`,
  `pressureReference`, and current MULES APIs.
- One official RheoTool OF90 constitutive equation per phase.
- Correct GNF stress assembly: `divTauS()` supplies the full generalized-
  Newtonian stress; `tau()` is added only for non-GNF differential models.
- Package-local runtime model:

  ```foam
  type HerschelBulkleySafe;
  ```

  with cancellation-safe Papanastasiou regularization, overflow-safe
  shear-thinning evaluation, validation, and diagnostics.
- Published phase-specific capillarity, curvature-only smoothing, phase-normal
  legacy compression, and SIMPLEC pressure correction.
- Runtime verification of `sigma_ij = Sigma_i + Sigma_j`.
- Explicit OF9 compatibility for `PLIC`, `PLICU`, `MPLIC`, `MPLICU`, direct
  `interfaceCompression`, and the legacy algebraic VOF branch.

## Verification status

| Check | Status |
|---|---|
| Expanded static source/case audit | **66/66 passed** |
| `HerschelBulkleySafe.C` against actual OF9 headers | Passed |
| All custom-library translation units against actual OF9 headers | Passed |
| Main solver translation unit against actual OF9 headers | Passed |
| Independent scalar HB-safe reference | Passed |
| Pressure/gravity manufactured identity | Passed |
| Analytical power-law reference | Passed |
| Final linking in a complete OF9/RheoTool installation | Local acceptance gate |
| CFD and parallel validation | Local acceptance gate |

The header-compilation gate uses actual OpenFOAM 9 headers and declaration-only
stubs matching the official RheoTool OF90 signatures.  It does not substitute
for final linking or CFD execution.  See `docs/VERIFICATION_STATUS.md`.

## Build

```bash
source /opt/openfoam9/etc/bashrc

export RHEOTOOL_SRC=/path/to/rheoTool/of90/src/libs
export EIGEN_RHEO=/path/to/Eigen
export PETSC_DIR=/path/to/petsc
export PETSC_ARCH=<your-petsc-architecture>

./tools/check_environment.sh
./tools/check_rheotool_api.sh
./Allwclean
./Allwmake 2>&1 | tee log.Allwmake
```

Expected products:

```text
$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so
$FOAM_USER_APPBIN/rheoMultiFluidInterFoamP
```

Check the runtime model and linked libraries:

```bash
nm -D -C "$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so" \
  | grep HerschelBulkleySafe

ldd "$FOAM_USER_APPBIN/rheoMultiFluidInterFoamP" | tee log.ldd
! grep -q 'not found' log.ldd
```

Detailed instructions are in `docs/BUILD_AND_RUN.md`.

## Use `HerschelBulkleySafe`

```foam
parameters
{
    type        HerschelBulkleySafe;

    rho         rho  [1 -3 0 0 0 0 0] 1202;
    eta0        eta0 [1 -1 -1 0 0 0 0] 25;
    tau0        tau0 [1 -1 -2 0 0 0 0] 0;
    k           k    [1 -1 -1 0 0 0 0] 1.38;
    n           n    [0 0 0 0 0 0 0] 0.2;

    PapanastasiouRegularization false;

    writeShearRate              true;
    writeStress                 true;
    writeSecondInvariantTauDev  true;
}
```

Complete power-law, Bingham and Papanastasiou examples are in
`docs/HERSCHELBULKLEY_SAFE.md`.

## Tutorials

Legacy algebraic/phase-normal compression:

```bash
cd tutorials/periodicSteadyUniformPowerLaw
./Allrun
```

Geometric VOF, with MPLIC active by default:

```bash
cd tutorials/periodicSteadyUniformPowerLawMPLIC
./selectVoFScheme MPLIC
./Allrun
```

Other selector values are:

```text
PLIC  PLICU  MPLICU  interfaceCompression  legacy
```

Both tutorials now select `HerschelBulkleySafe` in the pure power-law limit.
The analytical targets are:

```text
mean liquid velocity       0.242975383711 m/s
free-surface velocity      0.283471280996 m/s
```

## Key documentation

```text
docs/HERSCHELBULKLEY_SAFE.md
docs/BUILD_AND_RUN.md
docs/PLIC_MPLIC_COMPATIBILITY.md
docs/PRESSURE_FORMULATION.md
docs/RHEOTOOL_STRESS_ASSEMBLY.md
docs/LOCAL_ACCEPTANCE_TESTS.md
docs/VERIFICATION_STATUS.md
```

## Scope

The application is intentionally laminar.  GNF free-surface roll waves are the
primary target.  Differential viscoelastic models, contact-line problems,
three-phase geometric reconstruction, dynamic meshes, and parallel execution
require dedicated local regression tests before scientific use.
