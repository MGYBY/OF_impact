# Known limitations and cautions

1. **No full link or CFD run in the packaging runtime.**  The package is not
   represented as a validated executable.
2. **Laminar scope.**  No OpenFOAM eddy-viscosity/turbulence stress is added.
3. **GNF is the primary validated design target.**  Differential viscoelastic
   models are source-compatible but need dedicated runtime tests.
4. **Physical pressure is not automatically well balanced.**  A static-column
   test is mandatory because discrete hydrostatic cancellation can differ from
   the original `p_rgh` formulation.
5. **Contact angle needs regression.**  The port retains the OF9-compatible
   boundary class and pairwise correction machinery, but the published
   phase-specific curvature path has not been numerically verified here for
   wall contact lines or triple junctions.
6. **Dynamic mesh is compile-checked only.**  Topology-changing cases have not
   been executed.
7. **External solver stack remains required.**  The current build follows
   RheoTool's Eigen/PETSc/HYPRE sparse-solver environment.
8. **The compatibility `nu` is not the active GNF apparent viscosity.**  Use
   the RheoTool phase viscosity fields (for example `eta.mud`) for rheological
   diagnostics.
9. **Surface-tension decomposition is user supplied.**  The solver now checks
   consistency but does not derive `Sigma_i` automatically for arbitrary
   n-phase systems.
10. **No geometric PLIC switch was added.**  The case can use OF9-supported
    interpolation schemes where compatible, but the default regression case
    retains the published MULES/artificial-compression approach.
11. **The smoke tutorial is not a full roll-wave validation.**  Its streamwise
    length is one normal depth and its initial velocity is uniform.
