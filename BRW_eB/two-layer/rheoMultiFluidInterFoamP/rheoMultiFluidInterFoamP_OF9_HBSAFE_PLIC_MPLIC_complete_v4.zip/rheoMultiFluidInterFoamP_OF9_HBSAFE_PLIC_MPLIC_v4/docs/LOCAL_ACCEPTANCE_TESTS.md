# Local acceptance tests

Complete the gates in order and archive all logs.

## A. Environment and API

```bash
./tools/check_environment.sh
./tools/check_rheotool_api.sh
python3 tools/static_audit.py
python3 tools/hb_safe_reference.py
```

Acceptance:

- every command returns zero;
- OF90 pointer-argument `correct()` API is detected;
- the static audit reports zero failures.

## B. Build and link

```bash
./Allwclean
./Allwmake 2>&1 | tee log.Allwmake

solver=$(command -v rheoMultiFluidInterFoamP)
ldd "$solver" | tee log.ldd
! grep -q 'not found' log.ldd

nm -D -C "$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so" \
  | grep HerschelBulkleySafe
```

Acceptance:

- build return code is zero;
- both expected binary products exist;
- no library is missing;
- the Safe runtime class is present.

## C. Parser/runtime-selection smoke test

Run the short normal-flow case with:

```foam
type HerschelBulkleySafe;
```

Acceptance:

- no `Unknown constitutiveEq` error;
- `eta.mud`, `gammaDot.mud`, `tauTotal.mud`, and `IItauD.mud` are written when
  enabled;
- no NaN or Inf appears.

## D. Official-versus-Safe unregularized comparison

Run identical pure-power-law cases using:

```foam
type HerschelBulkley;
```

and:

```foam
type HerschelBulkleySafe;
```

with `tau0=0`, `n=0.2`, and regularization off.

Acceptance after the same transient interval:

- phase volume difference is within solver tolerance;
- phase-weighted discharge and velocity profiles agree to a documented small
  tolerance;
- apparent-viscosity profiles agree except for roundoff-level differences.

## E. Power-law analytical normal flow

Targets:

```text
Umean = 0.242975383711 m/s
Umax  = 0.283471280996 m/s
```

Acceptance:

- phase-fraction-weighted values converge to the analytical solution under
  mesh and time-step refinement;
- basal total traction balances `rho*gx*h` once, not twice;
- the profile shape and `Umax/Umean` converge correctly.

## F. Exact-rest Papanastasiou test

Use a regularized Bingham case with `n=1`, initialize `U=0`, and compare the
low-shear viscosity with:

```text
min(eta0, K + tau0*m).
```

Acceptance:

- the Papanastasiou yield contribution is not lost at startup;
- no artificial zero-viscosity region appears;
- decreasing the initial velocity perturbation does not change the limit.

## G. Parameter rejection

Deliberately test one invalid setting at a time:

- `rho <= 0`;
- `eta0 <= 0`;
- `tau0 < 0`;
- `k < 0`;
- `n <= 0`;
- regularization active with `m <= 0`;
- incorrect dimensions.

Acceptance: each case stops before time integration with a clear fatal
message.

## H. VOF scheme matrix

Run:

```text
legacy
interfaceCompression
PLIC
PLICU
MPLIC
MPLICU
```

Acceptance:

- no lookup for `U.<group>`;
- no missing `nHatf`;
- no geometric scheme is used on `div(phirb,alpha)`;
- phase fractions remain bounded and sum to one;
- phase volumes and cyclic fluxes are conserved.

## I. Pressure/reference tests

- repeat with several valid `pRefCell` values;
- compare `U`, phase fractions and fluxes after subtracting an additive
  pressure constant;
- run a static two-density column and a static-drop Laplace-pressure test.

## J. Convergence and advanced features

Before scientific production:

- grid and time-step convergence;
- `eta0` sensitivity;
- Papanastasiou `m` sensitivity;
- cyclic seam continuity;
- serial/parallel comparison;
- dynamic mesh and contact angle where relevant;
- three-phase/triple-junction tests;
- differential viscoelastic regression.
