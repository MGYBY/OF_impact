/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2019 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is distributed under the GNU General Public License v3 or later.

Application
    rheoMultiFluidInterFoamP

Description
    Laminar physical-pressure version of rheoMultiFluidInterFoam for n
    incompressible Newtonian or non-Newtonian phases under OpenFOAM
    Foundation 7.

    The solved pressure is the mechanical/static pressure p.  Gravity enters
    the momentum equation as +rho*g, allowing ordinary translational cyclic
    pressure conditions in a bed-aligned periodic inclined domain.

\*---------------------------------------------------------------------------*/

#include "sparseSolver.H" // Segregated RheoTool solver interface only

#include "fvCFD.H"
#include "dynamicFvMesh.H"
#include "multiphaseMixture.H"
#include "pimpleControl.H"
#include "fvOptions.H"
#include "CorrectPhi.H"

#include "adjustCorrPhi.H"
#include "ppUtilInterface.H"

int main(int argc, char *argv[])
{
    #include "postProcess.H"

    #include "setRootCaseLists.H"
    #include "createTime.H"
    #include "createDynamicFvMesh.H"
    #include "initContinuityErrs.H"
    #include "createDyMControls.H"
    #include "createFields.H"
    #include "createSolver.H"
    #include "initCorrectPhi.H"
    #include "createUfIfPresent.H"
    #include "createPPutil.H"

    #include "CourantNo.H"
    #include "setInitialDeltaT.H"

    const surfaceScalarField& rhoPhi(mixture.rhoPhi());

    Info<< "\nPressure formulation: -grad(p) + rho*g" << nl
        << "Starting time loop\n" << endl;

    while (runTime.run())
    {
        #include "readDyMControls.H"

        // transportProperties is MUST_READ_IF_MODIFIED.  This call invokes
        // the mixture's checked runtime re-read only when the file changed.
        mixture.readIfModified();

        #include "CourantNo.H"
        #include "alphaCourantNo.H"
        #include "setDeltaT.H"

        runTime++;

        Info<< "Time = " << runTime.timeName() << nl << endl;

        while (pimple.loop())
        {
            if (pimple.firstPimpleIter() || moveMeshOuterCorrectors)
            {
                const scalar timeBeforeMeshUpdate = runTime.elapsedCpuTime();

                mesh.update();

                if (mesh.changing())
                {
                    Info<< "Execution time for mesh.update() = "
                        << runTime.elapsedCpuTime() - timeBeforeMeshUpdate
                        << " s" << endl;

                    MRF.update();

                    if (correctPhi)
                    {
                        phi = mesh.Sf() & Uf();
                        #include "correctPhi.H"
                        fvc::makeRelative(phi, U);
                    }

                    if (checkMeshCourantNo)
                    {
                        #include "meshCourantNo.H"
                    }
                }
            }

            // Transport alpha first, then update all constitutive equations.
            mixture.solve();
            rho = mixture.rho();

            #include "UEqn.H"

            while (pimple.correct())
            {
                #include "pEqn.H"
            }
        }

        runTime.write();
        postProc.update();

        Info<< "ExecutionTime = " << runTime.elapsedCpuTime() << " s"
            << "  ClockTime = " << runTime.elapsedClockTime() << " s"
            << nl << endl;
    }

    Info<< "End\n" << endl;
    return 0;
}

// ************************************************************************* //
