# Source file map

| File | Responsibility |
|---|---|
| `rheoMultiFluidInterFoamP.C` | OF9 time loop, mesh update, phase/momentum/pressure workflow |
| `createFields.H` | physical `p`, `U`, `phi`, mixture, `rho`, gravity, pressure reference, OF9 models/constraints |
| `createSolver.H` | RheoTool sparse solvers for `p` and `U` |
| `UEqn.H` | conservative variable-density momentum equation, RheoTool stress, `+rho*g`, capillary and pressure predictor |
| `pEqn.H` | physical-pressure SIMPLEC/PIMPLE correction and flux update |
| `initCorrectPhi.H` | initial OF9 flux correction |
| `correctPhi.H` | dynamic-mesh flux correction using physical `p` |
| `multiphaseMixture/phase/phase.*` | phase fraction, base OF viscosity, OF90 constitutive equation and density |
| `multiphaseMixture/multiphaseMixture.*` | MULES transport, density flux, surface tension, smoothing, phase stress assembly |
| `multiphaseMixture/alphaContactAngle/*` | OF9-compatible multiphase contact-angle boundary class |
| `Make/*` | OF9 application build |
| `multiphaseMixture/Make/*` | custom library build |
| `tutorials/periodicSteadyUniformPowerLaw` | cyclic physical-pressure two-phase power-law regression starter |
| `tools/static_audit.py` | source/case migration invariant audit |
| `tools/check_environment.sh` | local OF9/RheoTool build preflight |
| `tools/pressure_identity_check.py` | continuous pressure/gravity identity regression |
| `tools/power_law_reference.py` | analytical normal-flow reference values |
