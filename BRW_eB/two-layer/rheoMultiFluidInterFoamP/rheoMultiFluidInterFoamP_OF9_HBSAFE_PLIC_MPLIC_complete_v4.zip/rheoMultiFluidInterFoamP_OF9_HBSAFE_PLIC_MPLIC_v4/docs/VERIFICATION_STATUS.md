# Verification status

## Completed source-level checks

### Source basis

The release was checked against:

- the previous PLIC/MPLIC v3 package;
- OpenFOAM Foundation 9 source headers;
- the official RheoTool OF90 `constitutiveEq` and `HerschelBulkley` public
  interfaces;
- the original OF7 physical-pressure solver lineage; and
- the 2022 solver methodology and later viscoplastic application workflow.

### Static audit

`tools/static_audit.py` checks the high-risk invariants in:

- OpenFOAM-9 API migration;
- physical-pressure and gravity signs;
- GNF stress ownership and double-count protection;
- registration and OF90 signature of `HerschelBulkleySafe`;
- cancellation-safe and overflow-safe constitutive logic;
- parameter validation, thermal multiplication and diagnostics;
- phase-specific capillarity and curvature-only smoothing;
- SIMPLEC and OF9 MULES behavior;
- PLIC/PLICU/MPLIC/MPLICU integration;
- tutorial rheology and VOF dictionaries; and
- absence of known OF7-only active APIs.

The packaged audit reports **66/66 passed**, recorded in `developmentEvidence/static_audit.txt`.

### Translation-unit compilation

The exact packaged files were compiled against the actual OpenFOAM-9 headers:

```text
multiphaseMixture/phase/phase.C
multiphaseMixture/alphaContactAngle/alphaContactAngleFvPatchScalarField.C
multiphaseMixture/constitutiveEqs/HerschelBulkleySafe/HerschelBulkleySafe.C
multiphaseMixture/multiphaseMixture.C
rheoMultiFluidInterFoamP.C
```

A compiled OF90 installation was not present in the packaging environment.
Declaration-only headers matching the official OF90 signatures were used for
the RheoTool side of this header gate.  No stub implementation was linked or
distributed.  Logs are under `developmentEvidence/`.

### Independent scalar constitutive checks

`tools/hb_safe_reference.py` verifies:

- pure power-law capping at vanishing shear;
- a finite-shear power-law value;
- the Newtonian limit;
- bounded unregularized Bingham behavior;
- the Papanastasiou zero-shear limit; and
- the numerical advantage of `expm1` over direct subtraction.

The result is stored in:

```text
developmentEvidence/hb_safe_reference.txt
```

### Other checks

- pressure/gravity manufactured identity;
- analytical power-law normal-flow values;
- shell syntax;
- Python syntax;
- six-way VOF selector round-trip;
- ZIP and checksum integrity; and
- removal of build artifacts from distributed archives.

## What remains to be done locally

The following require the user's complete OpenFOAM 9 + RheoTool OF90 runtime:

1. final shared-library and executable linking;
2. `ldd` verification with no missing libraries;
3. dictionary parsing and runtime-selection of `HerschelBulkleySafe`;
4. the normal-flow CFD benchmark;
5. comparison with official `HerschelBulkley` in the unregularized power-law
   limit;
6. an exact-rest regularized Bingham startup test;
7. PLIC/PLICU/MPLIC/MPLICU CFD execution;
8. serial/parallel and cyclic-seam tests;
9. grid, time-step, `eta0`, and `m` convergence; and
10. advanced viscoelastic, dynamic-mesh, contact-line and three-phase tests.

## Claim boundary

This release is an **audited source package that passes OpenFOAM-9
translation-unit and static checks**.  It is not a production-validation
certificate.  Scientific use should begin only after the local acceptance
matrix in `LOCAL_ACCEPTANCE_TESTS.md` has passed.
