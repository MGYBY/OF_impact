/*--------------------------------*- C++ -*----------------------------------*\
  =========                 |
  \      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \    /   O peration     | OpenFOAM Foundation version 9 case dictionary
    \  /    A nd           |
     \/     M anipulation  |
\*---------------------------------------------------------------------------*/
FoamFile
{
    version     2.0;
    format      ascii;
    class       volScalarField;
    location    "0";
    object      alpha.mud;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
    dimensions      [0 0 0 0 0 0 0];
    internalField   uniform 0;

    boundaryField
    {
        periodicIn  { type cyclic; }
periodicOut { type cyclic; }
bed         { type zeroGradient; }
top
        {
            type       inletOutlet;
            inletValue uniform 0;
            value      uniform 0;
        }
frontAndBack { type empty; }
    }
