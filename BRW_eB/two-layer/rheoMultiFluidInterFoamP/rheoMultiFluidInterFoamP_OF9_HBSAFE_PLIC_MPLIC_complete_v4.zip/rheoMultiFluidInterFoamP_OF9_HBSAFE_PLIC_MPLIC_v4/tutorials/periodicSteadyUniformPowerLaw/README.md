# Periodic steady-uniform power-law film: legacy compression

This OpenFOAM Foundation 9 regression case uses:

```text
rheoMultiFluidInterFoamP
physical pressure p
ordinary streamwise cyclic patches
HerschelBulkleySafe
legacy phase-normal algebraic interface compression
```

The mud is the pure-power-law limit:

```text
rho  = 1202 kg/m3
K    = 1.38 Pa s^n
n    = 0.2
tau0 = 0
eta0 = 25 Pa s
H    = 0.00602890842 m
gx   = 0.5886 m/s2
```

The analytical targets are:

```text
Umean = 0.242975383711 m/s
Umax  = 0.283471280996 m/s
```

## Active rheology

`constant/transportProperties` selects:

```foam
type HerschelBulkleySafe;
```

in the unregularized pure-power-law limit.  It also enables:

```text
eta.mud
gammaDot.mud
tauTotal.mud
IItauD.mud
```

## Run

```bash
./Allclean
./Allrun 2>&1 | tee log.Allrun
```

## Checks

- phase fractions are bounded and sum to one;
- phase volume and cyclic mass flux are conserved;
- no missing library or runtime-selection error occurs;
- the phase-weighted liquid mean and maximum velocity converge to the targets;
- the basal total traction balances `rho*gx*h` once;
- results are invariant to a valid change of `pRefCell`;
- mesh, time step and `eta0` are converged.

The initial mud velocity is uniform rather than the exact vertical profile, so
this is initially a build/runtime smoke test.  Replace the initialization by
the exact profile for a strict convergence study.

The upper boundary is atmospheric/open.  Surface-tension entries satisfy:

```text
Sigma_mud + Sigma_air = sigma_mud-air.
```

See `../../docs/HERSCHELBULKLEY_SAFE.md` and
`../../docs/LOCAL_ACCEPTANCE_TESTS.md`.
