# Source file map

| File | Responsibility |
|---|---|
| `rheoMultiFluidInterFoamP.C` | OF9 time loop, mesh update, phase/constitutive/momentum/pressure sequence |
| `createFields.H` | physical `p`, `U`, fluxes, mixture, gravity, pressure reference, OF9 models and constraints |
| `createSolver.H` | RheoTool sparse solvers for `p` and `U` |
| `UEqn.H` | variable-density momentum equation, phase rheology, `+rho*g`, capillary and pressure predictor |
| `pEqn.H` | physical-pressure SIMPLEC/PIMPLE correction and flux update |
| `initCorrectPhi.H`, `correctPhi.H` | initial and moving-mesh physical-pressure flux correction |
| `multiphaseMixture/phase/phase.*` | phase fraction, base OF viscosity, OF90 constitutive object and density |
| `multiphaseMixture/multiphaseMixture.*` | MULES, PLIC/MPLIC integration, density flux, capillarity, smoothing and stress assembly |
| `multiphaseMixture/constitutiveEqs/HerschelBulkleySafe/*` | package-local OF90 safe Herschel--Bulkley GNF model and diagnostics |
| `multiphaseMixture/alphaContactAngle/*` | OF9-compatible multiphase contact-angle boundary class |
| `Make/*`, `multiphaseMixture/Make/*` | application and custom-library build definitions |
| `tutorials/periodicSteadyUniformPowerLaw` | physical-pressure power-law case using legacy phase-normal compression |
| `tutorials/periodicSteadyUniformPowerLawMPLIC` | geometric-VOF case and selectable PLIC/PLICU/MPLIC/MPLICU templates |
| `docs/HERSCHELBULKLEY_SAFE.md` | rheology equations, dictionaries, output fields and validation plan |
| `docs/PLIC_MPLIC_COMPATIBILITY.md` | geometric-VOF failure mechanism, source policy and dictionary syntax |
| `docs/RHEOTOOL_STRESS_ASSEMBLY.md` | GNF versus differential-model stress ownership |
| `tools/check_rheotool_api.sh` | rejects an OF70/of70_plus API before an OF9 build |
| `tools/hb_safe_reference.py` | independent scalar constitutive reference checks |
| `tools/static_audit.py` | source, rheology, pressure, PLIC/MPLIC and case-invariant audit |
| `tools/check_environment.sh` | local OF9/RheoTool/PETSc/HYPRE preflight |
| `tools/pressure_identity_check.py` | physical-pressure/gravity identity regression |
| `tools/power_law_reference.py` | analytical normal-flow reference values |
| `patches/PLIC_MPLIC_V3_TO_HBSAFE_V4.patch` | focused review diff from v3 to v4 |
