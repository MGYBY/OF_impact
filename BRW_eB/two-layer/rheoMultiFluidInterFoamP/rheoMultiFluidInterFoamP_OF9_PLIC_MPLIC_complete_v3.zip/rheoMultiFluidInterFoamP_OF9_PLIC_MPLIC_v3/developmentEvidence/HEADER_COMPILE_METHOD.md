# Translation-unit header compilation method

The custom source files were compiled as relocatable objects against the
headers extracted from the uploaded OpenFOAM Foundation 9 source archive.  The
PLIC/MPLIC compatibility branch was active during the compilation.

Compiled translation units:

```text
multiphaseMixture/phase/phase.C
multiphaseMixture/alphaContactAngle/alphaContactAngleFvPatchScalarField.C
multiphaseMixture/multiphaseMixture.C
rheoMultiFluidInterFoamP.C
```

A complete compiled RheoTool OF90 installation was not available in the
packaging runtime.  Two minimal declaration-only headers were therefore used
for the compilation gate:

```text
constitutiveEq.H
sparseMatrixSolvers.H
```

They contain only the OF90 method signatures called by this port.  The
signatures were checked against the official OF90 source, including:

```text
constitutiveEq::New(...)
constitutiveEq::tau()
constitutiveEq::tauTotal()
constitutiveEq::rho()
constitutiveEq::divTauS(U, alpha)
constitutiveEq::isGNF()
constitutiveEq::correct(alpha, gradU)
sparseSolver<Type>::New(...)
sparseSolver<Type>::solve(...)
```

The stubs do not implement RheoTool physics and were not linked into an
executable.  Consequently, this establishes OpenFOAM-9 header/API compatibility
of the custom translation units—including the PLIC/MPLIC scheme-selection,
`nHatf` registration and ungrouped-flux code—but final linking and runtime CFD
validation remain mandatory in a real OpenFOAM 9 + RheoTool OF90 environment.

Compilation records:

```text
library_header_compile_PLIC_MPLIC.log
solver_header_compile_PLIC_MPLIC.log
```
