# Source provenance

The port was prepared from the user-supplied archives and papers listed below.
Hashes make the comparison basis reproducible.

```text
e6a993753d41aaac545e9f62e944ce74f047516c96ca6e45fcf7cfe5eda1169f  rheoMultiFluidInterFoamP.zip
135a89eb7e2b7f0b66225e97c60c6fba49d9979dc32737d9de8f8206861cdecc  rheoMultiFluidInterFoam-main(3).zip
8a3eac19cd9804c226f4fc44fada70c5179a4da6dd07f9d36d6a441f3eab52a8  OpenFOAM-9-master(1).zip
8ee83af49f4aeb1cbed1594d0235e674b286d3173c03591f129c15b10ac2bd3b  OpenFOAM-7-master(1).zip
be8923531fa398d077a5970d106a25c609d5adbf3f7325a76450c7a9160f5c19  2022 solver paper PDF
eb1a2b4859e1536890e59fffac6d28258312316d8db0327cd15c859fff11bb50  2025 wetting paper PDF
```

External source-level API checks used the public official RheoTool repository,
specifically its `of90` implementation.  The OF90 source is a build dependency
and is not redistributed in this package.

## Derivation lineage

```text
OpenFOAM-9 multiphaseInterFoam
    + uploaded multiFluid/rheoMultiFluid interface and algorithm changes
    + uploaded physical-pressure P formulation
    + official RheoTool OF90 interfaces
    + GNF stress-assembly correction
    = rheoMultiFluidInterFoamP_OF9
```
