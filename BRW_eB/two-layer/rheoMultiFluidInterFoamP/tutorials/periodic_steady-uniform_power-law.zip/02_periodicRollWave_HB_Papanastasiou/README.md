        # 02_periodicRollWave_HB_Papanastasiou

        **Purpose:** Papanastasiou-regularized Bingham/Herschel-Bulkley roll-wave starter with a localized depth perturbation.

        This is a reconstructed OpenFOAM Foundation 7 development case for
        `rheoMultiFluidInterFoamP`.  It is not an author-supplied tutorial and
        has not been executed in the packaging environment.

        ## Geometry and forcing

        | Quantity | Value |
        |---|---:|
        | Domain | 0.4 x 0.03 x 0.001 m |
        | Mesh | 400 x 90 x 1 |
        | Phase interfaces | 0.01 m |
        | sin(theta) | 0.06 |
        | g | (0.5886, -9.79232607913, 0) m/s^2 |
        | Localized perturbation | x=[0.18,0.22] m, height=0.0106666666667 m |

        ## Phases

        | Phase | Active RheoTool model | rho (kg/m3) | outer nu (m2/s) |
        |---|---|---:|---:|
        | `mud` | HerschelBulkley | 1200 | 4.16666666667e-05 |
| `air` | Newtonian | 1 | 1.5e-05 |

        ## Notes

        - Ideal-Bingham yielded depth used for initialization = 0.00716842224487 m.
- Ideal-Bingham plug velocity used for initialization = 0.362951555103 m/s.
- The initial profile is an ideal-Bingham normal-flow profile; the solved law is its Papanastasiou regularization.
- This is a development starter, not a validated Liu-Mei benchmark.

        ## Run

        ```bash
        ./Allrun
        ```

        Inspect at minimum:

        - phase-volume conservation and alpha bounds;
        - mass flux through both cyclic halves;
        - continuity errors;
        - pressure, velocity and interface continuity at the periodic join;
        - apparent-viscosity and stress fields for non-Newtonian phases;
        - sensitivity to `pRefCell`, mesh, time step and initial pressure.
