# rheoMultiFluidInterFoamP — complete OpenFOAM Foundation 7 package

`rheoMultiFluidInterFoamP` is the physical-pressure form of
`rheoMultiFluidInterFoam` for inclined translationally periodic domains. It
solves mechanical pressure `p` and retains gravity explicitly as `+rho*g`, so
streamwise periodic patches may use ordinary `cyclic` conditions.

## Target stack

```text
OpenFOAM Foundation 7
+ customized rheoTool-5.0_of70_plus
+ this solver and support library
```

The upstream solver requires OpenFOAM 7 and incorporates RheoTool for one
constitutive equation per phase. This package keeps that software lineage and
is not intended for OpenFOAM.com releases or Foundation 9/13.

## Main corrections in this edition

1. Generalized-Newtonian stress is assembled once: `divTauS()` supplies its
   complete apparent-viscosity stress; `tau()` is added only for differential
   non-GNF models.
2. `HerschelBulkleySafe` fixes the pure-power-law exact-zero-shear startup
   limit without modifying the installed RheoTool source.
3. Interface compression uses the published phase normal; VOF smoothing is
   limited to curvature evaluation.
4. Physical and phase-specific surface tensions are checked against
   `sigma_ij = Sigma_i + Sigma_j`; `sigmasPh` can be generated automatically.
5. The physical-pressure sign is `+rho*g`, and the pressure correction has a
   guarded SIMPLEC reciprocal diagonal.
6. Phase density and rheology density must agree; runtime dictionary rereads
   reconstruct both runtime-selected model objects.
7. The package includes complete build files, two tutorials, scripts,
   documentation, a source patch, and verification records.

## Quick build

```bash
source /opt/openfoam7/etc/bashrc

export RHEOTOOL_SRC=/path/to/rheoTool-5.0_of70_plus/src/libs
export EIGEN_RHEO=/path/to/Eigen
export PETSC_DIR=/path/to/petsc
export PETSC_ARCH=<petsc-architecture>

./tools/check_environment.sh
./Allwclean
./Allwmake 2>&1 | tee log.Allwmake
```

Expected products:

```text
$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP.so
$FOAM_USER_APPBIN/rheoMultiFluidInterFoamP
```

Start with `docs/BUILD_AND_RUN.md`, then run
`tutorials/T01_periodicNormalFlowPowerLaw`.

## Verification boundary

The exact packaged source compiled to five object files against the uploaded
OpenFOAM 7 and customized RheoTool headers: four custom-library translation
units and the main solver translation unit. Static and packaging audits also
pass. The package was not finally linked or CFD-run in the packaging
environment. Local linking,
`ldd`, mesh checks, and the staged numerical acceptance tests remain required.
See `docs/VERIFICATION_STATUS.md`.
