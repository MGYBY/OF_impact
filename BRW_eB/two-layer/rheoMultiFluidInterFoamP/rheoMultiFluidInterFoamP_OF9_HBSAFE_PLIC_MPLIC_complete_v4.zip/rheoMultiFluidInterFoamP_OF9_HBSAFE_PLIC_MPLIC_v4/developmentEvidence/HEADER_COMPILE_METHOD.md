# OpenFOAM 9 translation-unit compilation method

The package was checked without linking against a compiled OpenFOAM/RheoTool
installation.

## OpenFOAM side

The exact packaged C++ files were compiled to relocatable object files with the
actual headers from the uploaded OpenFOAM Foundation 9 source tree.

## RheoTool side

A compiled official RheoTool OF90 installation was unavailable.  Minimal
**declaration-only** headers were used for the external interfaces called by the
package:

```text
constitutiveEq
thermoFunction
sparseSolver
```

Their signatures were cross-checked against the official OF90 source.  In
particular:

```cpp
correct
(
    const volScalarField* alpha = nullptr,
    const volTensorField* gradU = nullptr
);
```

and the phase-weighted `divTauS(U,alpha)`/`isGNF()` semantics were retained.
No stub function body was linked and no stub header is distributed in the
release.

## Exact translation units

```text
multiphaseMixture/phase/phase.C
multiphaseMixture/alphaContactAngle/alphaContactAngleFvPatchScalarField.C
multiphaseMixture/constitutiveEqs/HerschelBulkleySafe/HerschelBulkleySafe.C
multiphaseMixture/multiphaseMixture.C
rheoMultiFluidInterFoamP.C
```

Results:

```text
of9_v4_library_translation_units.log
of9_v4_solver_translation_unit.log
```

This verifies source/header compatibility.  It does not prove final library
linking, runtime selection, or CFD correctness; those remain local acceptance
tests in a complete OF9 + RheoTool OF90 environment.
