# Optional legacy Herschel–Bulkley patch

The solver package already includes the independent runtime model
`HerschelBulkleySafe`; no RheoTool source modification is needed when that
model name is used.

This directory is only for old cases that must retain
`type HerschelBulkley`.  The replacement removes the extra `1e-8/s`
denominator offset in the unregularised branch.  The installer creates a
timestamped backup and rebuilds `libconstitutiveEquations`.

```bash
export RHEOTOOL_SRC=/path/to/rheoTool-5.0_of70_plus/src/libs
./install_patch.sh
```
