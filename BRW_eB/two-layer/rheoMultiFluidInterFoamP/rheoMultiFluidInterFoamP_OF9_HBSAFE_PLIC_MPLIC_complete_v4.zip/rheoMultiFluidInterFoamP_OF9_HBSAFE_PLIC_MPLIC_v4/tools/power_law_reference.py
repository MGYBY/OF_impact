#!/usr/bin/env python3
"""Analytical steady-uniform power-law film reference values."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Inputs:
    rho: float = 1202.0
    gx: float = 0.5886
    consistency: float = 1.38
    n: float = 0.2
    depth: float = 0.00602890842


def reference(values: Inputs) -> tuple[float, float]:
    common = (values.rho*values.gx/values.consistency)**(1.0/values.n)
    depth_factor = values.depth**((values.n + 1.0)/values.n)
    mean = values.n/(2.0*values.n + 1.0)*common*depth_factor
    maximum = values.n/(values.n + 1.0)*common*depth_factor
    return mean, maximum


def main() -> None:
    values = Inputs()
    mean, maximum = reference(values)
    print("steady-uniform power-law film")
    print(f"rho        = {values.rho:.12g} kg/m3")
    print(f"gx         = {values.gx:.12g} m/s2")
    print(f"K          = {values.consistency:.12g} Pa s^n")
    print(f"n          = {values.n:.12g}")
    print(f"H          = {values.depth:.12g} m")
    print(f"mean U     = {mean:.12f} m/s")
    print(f"maximum U  = {maximum:.12f} m/s")
    print(f"Umax/Umean = {maximum/mean:.12f}")


if __name__ == "__main__":
    main()
