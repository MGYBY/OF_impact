# Translation-unit header compilation method

The custom source files were compiled as C++14 relocatable objects against the
headers from the uploaded `OpenFOAM-9-master(1).zip` source tree.

Compiled translation units:

```text
multiphaseMixture/phase/phase.C
multiphaseMixture/alphaContactAngle/alphaContactAngleFvPatchScalarField.C
multiphaseMixture/multiphaseMixture.C
rheoMultiFluidInterFoamP.C
```

A complete compiled RheoTool OF90 installation was not available in the
packaging runtime.  Two minimal declaration-only headers were therefore used
for the compilation gate:

```text
constitutiveEq.H
sparseMatrixSolvers.H
```

They contain only the OF90 method signatures called by this port.  The
signatures were checked against the official OF90 source, including:

```text
constitutiveEq::New(...)
constitutiveEq::tau()
constitutiveEq::tauTotal()
constitutiveEq::rho()
constitutiveEq::divTauS(U, alpha)
constitutiveEq::isGNF()
constitutiveEq::correct(alpha, gradU)
sparseSolver<Type>::New(...)
sparseSolver<Type>::solve(...)
```

The stubs do not implement or emulate RheoTool physics and were not linked into
an executable.  Consequently this test establishes OpenFOAM-9 header/API
compatibility of the custom translation units, but final linking and runtime
validation remain mandatory in a real OpenFOAM 9 + RheoTool OF90 environment.
