# Known limitations

## Build and runtime

- Final linking and CFD execution were not possible in the packaging runtime.
- The package requires official RheoTool OF90.  OF70 and customized OF70+
  headers are incompatible with the OF9 `correct(alpha, gradU)` API.
- PETSc/HYPRE/Eigen must use a compiler and MPI stack compatible with the
  active OpenFOAM 9 build.

## `HerschelBulkleySafe`

- It is a viscosity-regularized generalized-Newtonian model, not an exact
  sharp-yield variational formulation.
- `eta0` changes the low-shear material response and must be varied in a
  sensitivity study.
- Increasing Papanastasiou `m` sharpens the yield approximation but generally
  increases numerical stiffness.
- The official OF90 and Safe classes should agree for the unregularized
  pure-power-law limit; the principal numerical difference is in the
  regularized very-small-shear branch and the added validation/diagnostics.
- The transported `tau()` field remains zero by design for a GNF.  The full
  stress comes from `eta()` through `divTauS(U,alpha)`.
- Material parameters are selected at construction; restart the solver after
  changing model type or coefficients.

## Physical-pressure formulation

- Physical `p` is continuously equivalent to the `p_rgh` formulation but need
  not preserve hydrostatic balance identically at the discrete level.
- Static-column and capillary-pressure tests are mandatory before using this
  formulation in gravity/capillary equilibrium problems.
- Pressure is defined up to an additive constant; results must not depend on
  the valid `pRefCell` choice.

## Geometric VOF

- The OF9 PLIC-family compatibility layer reconstructs each phase fraction
  independently and then applies the multiphase flux-sum limiter.
- For three or more phases, it is not claimed to be a fully coupled
  multi-material geometric reconstruction at triple junctions.
- PLIC/MPLIC may only be selected on `div(phi,alpha)`, not on the already
  compressive `div(phirb,alpha)` flux.
- Contact-angle behavior with the temporary phase-specific `nHatf` requires a
  dedicated wall/contact-line regression.

## Tutorials

- The supplied periodic cases are smoke/regression cases, not author-supplied
  quantitative validation decks.
- Their initial liquid velocity is uniform rather than the exact vertical
  power-law profile, so startup transients are expected.
- The long-domain nonlinear roll-wave, parallel, and mesh-convergence studies
  remain local scientific tasks.
