/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2021 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of OpenFOAM.

    OpenFOAM is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    OpenFOAM is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
    FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
    for more details.

    You should have received a copy of the GNU General Public License
    along with OpenFOAM.  If not, see <http://www.gnu.org/licenses/>.

\*---------------------------------------------------------------------------*/

#include "multiphaseMixture.H"
#include "alphaContactAngleFvPatchScalarField.H"
#include "unitConversion.H"
#include "Time.H"
#include "subCycle.H"
#include "MULES.H"
#include "surfaceInterpolate.H"
#include "fvcGrad.H"
#include "fvcSnGrad.H"
#include "fvcDiv.H"
#include "fvcFlux.H"


// * * * * * * * * * * * * * Private Member Functions  * * * * * * * * * * * //



void Foam::multiphaseMixture::validateSigmaDecomposition() const
{
    if (!lookupOrDefault<Switch>("checkSigmaDecomposition", true))
    {
        return;
    }

    const scalar tolerance = lookupOrDefault<scalar>
    (
        "sigmaDecompositionTolerance",
        1e-10
    );

    forAllConstIter(PtrDictionary<phase>, phases_, iter1)
    {
        const phase& alpha1 = iter1();

        const sigmaTable::const_iterator sigmaPh1 =
            sigmasPh_.find(interfacePair(alpha1, alpha1));

        if (sigmaPh1 == sigmasPh_.end())
        {
            FatalErrorInFunction
                << "Cannot find phase-specific coefficient "
                << interfacePair(alpha1, alpha1) << " in sigmasPh"
                << exit(FatalError);
        }

        PtrDictionary<phase>::const_iterator iter2 = iter1;
        ++iter2;

        for (; iter2 != phases_.end(); ++iter2)
        {
            const phase& alpha2 = iter2();

            const sigmaTable::const_iterator sigmaPair =
                sigmas_.find(interfacePair(alpha1, alpha2));

            const sigmaTable::const_iterator sigmaPh2 =
                sigmasPh_.find(interfacePair(alpha2, alpha2));

            if (sigmaPair == sigmas_.end())
            {
                FatalErrorInFunction
                    << "Cannot find pairwise surface tension "
                    << interfacePair(alpha1, alpha2) << " in sigmas"
                    << exit(FatalError);
            }

            if (sigmaPh2 == sigmasPh_.end())
            {
                FatalErrorInFunction
                    << "Cannot find phase-specific coefficient "
                    << interfacePair(alpha2, alpha2) << " in sigmasPh"
                    << exit(FatalError);
            }

            const scalar reconstructed = sigmaPh1() + sigmaPh2();
            const scalar scale = max
            (
                max(mag(sigmaPair()), mag(reconstructed)),
                SMALL
            );

            if (mag(reconstructed - sigmaPair()) > tolerance*scale)
            {
                FatalErrorInFunction
                    << "Inconsistent surface-tension decomposition for "
                    << interfacePair(alpha1, alpha2) << nl
                    << "    sigma_ij = " << sigmaPair() << nl
                    << "    Sigma_i + Sigma_j = " << reconstructed << nl
                    << "Set sigmasPh so that sigma_ij = Sigma_i + Sigma_j, "
                       "or disable this check explicitly with "
                       "checkSigmaDecomposition false."
                    << exit(FatalError);
            }
        }
    }
}


void Foam::multiphaseMixture::calcAlphas()
{
    scalar level = 0.0;
    alphas_ == 0.0;

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        alphas_ += level*iter();
        level += 1.0;
    }
}


// * * * * * * * * * * * * * * * * Constructors  * * * * * * * * * * * * * * //

Foam::multiphaseMixture::multiphaseMixture
(
    const volVectorField& U,
    const surfaceScalarField& phi
)
:
    IOdictionary
    (
        IOobject
        (
            "transportProperties",
            U.time().constant(),
            U.db(),
            IOobject::MUST_READ_IF_MODIFIED,
            IOobject::NO_WRITE
        )
    ),

    phases_(lookup("phases"), phase::iNew(U, phi)),

    mesh_(U.mesh()),
    U_(U),
    phi_(phi),

    rhoPhi_
    (
        IOobject
        (
            "rhoPhi",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        mesh_,
        dimensionedScalar(dimMass/dimTime, 0)
    ),

    alphas_
    (
        IOobject
        (
            "alphas",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_,
        dimensionedScalar(dimless, 0)
    ),

    nu_
    (
        IOobject
        (
            "nu",
            mesh_.time().timeName(),
            mesh_
        ),
        mu()/rho()
    ),

    sigmas_(lookup("sigmas")),
    dimSigma_(1, 0, -2, 0, 0),

    sigmasPh_(lookup("sigmasPh")),
    dimSigmaPh_(1, 0, -2, 0, 0),

    tauMF_
    (
        IOobject
        (
            "tauMF",
            U.time().timeName(),
            U.mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        U.mesh(),
        dimensionedSymmTensor
        (
            "zero",
            dimensionSet(1, -1, -2, 0, 0, 0, 0),
            symmTensor::zero
        ),
        calculatedFvPatchScalarField::typeName
    ),

    deltaN_
    (
        "deltaN",
        1e-8/pow(average(mesh_.V()), 1.0/3.0)
    )
{
    validateSigmaDecomposition();
    calcAlphas();
    alphas_.write();
}


// * * * * * * * * * * * * * * Member Functions  * * * * * * * * * * * * * * //

Foam::tmp<Foam::fvVectorMatrix>
Foam::multiphaseMixture::divTauMF(volVectorField& U)
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    volScalarField boundedAlpha
    (
        IOobject
        (
            "boundedAlphaStress",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE,
            false
        ),
        min(max(iter(), scalar(0)), scalar(1))
    );

    tmp<fvVectorMatrix> tDivTau = iter().divTauS(U, boundedAlpha);
    fvVectorMatrix& divTau = tDivTau.ref();

    tauMF_ = dimensionedSymmTensor
    (
        "zero",
        tauMF_.dimensions(),
        symmTensor::zero
    );

    // divTauS() is already the complete stress divergence for a GNF.
    // tau() is therefore added only for differential/non-GNF equations.
    if (!iter().isGNF())
    {
        tauMF_ += iter().tau()*boundedAlpha;
    }

    for (++iter; iter != phases_.end(); ++iter)
    {
        boundedAlpha = min(max(iter(), scalar(0)), scalar(1));
        divTau += iter().divTauS(U, boundedAlpha);

        if (!iter().isGNF())
        {
            tauMF_ += iter().tau()*boundedAlpha;
        }
    }

    if (U.time().outputTime())
    {
        tauMF_.write();
    }

    return tDivTau + fvc::div(tauMF_, "div(Sum(tau))");
}


Foam::tmp<Foam::volSymmTensorField>
Foam::multiphaseMixture::tauTotalMF() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    volScalarField boundedAlpha
    (
        IOobject
        (
            "boundedAlphaTauTotal",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE,
            false
        ),
        min(max(iter(), scalar(0)), scalar(1))
    );

    tmp<volSymmTensorField> tTau = iter().tauTotal()*boundedAlpha;
    volSymmTensorField& tau = tTau.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        boundedAlpha = min(max(iter(), scalar(0)), scalar(1));
        tau += iter().tauTotal()*boundedAlpha;
    }

    return tTau;
}


Foam::tmp<Foam::volScalarField>
Foam::multiphaseMixture::rho() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<volScalarField> trho = iter()*iter().rho();
    volScalarField& rho = trho.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        rho += iter()*iter().rho();
    }

    return trho;
}


Foam::tmp<Foam::scalarField>
Foam::multiphaseMixture::rho(const label patchi) const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<scalarField> trho = iter().boundaryField()[patchi]*iter().rho().value();
    scalarField& rho = trho.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        rho += iter().boundaryField()[patchi]*iter().rho().value();
    }

    return trho;
}


Foam::tmp<Foam::volScalarField>
Foam::multiphaseMixture::mu() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<volScalarField> tmu = iter()*iter().rho()*iter().nu();
    volScalarField& mu = tmu.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        mu += iter()*iter().rho()*iter().nu();
    }

    return tmu;
}


Foam::tmp<Foam::scalarField>
Foam::multiphaseMixture::mu(const label patchi) const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<scalarField> tmu =
        iter().boundaryField()[patchi]
       *iter().rho().value()
       *iter().nu(patchi);
    scalarField& mu = tmu.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        mu +=
            iter().boundaryField()[patchi]
           *iter().rho().value()
           *iter().nu(patchi);
    }

    return tmu;
}


Foam::tmp<Foam::surfaceScalarField>
Foam::multiphaseMixture::muf() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<surfaceScalarField> tmuf =
        fvc::interpolate(iter())*iter().rho()*fvc::interpolate(iter().nu());
    surfaceScalarField& muf = tmuf.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        muf +=
            fvc::interpolate(iter())*iter().rho()*fvc::interpolate(iter().nu());
    }

    return tmuf;
}


Foam::tmp<Foam::volScalarField>
Foam::multiphaseMixture::nu() const
{
    return nu_;
}


Foam::tmp<Foam::scalarField>
Foam::multiphaseMixture::nu(const label patchi) const
{
    return nu_.boundaryField()[patchi];
}


Foam::tmp<Foam::surfaceScalarField>
Foam::multiphaseMixture::nuf() const
{
    return muf()/fvc::interpolate(rho());
}


void Foam::multiphaseMixture::smoothen(volScalarField& alphaSmooth) const
{
    const dictionary& alphaControls = mesh_.solverDict("alpha");

    const label nIterations = alphaControls.lookupOrDefault<label>
    (
        "numSmoothingIterations",
        alphaControls.lookupOrDefault<label>("numSmoothingIterations_", 0)
    );

    const Switch smoothCurvature = alphaControls.lookupOrDefault<Switch>
    (
        "smoothCurvature",
        alphaControls.lookupOrDefault<Switch>("smoothKn_", false)
    );

    if (!smoothCurvature || nIterations <= 0)
    {
        return;
    }

    const volScalarField faceAreaSum
    (
        IOobject
        (
            "faceAreaSum",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE,
            false
        ),
        fvc::surfaceSum(mesh_.magSf())
    );

    for (label iteration = 0; iteration < nIterations; ++iteration)
    {
        alphaSmooth =
            fvc::surfaceSum(fvc::interpolate(alphaSmooth)*mesh_.magSf())
           /faceAreaSum;

        alphaSmooth.correctBoundaryConditions();
    }
}


Foam::tmp<Foam::surfaceScalarField>
Foam::multiphaseMixture::surfaceTensionForce() const
{
    tmp<surfaceScalarField> tStf
    (
        surfaceScalarField::New
        (
            "surfaceTensionForce",
            mesh_,
            dimensionedScalar(dimensionSet(1, -2, -2, 0, 0), 0)
        )
    );

    surfaceScalarField& stf = tStf.ref();

    // Interfacial-tension coefficient decomposition:
    // sigma_ij = Sigma_i + Sigma_j.  Sigma_i is stored as (phase phase).
    forAllConstIter(PtrDictionary<phase>, phases_, iter)
    {
        const phase& alpha = iter();

        const sigmaTable::const_iterator sigmaPh =
            sigmasPh_.find(interfacePair(alpha, alpha));

        if (sigmaPh == sigmasPh_.end())
        {
            FatalErrorInFunction
                << "Cannot find phase-specific surface-tension coefficient "
                << interfacePair(alpha, alpha) << " in sigmasPh"
                << exit(FatalError);
        }

        stf +=
            dimensionedScalar(dimSigmaPh_, sigmaPh())
           *fvc::interpolate(Kn(alpha))
           *fvc::snGrad(alpha);
    }

    return tStf;
}


void Foam::multiphaseMixture::solve()
{
    const Time& runTime = mesh_.time();

    volScalarField& alpha = phases_.first();

    const dictionary& alphaControls = mesh_.solverDict("alpha");
    label nAlphaSubCycles(alphaControls.lookup<label>("nAlphaSubCycles"));
    scalar cAlpha(alphaControls.lookup<scalar>("cAlpha"));

    if (nAlphaSubCycles > 1)
    {
        surfaceScalarField rhoPhiSum
        (
            IOobject
            (
                "rhoPhiSum",
                runTime.timeName(),
                mesh_
            ),
            mesh_,
            dimensionedScalar(rhoPhi_.dimensions(), 0)
        );

        dimensionedScalar totalDeltaT = runTime.deltaT();

        for
        (
            subCycle<volScalarField> alphaSubCycle(alpha, nAlphaSubCycles);
            !(++alphaSubCycle).end();
        )
        {
            solveAlphas(cAlpha);
            rhoPhiSum += (runTime.deltaT()/totalDeltaT)*rhoPhi_;
        }

        rhoPhi_ = rhoPhiSum;
    }
    else
    {
        solveAlphas(cAlpha);
    }

    // The phase fractions are advanced first; then each RheoTool model is
    // corrected before the common momentum equation is assembled.
    correct();

    // Retain the stock kinematicTransportModel field for API compatibility.
    // The active laminar stress in the solver is assembled by divTauMF().
    nu_ = mu()/rho();
}


void Foam::multiphaseMixture::correct()
{
    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        iter().correct();
    }
}


Foam::tmp<Foam::surfaceVectorField> Foam::multiphaseMixture::nHatfv
(
    const volScalarField& alpha1,
    const volScalarField& alpha2
) const
{
    /*
    // Cell gradient of alpha
    volVectorField gradAlpha =
        alpha2*fvc::grad(alpha1) - alpha1*fvc::grad(alpha2);

    // Interpolated face-gradient of alpha
    surfaceVectorField gradAlphaf = fvc::interpolate(gradAlpha);
    */

    surfaceVectorField gradAlphaf
    (
        fvc::interpolate(alpha2)*fvc::interpolate(fvc::grad(alpha1))
      - fvc::interpolate(alpha1)*fvc::interpolate(fvc::grad(alpha2))
    );

    // Face unit interface normal
    return gradAlphaf/(mag(gradAlphaf) + deltaN_);
}


Foam::tmp<Foam::surfaceScalarField> Foam::multiphaseMixture::nHatf
(
    const volScalarField& alpha1,
    const volScalarField& alpha2
) const
{
    // Face unit interface normal flux
    return nHatfv(alpha1, alpha2) & mesh_.Sf();
}


Foam::tmp<Foam::surfaceVectorField> Foam::multiphaseMixture::nHatfvn
(
    const volScalarField& alpha,
    const bool smoothAlpha
) const
{
    // The 2022 formulation uses the smoothed VOF field only for curvature.
    // Interface compression must remain based on the transported alpha field.
    volScalarField alphaForNormal
    (
        IOobject
        (
            "alphaForNormal." + alpha.name(),
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE,
            false
        ),
        alpha
    );

    if (smoothAlpha)
    {
        smoothen(alphaForNormal);
    }

    const surfaceVectorField gradAlphaf
    (
        fvc::interpolate(fvc::grad(alphaForNormal))
    );

    return gradAlphaf/(mag(gradAlphaf) + deltaN_);
}


Foam::tmp<Foam::surfaceScalarField> Foam::multiphaseMixture::nHatfn
(
    const volScalarField& alpha
) const
{
    // Raw transported alpha: smoothing is deliberately not used by
    // the artificial compression velocity.
    return nHatfvn(alpha, false) & mesh_.Sf();
}


void Foam::multiphaseMixture::correctContactAngle
(
    const phase& alpha1,
    const phase& alpha2,
    surfaceVectorField::Boundary& nHatb
) const
{
    const volScalarField::Boundary& a1bf = alpha1.boundaryField();
    const volScalarField::Boundary& a2bf = alpha2.boundaryField();

    const fvBoundaryMesh& boundary = mesh_.boundary();

    forAll(boundary, patchi)
    {
        if
        (
            isA<alphaContactAngleFvPatchScalarField>(a1bf[patchi])
         || isA<alphaContactAngleFvPatchScalarField>(a2bf[patchi])
        )
        {
            if
            (
                isA<alphaContactAngleFvPatchScalarField>(a1bf[patchi])
             && isA<alphaContactAngleFvPatchScalarField>(a2bf[patchi])
            )
            {
                FatalErrorInFunction
                    << "alphaContactAngle boundary condition "
                       "specified on patch " << boundary[patchi].name()
                    << " for both " << alpha1.name() << " and " << alpha2.name()
                    << nl << "which may be inconsistent."
                    << exit(FatalError);
            }

            const alphaContactAngleFvPatchScalarField& acap =
                isA<alphaContactAngleFvPatchScalarField>(a1bf[patchi])
              ? refCast<const alphaContactAngleFvPatchScalarField>(a1bf[patchi])
              : refCast<const alphaContactAngleFvPatchScalarField>(a2bf[patchi])
              ;

            vectorField& nHatPatch = nHatb[patchi];

            const vectorField AfHatPatch
            (
                mesh_.Sf().boundaryField()[patchi]
               /mesh_.magSf().boundaryField()[patchi]
            );

            alphaContactAngleFvPatchScalarField::thetaPropsTable::
                const_iterator tp =
                acap.thetaProps().find(interfacePair(alpha1, alpha2));

            if (tp == acap.thetaProps().end())
            {
                FatalErrorInFunction
                    << "Cannot find interface " << interfacePair(alpha1, alpha2)
                    << "\n    in table of theta properties for patch "
                    << acap.patch().name()
                    << exit(FatalError);
            }

            const bool matched = (tp.key().first() == alpha1.name());

            const scalar theta0 = degToRad(tp().theta0(matched));

            scalarField theta(boundary[patchi].size(), theta0);

            const scalar uTheta = tp().uTheta();

            // Calculate the dynamic contact angle if required
            if (uTheta > small)
            {
                const scalar thetaA = degToRad(tp().thetaA(matched));
                const scalar thetaR = degToRad(tp().thetaR(matched));

                // Calculated the component of the velocity parallel to the wall
                vectorField Uwall
                (
                    U_.boundaryField()[patchi].patchInternalField()
                  - U_.boundaryField()[patchi]
                );
                Uwall -= (AfHatPatch & Uwall)*AfHatPatch;

                // Find the direction of the interface parallel to the wall
                vectorField nWall
                (
                    nHatPatch - (AfHatPatch & nHatPatch)*AfHatPatch
                );

                // Normalise nWall
                nWall /= (mag(nWall) + small);

                // Calculate Uwall resolved normal to the interface parallel to
                // the interface
                const scalarField uwall(nWall & Uwall);

                theta += (thetaA - thetaR)*tanh(uwall/uTheta);
            }


            // Reset nHatPatch to correspond to the contact angle

            const scalarField a12(nHatPatch & AfHatPatch);

            const scalarField b1(cos(theta));

            scalarField b2(nHatPatch.size());

            forAll(b2, facei)
            {
                b2[facei] = cos(acos(a12[facei]) - theta[facei]);
            }

            const scalarField det(1.0 - a12*a12);

            const scalarField a((b1 - a12*b2)/det);
            const scalarField b((b2 - a12*b1)/det);

            nHatPatch = a*AfHatPatch + b*nHatPatch;

            nHatPatch /= (mag(nHatPatch) + deltaN_.value());
        }
    }
}


Foam::tmp<Foam::volScalarField> Foam::multiphaseMixture::K
(
    const phase& alpha1,
    const phase& alpha2
) const
{
    tmp<surfaceVectorField> tnHatfv = nHatfv(alpha1, alpha2);

    correctContactAngle(alpha1, alpha2, tnHatfv.ref().boundaryFieldRef());

    // Simple expression for curvature
    return -fvc::div(tnHatfv & mesh_.Sf());
}


Foam::tmp<Foam::volScalarField> Foam::multiphaseMixture::Kn
(
    const phase& alpha
) const
{
    // Curvature alone may use the optional Laplacian-smoothed alpha.
    tmp<surfaceVectorField> tNHat = nHatfvn(alpha, true);
    return -fvc::div(tNHat & mesh_.Sf());
}


Foam::tmp<Foam::volScalarField>
Foam::multiphaseMixture::nearInterface() const
{
    tmp<volScalarField> tnearInt
    (
        volScalarField::New
        (
            "nearInterface",
            mesh_,
            dimensionedScalar(dimless, 0)
        )
    );

    forAllConstIter(PtrDictionary<phase>, phases_, iter)
    {
        tnearInt.ref() =
            max(tnearInt(), pos0(iter() - 0.01)*pos0(0.99 - iter()));
    }

    return tnearInt;
}


void Foam::multiphaseMixture::solveAlphas
(
    const scalar cAlpha
)
{
    static label nSolves=-1;
    nSolves++;

    word alphaScheme("div(phi,alpha)");
    word alpharScheme("div(phirb,alpha)");

    surfaceScalarField phic(mag(phi_/mesh_.magSf()));
    phic = min(cAlpha*phic, max(phic));

    UPtrList<const volScalarField> alphas(phases_.size());
    PtrList<surfaceScalarField> alphaPhis(phases_.size());
    int phasei = 0;

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        const phase& alpha = iter();

        alphas.set(phasei, &alpha);

        alphaPhis.set
        (
            phasei,
            new surfaceScalarField
            (
                "phi" + alpha.name() + "Corr",
                fvc::flux
                (
                    phi_,
                    alpha,
                    alphaScheme
                )
            )
        );

        surfaceScalarField& alphaPhi = alphaPhis[phasei];

        forAllIter(PtrDictionary<phase>, phases_, iter2)
        {
            phase& alpha2 = iter2();

            if (&alpha2 == &alpha) continue;

            surfaceScalarField phir(phic*nHatfn(alpha));

            alphaPhi += fvc::flux
            (
                -fvc::flux(-phir, alpha2, alpharScheme),
                alpha,
                alpharScheme
            );
        }

        // Limit alphaPhi for each phase
        MULES::limit
        (
            1.0/mesh_.time().deltaT().value(),
            geometricOneField(),
            alpha,
            phi_,
            alphaPhi,
            zeroField(),
            zeroField(),
            oneField(),
            zeroField(),
            false
        );

        phasei++;
    }

    MULES::limitSum(alphas, alphaPhis, phi_);

    rhoPhi_ = dimensionedScalar(dimensionSet(1, 0, -1, 0, 0), 0);

    volScalarField sumAlpha
    (
        IOobject
        (
            "sumAlpha",
            mesh_.time().timeName(),
            mesh_
        ),
        mesh_,
        dimensionedScalar(dimless, 0)
    );

    phasei = 0;

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        phase& alpha = iter();
        surfaceScalarField& alphaPhi = alphaPhis[phasei];

        MULES::explicitSolve
        (
            geometricOneField(),
            alpha,
            alphaPhi
        );

        rhoPhi_ += alphaPhi*alpha.rho();

        Info<< alpha.name() << " volume fraction, min, max = "
            << alpha.weightedAverage(mesh_.V()).value()
            << ' ' << min(alpha).value()
            << ' ' << max(alpha).value()
            << endl;

        sumAlpha += alpha;

        phasei++;
    }

    Info<< "Phase-sum volume fraction, min, max = "
        << sumAlpha.weightedAverage(mesh_.V()).value()
        << ' ' << min(sumAlpha).value()
        << ' ' << max(sumAlpha).value()
        << endl;

    // Correct the sum of the phase-fractions to avoid 'drift'
    volScalarField sumCorr(1.0 - sumAlpha);
    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        phase& alpha = iter();
        alpha += alpha*sumCorr;
    }

    calcAlphas();
}


bool Foam::multiphaseMixture::read()
{
    if (regIOobject::read())
    {
        bool readOK = true;

        PtrList<entry> phaseData(lookup("phases"));
        label phasei = 0;

        forAllIter(PtrDictionary<phase>, phases_, iter)
        {
            readOK &= iter().read(phaseData[phasei++].dict());
        }

        lookup("sigmas") >> sigmas_;
        lookup("sigmasPh") >> sigmasPh_;
        validateSigmaDecomposition();

        return readOK;
    }
    else
    {
        return false;
    }
}


// ************************************************************************* //
