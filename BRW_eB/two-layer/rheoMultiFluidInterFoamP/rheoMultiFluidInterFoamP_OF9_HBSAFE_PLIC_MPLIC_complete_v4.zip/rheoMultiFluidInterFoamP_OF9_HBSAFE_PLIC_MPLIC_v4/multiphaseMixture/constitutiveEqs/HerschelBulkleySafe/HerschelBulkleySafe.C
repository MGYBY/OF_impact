/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | OpenFOAM Foundation 9 / RheoTool OF90
    \\  /    A nd           |
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is part of rheoMultiFluidInterFoamP and is distributed under
    the GNU General Public License v3 or later.

\*---------------------------------------------------------------------------*/

#include "HerschelBulkleySafe.H"
#include "addToRunTimeSelectionTable.H"

#include <cmath>

namespace Foam
{
namespace constitutiveEqs
{
    defineTypeNameAndDebug(HerschelBulkleySafe, 0);

    addToRunTimeSelectionTable
    (
        constitutiveEq,
        HerschelBulkleySafe,
        dictionary
    );
}
}


void Foam::constitutiveEqs::HerschelBulkleySafe::validateParameters
(
    const dictionary& dict
) const
{
    if (rho_.dimensions() != dimDensity)
    {
        FatalIOErrorInFunction(dict)
            << "rho must have dimensions " << dimDensity
            << ", but received " << rho_.dimensions()
            << exit(FatalIOError);
    }

    if (tau0_.dimensions() != dimPressure)
    {
        FatalIOErrorInFunction(dict)
            << "tau0 must have dimensions " << dimPressure
            << ", but received " << tau0_.dimensions()
            << exit(FatalIOError);
    }

    if (eta0_.dimensions() != dimDynamicViscosity)
    {
        FatalIOErrorInFunction(dict)
            << "eta0 must have dimensions " << dimDynamicViscosity
            << ", but received " << eta0_.dimensions()
            << exit(FatalIOError);
    }

    // RheoTool OF90 intentionally reads k with dynamic-viscosity dimensions
    // and inserts unit-time factors in the field expression for n != 1.
    if (k_.dimensions() != dimDynamicViscosity)
    {
        FatalIOErrorInFunction(dict)
            << "k must use the RheoTool OF90 dimensions "
            << dimDynamicViscosity << ", but received " << k_.dimensions()
            << exit(FatalIOError);
    }

    if (n_.dimensions() != dimless)
    {
        FatalIOErrorInFunction(dict)
            << "n must be dimensionless, but received " << n_.dimensions()
            << exit(FatalIOError);
    }

    if (reg_ && m_.dimensions() != dimTime)
    {
        FatalIOErrorInFunction(dict)
            << "m must have time dimensions " << dimTime
            << " when PapanastasiouRegularization is enabled, but received "
            << m_.dimensions() << exit(FatalIOError);
    }

    if (rho_.value() <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "rho must be positive" << exit(FatalIOError);
    }

    if (eta0_.value() <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "eta0 must be positive" << exit(FatalIOError);
    }

    if (tau0_.value() < 0)
    {
        FatalIOErrorInFunction(dict)
            << "tau0 must be non-negative" << exit(FatalIOError);
    }

    if (k_.value() < 0)
    {
        FatalIOErrorInFunction(dict)
            << "k must be non-negative" << exit(FatalIOError);
    }

    if (n_.value() <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "n must be positive" << exit(FatalIOError);
    }

    if (reg_ && m_.value() <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "m must be positive when PapanastasiouRegularization is true"
            << exit(FatalIOError);
    }

    if (tau0_.value() == 0 && k_.value() == 0)
    {
        FatalIOErrorInFunction(dict)
            << "tau0 and k cannot both be zero; that would define a "
            << "zero-stress/zero-viscosity phase" << exit(FatalIOError);
    }
}


Foam::scalar
Foam::constitutiveEqs::HerschelBulkleySafe::apparentViscosity
(
    const scalar gammaDot
) const
{
    const scalar gamma = max(gammaDot, VSMALL);
    const scalar etaCap = eta0_.value();

    scalar eta = 0;

    // Evaluate K*gamma^(n-1) in logarithmic form.  This avoids overflow for
    // strongly shear-thinning fluids at startup while preserving an exact
    // early return when the configured viscosity cap is reached.
    if (k_.value() > 0)
    {
        const scalar logPowerLaw =
            std::log(k_.value())
          + (n_.value() - 1.0)*std::log(gamma);

        const scalar logCap = std::log(etaCap);

        if (logPowerLaw >= logCap)
        {
            return etaCap;
        }

        const scalar etaPowerLaw = std::exp(logPowerLaw);

        if (!std::isfinite(etaPowerLaw) || etaPowerLaw >= etaCap)
        {
            return etaCap;
        }

        eta += etaPowerLaw;
    }

    if (tau0_.value() > 0)
    {
        scalar etaYield = 0;

        if (reg_)
        {
            const scalar x = m_.value()*gamma;

            // -expm1(-x) evaluates 1-exp(-x) accurately for x << 1.
            // Consequently etaYield tends continuously to tau0*m as
            // gamma -> 0, instead of losing the complete yield contribution
            // through catastrophic cancellation.
            etaYield =
                tau0_.value()
               *(-std::expm1(-x))
               /gamma;
        }
        else
        {
            // Test against the remaining cap before dividing by gamma.  This
            // avoids an unnecessary overflow in the ideal-yield branch.
            const scalar remaining = max(etaCap - eta, scalar(0));

            if (tau0_.value() >= remaining*gamma)
            {
                return etaCap;
            }

            etaYield = tau0_.value()/gamma;
        }

        if (!std::isfinite(etaYield) || etaYield >= etaCap - eta)
        {
            return etaCap;
        }

        eta += etaYield;
    }

    return min(etaCap, max(eta, scalar(0)));
}


Foam::constitutiveEqs::HerschelBulkleySafe::HerschelBulkleySafe
(
    const word& name,
    const volVectorField& U,
    const surfaceScalarField& phi,
    const dictionary& dict
)
:
    constitutiveEq(name, U, phi),
    rho_(dict.lookup("rho")),
    reg_(dict.lookup("PapanastasiouRegularization")),
    tau0_(dict.lookup("tau0")),
    eta0_(dict.lookup("eta0")),
    k_(dict.lookup("k")),
    n_(dict.lookup("n")),
    m_
    (
        reg_
      ? dimensionedScalar(dict.lookup("m"))
      : dimensionedScalar("m", dimTime, 1.0)
    ),
    writeShearRate_
    (
        dict.lookupOrDefault<Switch>("writeShearRate", true)
    ),
    writeStress_
    (
        dict.lookupOrDefault<Switch>("writeStress", true)
    ),
    writeSecondInvariant_
    (
        dict.lookupOrDefault<Switch>
        (
            "writeSecondInvariantTauDev",
            true
        )
    ),
    tau_
    (
        IOobject
        (
            "tau" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        U.mesh(),
        dimensionedSymmTensor
        (
            "zero",
            dimPressure,
            symmTensor::zero
        ),
        extrapolatedCalculatedFvPatchField<symmTensor>::typeName
    ),
    eta_
    (
        IOobject
        (
            "eta" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        U.mesh(),
        dimensionedScalar
        (
            "zero",
            dimDynamicViscosity,
            0
        ),
        extrapolatedCalculatedFvPatchField<scalar>::typeName
    ),
    gammaDot_
    (
        IOobject
        (
            "gammaDot" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::NO_READ,
            writeShearRate_ ? IOobject::AUTO_WRITE : IOobject::NO_WRITE
        ),
        U.mesh(),
        dimensionedScalar
        (
            "zero",
            dimless/dimTime,
            0
        ),
        extrapolatedCalculatedFvPatchField<scalar>::typeName
    ),
    tauTotalDiag_
    (
        IOobject
        (
            "tauTotal" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::NO_READ,
            writeStress_ ? IOobject::AUTO_WRITE : IOobject::NO_WRITE
        ),
        U.mesh(),
        dimensionedSymmTensor
        (
            "zero",
            dimPressure,
            symmTensor::zero
        ),
        extrapolatedCalculatedFvPatchField<symmTensor>::typeName
    ),
    IItauD_
    (
        IOobject
        (
            "IItauD" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::NO_READ,
            writeSecondInvariant_
          ? IOobject::AUTO_WRITE
          : IOobject::NO_WRITE
        ),
        U.mesh(),
        dimensionedScalar
        (
            "zero",
            dimPressure,
            0
        ),
        extrapolatedCalculatedFvPatchField<scalar>::typeName
    ),
    thermoEtaPtr_(thermoFunction::New("thermoEta", U.mesh(), dict))
{
    validateParameters(dict);
    correct(nullptr, nullptr);
}


void Foam::constitutiveEqs::HerschelBulkleySafe::correct
(
    const volScalarField* alpha,
    const volTensorField* gradU
)
{
    // alpha is intentionally unused by this local algebraic GNF closure.  It
    // remains part of the OF90 interface and is used by divTauS for weighting.
    (void)alpha;

    gammaDot_ = max
    (
        strainRate(gradU),
        dimensionedScalar("gammaDotMin", dimless/dimTime, VSMALL)
    );

    scalarField& etaCells = eta_.primitiveFieldRef();
    const scalarField& gammaCells = gammaDot_.primitiveField();

    forAll(etaCells, celli)
    {
        etaCells[celli] = apparentViscosity(gammaCells[celli]);
    }

    forAll(eta_.boundaryField(), patchi)
    {
        scalarField& etaPatch = eta_.boundaryFieldRef()[patchi];
        const scalarField& gammaPatch = gammaDot_.boundaryField()[patchi];

        forAll(etaPatch, facei)
        {
            etaPatch[facei] = apparentViscosity(gammaPatch[facei]);
        }
    }

    // Retain official RheoTool OF90 non-isothermal behavior.  The configured
    // eta0 cap applies to the isothermal base law, as in the official model;
    // a thermo multiplier can subsequently rescale eta_.
    thermoEtaPtr_->multiply(eta_);

    tmp<volTensorField> tGradU;
    const volTensorField* gradUPtr = gradU;

    if (gradUPtr == nullptr)
    {
        tGradU = fvc::grad(U());
        gradUPtr = &tGradU();
    }

    tauTotalDiag_ = eta_*
    (
        symm(*gradUPtr + gradUPtr->T())
      - (2.0/3.0)*tr(*gradUPtr)*symmTensor::I
    );

    IItauD_ = mag(dev(tauTotalDiag_))/sqrt(2.0);
}

// ************************************************************************* //
