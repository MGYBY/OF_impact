#!/bin/sh
# Verify that the selected RheoTool source tree exposes the OpenFOAM-9 (OF90)
# constitutive-equation API required by this package.
set -eu

RHEOTOOL_SRC=${1:-${RHEOTOOL_SRC:-${FOAM_USER_SRC:-}/libs/libRheoTool}}
fail=0

say()
{
    printf '%-38s %s\n' "$1" "$2"
}

constitutive="$RHEOTOOL_SRC/constitutiveEquations/lnInclude/constitutiveEq.H"
thermo="$RHEOTOOL_SRC/thermo/lnInclude/thermoFunction.H"
hb="$RHEOTOOL_SRC/constitutiveEquations/constitutiveEqs/GNF/HerschelBulkley/HerschelBulkley.H"

say "RHEOTOOL_SRC" "$RHEOTOOL_SRC"

for path in "$constitutive" "$thermo"; do
    if [ -f "$path" ]; then
        say "found" "$path"
    else
        echo "MISSING: $path" >&2
        fail=1
    fi
done

if [ "$fail" -eq 0 ]; then
    if grep -q 'const volTensorField\* gradU' "$constitutive" \
       && grep -q 'const volScalarField\* alpha' "$constitutive"; then
        say "constitutive correct API" "OF90 pointer-argument signature"
    else
        echo "FAIL: constitutiveEq.H does not expose the OF90 correct(alpha, gradU) API" >&2
        echo "      Do not use a generic OF70/of70_plus header tree with the OF9 package." >&2
        fail=1
    fi

    if grep -q 'divTauS' "$constitutive" && grep -q 'isGNF' "$constitutive"; then
        say "phase-weighted GNF API" "divTauS and isGNF present"
    else
        echo "FAIL: required phase-weighted GNF declarations are absent" >&2
        fail=1
    fi

    if grep -q 'multiply' "$thermo" && grep -q 'volScalarField' "$thermo"; then
        say "thermo viscosity API" "multiply(volScalarField) present"
    else
        echo "FAIL: thermoFunction viscosity multiplier API is absent" >&2
        fail=1
    fi
fi

if [ -f "$hb" ]; then
    if grep -q 'const volTensorField\* gradU' "$hb"; then
        say "official HerschelBulkley" "OF90-compatible header found"
    else
        echo "WARNING: $hb does not look like the official OF90 header" >&2
    fi
else
    say "official HerschelBulkley" "header not found (not fatal for local Safe class)"
fi

if [ "$fail" -eq 0 ]; then
    echo "RheoTool OF90 API/header consistency check passed."
else
    echo "RheoTool OF90 API/header consistency check failed." >&2
fi

exit "$fail"
