# OF9 HBSAFE + PLIC/MPLIC compatibility release

Package identifier:

```text
rheoMultiFluidInterFoamP_OF9_HBSAFE_PLIC_MPLIC_v4
```

Prepared: 2026-08-03

This release supersedes the PLIC/MPLIC v3 package.  It retains the complete
physical-pressure and geometric-VOF compatibility work and adds a package-local
RheoTool OF90 constitutive equation:

```foam
type HerschelBulkleySafe;
```

The new class adds cancellation-safe Papanastasiou evaluation, overflow-safe
strong-shear-thinning evaluation, explicit validation, and optional diagnostic
fields without modifying the installed RheoTool OF90 library.  See:

```text
docs/HERSCHELBULKLEY_SAFE.md
docs/PLIC_MPLIC_COMPATIBILITY.md
CHANGELOG_OF9_PORT.md
```
