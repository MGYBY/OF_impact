/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2019 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is distributed under the GNU General Public License v3 or later.

\*---------------------------------------------------------------------------*/

#include "phase.H"

namespace Foam
{

void phase::validateCompatibilityTransport() const
{
    const word transportType(phaseDict_.lookup("transportModel"));

    if (transportType != "Newtonian")
    {
        FatalErrorInFunction
            << "Phase '" << name_ << "' uses transportModel "
            << transportType << '.' << nl
            << "The phase-level OpenFOAM viscosityModel is a compatibility "
            << "object only.  Set transportModel Newtonian and select the "
            << "active rheology exclusively in parameters/type."
            << exit(FatalError);
    }
}


void phase::validateDensity() const
{
    const dictionary& parameters = phaseDict_.subDict("parameters");
    const dimensionedScalar rheoRho("rho", dimDensity, parameters);

    const scalar tolerance = phaseDict_.lookupOrDefault<scalar>
    (
        "rheologyDensityTolerance",
        1e-12
    );

    const scalar scale = Foam::max
    (
        Foam::max(mag(rho_.value()), mag(rheoRho.value())),
        scalar(1)
    );

    if (mag(rho_.value() - rheoRho.value()) > tolerance*scale)
    {
        FatalErrorInFunction
            << "Inconsistent density entries for phase '" << name_ << "'." << nl
            << "    phase-level rho = " << rho_ << nl
            << "    parameters/rho  = " << rheoRho << nl
            << "The OpenFOAM transport interface and the RheoTool stress "
            << "must use the same density."
            << exit(FatalError);
    }
}


void phase::warnForLegacyHerschelBulkley() const
{
    const dictionary& parameters = phaseDict_.subDict("parameters");
    const word rheologyType(parameters.lookup("type"));

    const Switch warnLegacy = phaseDict_.lookupOrDefault<Switch>
    (
        "warnUnsafeLegacyHerschelBulkley",
        true
    );

    if (warnLegacy && rheologyType == "HerschelBulkley")
    {
        WarningInFunction
            << "Phase '" << name_ << "' selects the legacy bundled "
            << "HerschelBulkley model.  In the unregularised pure power-law "
            << "limit (tau0=0, n<1), that model contains an exact-zero-shear "
            << "startup defect.  Select type HerschelBulkleySafe, or install "
            << "the optional RheoTool patch supplied with this package." << nl;
    }
}


void phase::rebuildViscosityModel()
{
    nuModel_.clear();

    nuModel_.reset
    (
        viscosityModel::New
        (
            IOobject::groupName("nu", name_),
            phaseDict_,
            U_,
            phi_
        ).ptr()
    );
}


void phase::rebuildConstitutiveModel()
{
    // Destroy the existing model first so that its registered fields are
    // removed before a new model creates fields with the same names.
    phaseEqModel_.clear();

    phaseEqModel_.reset
    (
        constitutiveEq::New
        (
            word("." + name_),
            U_,
            phi_,
            phaseDict_.subDict("parameters")
        ).ptr()
    );
}


phase::phase
(
    const word& phaseName,
    const dictionary& phaseDict,
    const volVectorField& U,
    const surfaceScalarField& phi
)
:
    volScalarField
    (
        IOobject
        (
            IOobject::groupName("alpha", phaseName),
            U.mesh().time().timeName(),
            U.mesh(),
            IOobject::MUST_READ,
            IOobject::AUTO_WRITE
        ),
        U.mesh()
    ),
    name_(phaseName),
    phaseDict_(phaseDict),
    U_(U),
    phi_(phi),
    nuModel_
    (
        viscosityModel::New
        (
            IOobject::groupName("nu", phaseName),
            phaseDict_,
            U_,
            phi_
        )
    ),
    phaseEqModel_
    (
        constitutiveEq::New
        (
            word("." + phaseName),
            U_,
            phi_,
            phaseDict_.subDict("parameters")
        )
    ),
    rho_("rho", dimDensity, phaseDict_)
{
    validateCompatibilityTransport();
    validateDensity();
    warnForLegacyHerschelBulkley();
}


autoPtr<phase> phase::clone() const
{
    NotImplemented;
    return autoPtr<phase>(nullptr);
}


void phase::correct()
{
    // The required phase-level model is Newtonian and acts only as a stable
    // compatibility viscosity.  The active momentum stress is supplied
    // exclusively by the RheoTool constitutive model.
    nuModel_->correct();
    phaseEqModel_->correct();
}


bool phase::read(const dictionary& phaseDict)
{
    phaseDict_ = phaseDict;

    phaseDict_.lookup("rho") >> rho_;

    // Both runtime-selectable model families are reconstructed.  This makes
    // a transportProperties re-read complete, including a model-type change,
    // instead of updating only coefficients accepted by the old object.
    rebuildViscosityModel();
    rebuildConstitutiveModel();

    validateCompatibilityTransport();
    validateDensity();
    warnForLegacyHerschelBulkley();
    correct();

    return true;
}

} // End namespace Foam

// ************************************************************************* //
