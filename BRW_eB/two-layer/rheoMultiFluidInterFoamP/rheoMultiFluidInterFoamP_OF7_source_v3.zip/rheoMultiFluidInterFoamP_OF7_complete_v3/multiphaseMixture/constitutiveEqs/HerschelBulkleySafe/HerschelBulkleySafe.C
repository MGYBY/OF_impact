/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Source CFD Toolbox
   \\    /   O peration     | OpenFOAM Foundation 7 / RheoTool OF70+
    \\  /    A nd           |
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is distributed under the GNU General Public License v3 or later.

\*---------------------------------------------------------------------------*/

#include "HerschelBulkleySafe.H"
#include "addToRunTimeSelectionTable.H"
#include <cmath>

namespace Foam
{
namespace constitutiveEqs
{
    defineTypeNameAndDebug(HerschelBulkleySafe, 0);
    addToRunTimeSelectionTable
    (
        constitutiveEq,
        HerschelBulkleySafe,
        dictionary
    );
}
}


void Foam::constitutiveEqs::HerschelBulkleySafe::validateParameters
(
    const dictionary& dict
) const
{
    if (rho_.value() <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "rho must be positive" << exit(FatalIOError);
    }

    if (tau0_.value() < 0)
    {
        FatalIOErrorInFunction(dict)
            << "tau0 must be non-negative" << exit(FatalIOError);
    }

    if (eta0_.value() <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "eta0 must be positive" << exit(FatalIOError);
    }

    if (k_.value() < 0)
    {
        FatalIOErrorInFunction(dict)
            << "k must be non-negative" << exit(FatalIOError);
    }

    if (n_.value() <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "n must be positive" << exit(FatalIOError);
    }

    if (reg_ && m_.value() < 0)
    {
        FatalIOErrorInFunction(dict)
            << "m must be non-negative when PapanastasiouRegularization "
            << "is enabled" << exit(FatalIOError);
    }

    if (nDims_ <= 0)
    {
        FatalIOErrorInFunction(dict)
            << "dims must contain at least one solved direction"
            << exit(FatalIOError);
    }
}


Foam::scalar
Foam::constitutiveEqs::HerschelBulkleySafe::apparentViscosity
(
    const scalar gammaDot
) const
{
    const scalar gamma = max(gammaDot, VSMALL);
    const scalar eta0 = eta0_.value();

    scalar eta = 0.0;

    if (k_.value() > 0.0)
    {
        eta += k_.value()*pow(gamma, n_.value() - 1.0);

        if (eta >= eta0)
        {
            return eta0;
        }
    }

    if (tau0_.value() > 0.0)
    {
        if (reg_)
        {
            const scalar x = m_.value()*gamma;

            // -expm1(-x) is accurate for x << 1 and tends to x.  Hence the
            // yield-viscosity term tends continuously to tau0*m.
            eta += tau0_.value()*(-std::expm1(-x))/gamma;
        }
        else
        {
            eta += tau0_.value()/gamma;
        }
    }

    return min(eta0, eta);
}


Foam::constitutiveEqs::HerschelBulkleySafe::HerschelBulkleySafe
(
    const word& name,
    const volVectorField& U,
    const surfaceScalarField& phi,
    const dictionary& dict
)
:
    constitutiveEq(name, U, phi),
    rho_(dict.lookup("rho")),
    reg_(dict.lookup("PapanastasiouRegularization")),
    tau0_(dict.lookup("tau0")),
    eta0_(dict.lookup("eta0")),
    k_(dict.lookup("k")),
    n_(dict.lookup("n")),
    m_
    (
        reg_ == true
      ? dict.lookup("m")
      : dimensionedScalar("m", dimTime, 1.0)
    ),
    dims_(dict.lookupOrDefault<vector>("dims", U.mesh().solutionD())),
    nDims_(scalar(dims_.x() + dims_.y() + dims_.z())),
    identity_("Identity", dimless, symm(tensor::I)),
    writeStress_(dict.lookupOrDefault<Switch>("writeStress", true)),
    writeSecondInvariant_
    (
        dict.lookupOrDefault<Switch>("writeSecondInvariantTauDev", true)
    ),
    writeShearRate_(dict.lookupOrDefault<Switch>("writeShearRate", true)),
    IItauD_
    (
        IOobject
        (
            "IItauD" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::READ_IF_PRESENT,
            IOobject::NO_WRITE
        ),
        strainRate()*dimensionedScalar
        (
            "zeroStress",
            dimensionSet(1, -1, -1, 0, 0, 0, 0),
            0
        )
    ),
    tau_
    (
        IOobject
        (
            "tau" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        U.mesh(),
        dimensionedSymmTensor
        (
            "zero",
            dimensionSet(1, -1, -2, 0, 0, 0, 0),
            symmTensor::zero
        ),
        extrapolatedCalculatedFvPatchField<symmTensor>::typeName
    ),
    eta_
    (
        IOobject
        (
            "eta" + name,
            U.time().timeName(),
            U.mesh(),
            IOobject::READ_IF_PRESENT,
            IOobject::AUTO_WRITE
        ),
        strainRate()*dimensionedScalar
        (
            "zeroViscosity",
            dimensionSet(1, -1, 0, 0, 0, 0, 0),
            0
        )
    )
{
    identity_.value().xx() = dims_.x();
    identity_.value().yy() = dims_.y();
    identity_.value().zz() = dims_.z();

    validateParameters(dict);
    correct();
}


void Foam::constitutiveEqs::HerschelBulkleySafe::correct()
{
    volScalarField gammaDot
    (
        IOobject
        (
            "gammaDot" + name(),
            U().time().timeName(),
            U().mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        max
        (
            strainRate(),
            dimensionedScalar("gammaDotMin", dimless/dimTime, VSMALL)
        )
    );

    scalarField& etaCells = eta_.primitiveFieldRef();
    const scalarField& gammaCells = gammaDot.primitiveField();

    forAll(etaCells, celli)
    {
        etaCells[celli] = apparentViscosity(gammaCells[celli]);
    }

    forAll(eta_.boundaryField(), patchi)
    {
        scalarField& etaPatch = eta_.boundaryFieldRef()[patchi];
        const scalarField& gammaPatch = gammaDot.boundaryField()[patchi];

        forAll(etaPatch, facei)
        {
            etaPatch[facei] = apparentViscosity(gammaPatch[facei]);
        }
    }


    const volTensorField gradU(fvc::grad(U()));

    tau_ = eta_*
    (
        symm(gradU + gradU.T())
      - (2.0/3.0)*tr(gradU)*symmTensor::I
    );

    IItauD_ = mag(tau_ - identity_*tr(tau_)/nDims_)/sqrt(2.0);

    if (U().time().outputTime())
    {
        if (writeShearRate_)
        {
            gammaDot.write();
        }

        if (writeStress_)
        {
            tau_.write();
        }

        if (writeSecondInvariant_)
        {
            IItauD_.write();
        }
    }
}

// ************************************************************************* //
