# Periodic steady-uniform power-law film (OpenFOAM 9)

This is a source-level regression case for `rheoMultiFluidInterFoamP` on
OpenFOAM Foundation 9 with RheoTool OF90.  The streamwise patches are ordinary
`cyclic` patches and the solved pressure is the mechanical pressure `p`.

The liquid is the pure power-law limit of Herschel--Bulkley:

- density `rho = 1202 kg/m3`;
- consistency `K = 1.38 Pa s^n`;
- exponent `n = 0.2`;
- yield stress `tau0 = 0`;
- film depth `H = 0.00602890842 m`;
- downslope gravity `gx = 0.5886 m/s2`.

The analytical steady-uniform values are approximately

```text
depth-averaged velocity  0.242975384 m/s
free-surface velocity    0.283471281 m/s
```

The initial field uses the analytical mean velocity uniformly; it is therefore
a build/runtime smoke test rather than a fully profile-matched convergence
case.  A quantitative validation should initialize the exact vertical profile
and compare phase-weighted discharge after transients decay.

## Run

```bash
./Allrun
```

Check at minimum:

- `alpha.mud + alpha.air = 1` and phase-volume conservation;
- continuity errors and cyclic flux matching;
- the phase-weighted mean and maximum mud velocity;
- independence from `pRefCell`;
- Newtonian recovery with `tau0=0`, `n=1`, and `k=eta`;
- mesh and time-step convergence.

`sigmasPh` stores the phase-specific coefficients `Sigma_i`.  For this
two-phase case each is set to half of the pairwise `sigma_mud-air`, so that
`Sigma_mud + Sigma_air = sigma_mud-air`.


The upper boundary is a pressure outlet/inlet (`totalPressure` for `p`,
`pressureInletOutletVelocity` for `U`, and `inletOutlet` phase fractions).
The supplied `sigmasPh` values are checked at startup against
`Sigma_mud + Sigma_air = sigma_mud-air`.
