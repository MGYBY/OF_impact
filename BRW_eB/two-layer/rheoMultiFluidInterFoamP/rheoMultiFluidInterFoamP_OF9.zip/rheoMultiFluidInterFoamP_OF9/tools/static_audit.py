#!/usr/bin/env python3
"""Static source and case audit for the OpenFOAM 9 port.

This script does not replace compilation or CFD validation.  It verifies the
high-risk migration invariants that can be checked directly from the source.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

checks: list[tuple[str, bool, str]] = []


def text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str) -> None:
    checks.append((name, bool(condition), detail))


main = text("rheoMultiFluidInterFoamP.C")
fields = text("createFields.H")
ueqn = text("UEqn.H")
peqn = text("pEqn.H")
mixture_c = text("multiphaseMixture/multiphaseMixture.C")
mixture_h = text("multiphaseMixture/multiphaseMixture.H")
phase_c = text("multiphaseMixture/phase/phase.C")
phase_h = text("multiphaseMixture/phase/phase.H")
app_options = text("Make/options")
lib_options = text("multiphaseMixture/Make/options")
case_transport = text("tutorials/periodicSteadyUniformPowerLaw/constant/transportProperties")
case_solution = text("tutorials/periodicSteadyUniformPowerLaw/system/fvSolution")
case_p = text("tutorials/periodicSteadyUniformPowerLaw/0.orig/p")
case_u = text("tutorials/periodicSteadyUniformPowerLaw/0.orig/U")
case_alpha_mud = text("tutorials/periodicSteadyUniformPowerLaw/0.orig/alpha.mud")
case_mesh = text("tutorials/periodicSteadyUniformPowerLaw/system/blockMeshDict")

# OpenFOAM-9 application/API invariants
check("OF9 pimple.run loop", "while (pimple.run(runTime))" in main,
      "Main loop uses the OpenFOAM-9 solution-control API.")
check("fvModels migration", "fvModels.preUpdateMesh()" in main and "fvModels.correct()" in main,
      "OF9 fvModels replaces OF7 fvOptions source handling.")
check("fvConstraints migration", "fvConstraints.constrain(UEqn)" in ueqn and "fvConstraints.constrain(U)" in peqn,
      "Equation and field constraints use the OF9 interface.")
check("pressureReference object", "pressureReference pressureReference(p, pimple.dict())" in fields,
      "Physical pressure reference uses the OF9 pressureReference class.")
check("OF9 MULES limitSum", "MULES::limitSum(alphas, alphaPhis, phi_)" in mixture_c,
      "Multi-phase limiting uses the OF9 signature.")
check("OF9 dictionary read", "regIOobject::read()" in mixture_c,
      "Mixture re-read uses the OF9 IOdictionary/regIOobject path.")
check("OF9 libraries", all(token in app_options for token in ("-lfvModels", "-lfvConstraints", "-ltransportModels")),
      "Make/options references the OF9 model and transport libraries.")

# Physical-pressure formulation
all_solver_source = "\n".join((main, fields, ueqn, peqn))
active_source = re.sub(r"/\*.*?\*/|//[^\n]*", "", all_solver_source, flags=re.S)
check("no p_rgh field", "p_rgh" not in active_source,
      "The application advances p directly; explanatory comments are ignored.")
check("no gh/hRef fields", not re.search(r"\bghf?\b|readhRef|ghRef", active_source),
      "Hydrostatic helper fields are absent from active code.")
check("positive gravity source", "+ rho*g" in ueqn,
      "Momentum uses +rho*g under the OpenFOAM physical-acceleration convention.")
check("cyclic physical pressure tutorial", "type cyclic" in case_p and "object      p;" in case_p,
      "Tutorial pressure field uses ordinary cyclic patches.")

# RheoTool coupling and stress semantics
check("one constitutive equation per phase", "autoPtr<constitutiveEq> constitutiveEq_" in phase_h,
      "Each phase owns an OF90 constitutive equation.")
check("phase colour passed to RheoTool", "constitutiveEq_->correct(this)" in phase_c,
      "The alpha field is passed to OF90 correct(alpha,gradU).")
check("GNF stress double-count guard", "if (!iter().isGNF())" in mixture_c and "divTauS() is already" in mixture_c,
      "tau() is not added on top of the complete GNF divTauS stress.")
check("no bundled HB override", not (ROOT / "HerschelBulkley.C").exists(),
      "The port relies on the official RheoTool OF90 HerschelBulkley class.")
check("RheoTool include root configurable", "RHEOTOOL_SRC ?=" in app_options and "RHEOTOOL_SRC ?=" in lib_options,
      "The OF90 source location can be overridden without editing Make/options.")

# Published multiFluidInterFoam interface treatment
check("phase-specific surface tension", "sigmasPh_" in mixture_h and "fvc::interpolate(Kn(alpha))" in mixture_c,
      "Surface force uses Sigma_i kappa_i grad(alpha_i).")
check("runtime sigma decomposition validation", "validateSigmaDecomposition()" in mixture_c and "checkSigmaDecomposition" in mixture_c,
      "Pairwise and phase-specific surface tensions are checked at startup and on dictionary re-read.")
check("optional curvature smoothing", "smoothCurvature" in mixture_c and "numSmoothingIterations" in mixture_c,
      "The Laplacian VOF filter is runtime-controlled.")
check("smoothing restricted to curvature",
      "nHatfvn(alpha, false)" in mixture_c and "nHatfvn(alpha, true)" in mixture_c,
      "Compression uses raw alpha; only curvature may use the smoothed VOF field.")
check("phase-normal compression", "surfaceScalarField phir(phic*nHatfn(alpha))" in mixture_c,
      "Artificial compression follows the phase-normal form of the paper.")
check("SIMPLEC branch", "if (simplec)" in peqn and "UEqn.H1()" in peqn,
      "Pressure correction contains the SIMPLEC diagonal correction.")

# Tutorial dictionary invariants
check("tutorial p reference", "pRefCell" in case_solution and "pRefValue" in case_solution,
      "A fallback pressure reference is present for closed variants of the periodic case.")
check("tutorial open upper boundary", all(token in case_u + case_alpha_mud + case_mesh for token in
      ("pressureInletOutletVelocity", "inletOutlet", "type patch")),
      "The atmospheric top is an open patch rather than a wall carrying a pressure boundary condition.")
check("tutorial phase models", case_transport.count("parameters") >= 2 and "HerschelBulkley" in case_transport,
      "Both phases provide RheoTool parameter dictionaries.")

# Check the two-phase sigma decomposition in the supplied case.
pair = re.search(r"\(mud air\)\s+([0-9.eE+-]+)", case_transport)
mud = re.search(r"\(mud mud\)\s+([0-9.eE+-]+)", case_transport)
air = re.search(r"\(air air\)\s+([0-9.eE+-]+)", case_transport)
consistent_sigma = False
if pair and mud and air:
    pair_v = float(pair.group(1))
    phasic_sum = float(mud.group(1)) + float(air.group(1))
    consistent_sigma = abs(pair_v - phasic_sum) <= 1e-12 * max(1.0, abs(pair_v))
check("tutorial sigma decomposition", consistent_sigma,
      "Sigma_mud + Sigma_air equals sigma_mud-air.")

# Reject known OF7-only API tokens in active source/Make files.
legacy_tokens = {
    "turbulentTransportModel.H": all_solver_source + app_options,
    "incompressible::turbulenceModel": all_solver_source,
    "createFvOptions.H": all_solver_source,
    "fvOptions(": all_solver_source,
    "setRefCell": all_solver_source,
    "MULES::limitSum(alphaPhi": mixture_c,
    "transportModel::read()": mixture_c,
}
for token, haystack in legacy_tokens.items():
    check(f"legacy token absent: {token}", token not in haystack,
          "OF7-only syntax is not present in active port files.")

passed = sum(ok for _, ok, _ in checks)
failed = len(checks) - passed

print("rheoMultiFluidInterFoamP OF9 static audit")
print(f"root: {ROOT}")
print(f"checks: {len(checks)}  passed: {passed}  failed: {failed}\n")

for name, ok, detail in checks:
    status = "PASS" if ok else "FAIL"
    print(f"[{status}] {name}\n       {detail}")

sys.exit(1 if failed else 0)
