#!/bin/sh
set -eu

fail=0

say()
{
    printf '%-34s %s\n' "$1" "$2"
}

say "foamVersion" "$(foamVersion 2>/dev/null || echo unavailable)"
say "WM_PROJECT_VERSION" "${WM_PROJECT_VERSION:-unset}"
say "WM_OPTIONS" "${WM_OPTIONS:-unset}"
say "WM_PROJECT_DIR" "${WM_PROJECT_DIR:-unset}"
say "FOAM_USER_APPBIN" "${FOAM_USER_APPBIN:-unset}"
say "FOAM_USER_LIBBIN" "${FOAM_USER_LIBBIN:-unset}"
say "EIGEN_RHEO" "${EIGEN_RHEO:-unset}"
say "PETSC_DIR" "${PETSC_DIR:-unset}"
say "PETSC_ARCH" "${PETSC_ARCH:-unset}"

case "${WM_PROJECT_VERSION:-}" in
    9|9.*) ;;
    *) echo "FAIL: source OpenFOAM Foundation 9 first" >&2; fail=1 ;;
esac

RHEOTOOL_SRC="${RHEOTOOL_SRC:-${FOAM_USER_SRC:-}/libs/libRheoTool}"
say "RHEOTOOL_SRC" "$RHEOTOOL_SRC"

for path in \
    "$RHEOTOOL_SRC/constitutiveEquations/lnInclude/constitutiveEq.H" \
    "$RHEOTOOL_SRC/sparseMatrixSolvers/lnInclude/sparseSolver.H"
do
    if [ -f "$path" ]; then
        say "found" "$path"
    else
        echo "MISSING: $path" >&2
        fail=1
    fi
done

for lib in constitutiveEquations sparseMatrixSolvers fvmb thermoRheoTool; do
    matches=$(find "${FOAM_USER_LIBBIN:-/nonexistent}" -maxdepth 1 \
        -type f -name "lib${lib}.so*" -print 2>/dev/null || true)
    if [ -n "$matches" ]; then
        say "library $lib" "$matches"
    else
        echo "MISSING: lib${lib}.so under FOAM_USER_LIBBIN" >&2
        fail=1
    fi
done

for cmd in wmake blockMesh setFields checkMesh; do
    if command -v "$cmd" >/dev/null 2>&1; then
        say "command $cmd" "$(command -v "$cmd")"
    else
        echo "MISSING command: $cmd" >&2
        fail=1
    fi
done

exit "$fail"
