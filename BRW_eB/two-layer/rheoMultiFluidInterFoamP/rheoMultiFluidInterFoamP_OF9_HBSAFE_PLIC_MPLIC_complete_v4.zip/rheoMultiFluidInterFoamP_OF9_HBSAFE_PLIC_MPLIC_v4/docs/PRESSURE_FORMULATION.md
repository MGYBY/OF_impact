# Physical-pressure formulation for inclined cyclic domains

## Why `p_rgh` is awkward at a cyclic join

OpenFOAM's reduced pressure is

\[
p_{rgh}=p-\rho\,\boldsymbol g\!\cdot\!\boldsymbol x
\]

(up to the reference-height convention).  Across corresponding translational
cyclic faces separated by \(\Delta\boldsymbol x\), the gravitational potential
changes when

\[
\boldsymbol g\cdot\Delta\boldsymbol x\ne0.
\]

Even if the mechanical pressure, phase fractions and velocity are periodic in
a bed-aligned coordinate system, `p_rgh` generally is not.  The OF7 solver has
no modern gravitationally corrected cyclic pressure condition, so this port
advances `p` directly.

## Exact transformation

Using

\[
\nabla p_{rgh}=\nabla p-(\boldsymbol g\cdot\boldsymbol x)\nabla\rho-\rho\boldsymbol g,
\]

we obtain

\[
-\nabla p_{rgh}-(\boldsymbol g\cdot\boldsymbol x)\nabla\rho
=
-\nabla p+\rho\boldsymbol g.
\]

The momentum equation therefore contains

```cpp
+ rho*g
```

and the reconstructed explicit face force contains

```cpp
mixture.surfaceTensionForce() - fvc::snGrad(p)
```

There is no `-rho*g`, no `ghf*snGrad(rho)`, and no `p_rgh` field.

## Pressure correction

Gravity is already part of `UEqn.H()` after the momentum matrix is assembled.
The pressure predictor therefore forms `HbyA` from that matrix and adds only
the surface-tension face flux explicitly.  The pressure equation is

```cpp
fvm::laplacian(rAtU(), p) == fvc::div(phiHbyA)
```

with

```cpp
phi = phiHbyA - pEqn.flux();
```

The SIMPLEC branch uses `rAtU` and `UEqn.H1()` in the same OF90 style as
`rheoInterFoam`.

## Pressure reference

- If an atmospheric `totalPressure` or other fixed-pressure boundary is
  present, `p.needReference()` is false.
- For a completely closed/cyclic domain, set `pRefCell` and `pRefValue` in the
  `PIMPLE` dictionary.
- A valid incompressible solution must be independent of the selected
  reference cell apart from an additive pressure constant.

## Numerical qualification

The physical-pressure and reduced-pressure equations are continuously
identical, but their discrete hydrostatic balances need not be identical.
Before production use, run:

1. a static two-density column test;
2. a periodic single-phase inclined-film test;
3. a cyclic-seam continuity test;
4. a pressure-reference invariance test.

`tools/pressure_identity_check.py` verifies the continuous identity by a
second-order manufactured finite-difference calculation.  It is not a
substitute for the OpenFOAM tests above.
