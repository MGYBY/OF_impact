#!/usr/bin/env python3
"""Manufactured check of the physical-pressure gravity identity.

This checks the continuous transformation used by rheoMultiFluidInterFoamP:

    -grad(p_rgh) - (g.x) grad(rho) = -grad(p) + rho g,
    p_rgh = p - rho (g.x).

The finite-difference test deliberately excludes the two end points because
p_rgh is not periodic when gravity has a component across a periodic domain.
It is an algebraic/regression check, not an OpenFOAM discretisation proof.
"""

from __future__ import annotations

import numpy as np


def error(n: int) -> float:
    x = np.linspace(-0.35, 0.65, n)
    dx = x[1] - x[0]
    gx = 0.5886

    rho = 1000.0 + 120.0*np.sin(2.1*x) + 35.0*np.cos(4.3*x)
    p = 2.0e3*np.sin(1.7*x) + 500.0*np.cos(3.2*x)
    gh = gx*x
    p_rgh = p - rho*gh

    def grad(f: np.ndarray) -> np.ndarray:
        return (f[2:] - f[:-2])/(2.0*dx)

    lhs = -grad(p_rgh) - gh[1:-1]*grad(rho)
    rhs = -grad(p) + rho[1:-1]*gx
    return float(np.max(np.abs(lhs - rhs)))


def main() -> None:
    grids = (51, 101, 201, 401, 801)
    errors = [error(n) for n in grids]

    print("physical-pressure identity check")
    print("n\tmax_abs_error\tobserved_order")
    previous = None
    for n, err in zip(grids, errors):
        if previous is None:
            order = float("nan")
        else:
            order = np.log(previous/err)/np.log(2.0)
        print(f"{n}\t{err:.12e}\t{order:.6f}")
        previous = err

    if errors[-1] >= errors[0]/100.0:
        raise SystemExit("error did not decrease sufficiently")


if __name__ == "__main__":
    main()
