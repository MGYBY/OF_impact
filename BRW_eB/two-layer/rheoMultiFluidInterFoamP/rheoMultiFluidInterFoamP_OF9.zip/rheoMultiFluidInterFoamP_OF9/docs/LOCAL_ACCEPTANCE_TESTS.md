# Local acceptance tests

Run the tests in this order.  Do not begin a later scientific test until the
previous software gate passes.

## A. Build and link gate

1. `./tools/check_environment.sh` returns zero.
2. `./Allwmake` returns zero.
3. the library and executable exist.
4. `ldd` reports no missing libraries.
5. `python3 tools/static_audit.py` reports zero failures.

## B. Parser and one-step gate

Use the supplied tutorial with `endTime` set to one or two time steps.
Require:

- all dictionaries parse;
- phase models are selected correctly;
- no NaN/Inf;
- `sum(alpha_i)` remains within a strict tolerance of one;
- continuity errors are finite;
- the solver writes a new time directory.

## C. Newtonian recovery

Set every phase to RheoTool `Newtonian` and compare with an OF9 Newtonian
multiphase calculation using the same mesh, timestep and boundary conditions.
Compare:

- phase volumes;
- pressure and velocity norms;
- interface position;
- integrated kinetic energy;
- timestep history.

The discrepancy should converge toward zero with mesh and timestep refinement.

## D. Single-phase physical-pressure inclined film

Set the whole domain to one Newtonian liquid and remove surface tension.
Require:

- correct flow direction for the declared `g` vector;
- steady wall traction equal to the downslope body-force integral;
- independence from `pRefCell`;
- no jump in `p`, `U` or flux at the cyclic join.

This test detects a wrong gravity sign immediately.

## E. Two-phase power-law normal flow

Use the supplied parameters and initialize the exact analytical profile.
Measure phase-weighted values:

\[
h_\alpha=\int \alpha_{mud}\,dy,
\qquad
q_\alpha=\int \alpha_{mud}U_x\,dy,
\qquad
\overline U=q_\alpha/h_\alpha.
\]

Reference values:

```text
Umean = 0.242975383711 m/s
Umax  = 0.283471280996 m/s
```

Require mesh, timestep and domain-height convergence.  Also check that the
computed basal traction balances `rho*gx*h_alpha`.

## F. Stress-assembly gate

For the pure power-law case, verify that the total basal traction is supplied
once—not by two equal copies.  Inspect the RheoTool apparent viscosity and the
total momentum balance.  This is the regression test for the GNF double-count
guard.

## G. Cyclic pressure and reference gate

Run with several valid `pRefCell` choices.  After subtracting an additive
constant from `p`, require identical `U`, alpha fields and fluxes.  Sample both
cyclic faces and check mapped values and integrated mass flux.

## H. Static column/capillary gate

Before surface-tension-dominated work, run:

1. a static two-density column under gravity;
2. a static drop with known Laplace pressure.

Measure parasitic velocity, pressure error and convergence.  Physical pressure
can have a different discrete hydrostatic balance from `p_rgh` even though the
continuous equations are identical.

## I. Herschel-Bulkley/Papanastasiou gate

Reproduce an official OF90 `rheoInterFoam` two-phase HB case first.  Compare:

- apparent viscosity;
- yielded/unyielded diagnostic regions;
- terminal or steady velocity;
- regularization-parameter sensitivity.

## J. Advanced features

Only after A–I pass:

- three phases and triple junctions;
- dynamic contact angle;
- dynamic mesh;
- parallel cyclic run;
- viscoelastic PTT or other differential model.
