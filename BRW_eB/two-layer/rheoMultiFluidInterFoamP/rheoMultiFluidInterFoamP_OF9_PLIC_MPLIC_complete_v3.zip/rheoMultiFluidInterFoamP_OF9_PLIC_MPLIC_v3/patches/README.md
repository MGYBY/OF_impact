# Source comparison patches

These files are review aids, not the recommended installation method.  The
complete OF9 source tree in the parent directory should be copied and built as a
unit.

- `FROM_UPLOADED_OF7_P_SOURCE.diff` compares the high-level solver, pressure,
  mixture, phase, contact-angle and Make files with the uploaded OF7
  `rheoMultiFluidInterFoamP` source.  It also records the deliberate removal of
  the customized OF7 `HerschelBulkley.C` override.
- `AGAINST_OF9_MULTIPHASEINTERFOAM_SOURCE.diff` shows how the port differs from
  stock OpenFOAM-9 `multiphaseInterFoam`, making the OF9 rebase and retained
  rheology/interface changes easier to review.

The directory layouts differ substantially, so these patches are not expected
to apply cleanly with a single `patch -pN` command.  They are intended for
manual review and provenance.

- `PLIC_MPLIC_COMPATIBILITY.patch` is a focused unified diff from the previous
  OF9 port to the present geometric-VOF update.  It includes the custom mixture
  logic, explicit library links, documentation and tutorial dictionaries.
- `OF9_V2_TO_PLIC_MPLIC_V3_FULL.diff` is the complete review diff from the
  previous OF9 package to this update, excluding generated evidence, manifests
  and older provenance diffs.
