# PLIC/MPLIC compatibility release

Package identifier: `rheoMultiFluidInterFoamP_OF9_PLIC_MPLIC_v3`

Prepared: 2026-08-03

This release supersedes the earlier OpenFOAM-9 compatibility package.  Its
principal addition is explicit integration of OpenFOAM Foundation 9's
`interfaceCompression`, `PLIC`, `PLICU`, `MPLIC` and `MPLICU` interpolation
schemes into the custom n-phase MULES transport loop.  See
`docs/PLIC_MPLIC_COMPATIBILITY.md` and `CHANGELOG_OF9_PORT.md`.
