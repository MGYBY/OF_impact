/*--------------------------------*- C++ -*----------------------------------*\
  =========                 |
  \      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \    /   O peration     | Foundation version 7 case dictionary
    \  /    A nd           |
     \/     M anipulation  |
\*---------------------------------------------------------------------------*/
FoamFile
{
    version     2.0;
    format      ascii;
    class       volScalarField;
    location    "0";
    object      alpha.mud;
}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //
    dimensions      [0 0 0 0 0 0 0];
    internalField   uniform 0;

    boundaryField
    {
        periodicIn  { type cyclic; }
periodicOut { type cyclic; }
bed         { type zeroGradient; }
top         { type zeroGradient; }
frontAndBack { type empty; }
    }
