# RheoTool OF90 phase stress assembly

## One constitutive equation per phase

Each `phase` owns

```cpp
autoPtr<constitutiveEq> constitutiveEq_;
```

constructed from the phase's `parameters` dictionary.  The phase fraction is
passed to

```cpp
constitutiveEq_->correct(this);
```

which matches the OF90 `correct(alpha, gradU)` interface.

The stock OpenFOAM `viscosityModel` is retained only because
`multiphaseMixture` derives from `kinematicTransportModel`.  It is a
compatibility/base transport object; the active laminar momentum stress is the
RheoTool stress.

## Generalized-Newtonian fluids

In official RheoTool OF90, `divTauS(U, alpha)` supplies the complete
phase-weighted generalized-Newtonian stress divergence.  For a Herschel-Bulkley
phase, the apparent dynamic viscosity is updated algebraically and the model is
marked `isGNF() == true`.

Therefore the port does:

```cpp
divTau += phase.divTauS(U, boundedAlpha);

if (!phase.isGNF())
{
    tauMF += phase.tau()*boundedAlpha;
}
```

It does **not** unconditionally add `div(alpha*tau)` for a GNF.  This guard is
important because the earlier customized OF7 Herschel-Bulkley implementation
could write the full GNF stress into `tau()`, making an unconditional addition
apply the same constitutive stress twice.

## Differential/viscoelastic fluids

For non-GNF equations:

- `divTauS()` supplies solvent/stabilization terms;
- `tau()` supplies the additional differential/polymeric extra stress;
- `tauMF` is volume-fraction weighted and added explicitly through
  `fvc::div(tauMF)`.

This is source-compatible with the OF90 constitutive API, but the present
package has not run a viscoelastic CFD regression.  A rising-droplet PTT case
should be required before claiming full viscoelastic validation.

## Official versus package-local Herschel--Bulkley models

The historical customized OF7 file is not copied into or used to patch the
OF90 library.  OpenFOAM 9 links to the official RheoTool OF90 implementation.

This v4 package additionally compiles a distinct runtime type:

```foam
type HerschelBulkleySafe;
```

into `librheoMultiFluidInterFoamP9.so`.  The class follows the OF90 constructor,
`correct(alpha,gradU)`, `eta()`, `isGNF()`, and thermal-multiplier interfaces,
but adds cancellation-safe Papanastasiou evaluation, overflow-safe
shear-thinning evaluation, parameter validation and optional diagnostics.

Both official `HerschelBulkley` and local `HerschelBulkleySafe` remain GNF
models.  Consequently the same double-count guard applies to both, and neither
may be accompanied by an unconditional extra `div(alpha*tau())` term.
