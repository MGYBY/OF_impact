# OpenFOAM 7 to OpenFOAM 9 compatibility audit

## Porting strategy

The reliable strategy is:

```text
OpenFOAM-9 multiphaseInterFoam framework
+ multiFluidInterFoam interface treatment
+ RheoTool OF90 constitutive equations
+ physical-pressure cyclic formulation
```

This is safer than compiling the OF7 application directly because it preserves
OF9's current phase transport, dynamic-mesh, pressure-reference and source-term
interfaces.

## API migration map

| Area | OF7 source | OF9 port |
|---|---|---|
| Time/solution loop | `runTime.run()` with older PIMPLE pattern | `pimple.run(runTime)` |
| Physical sources | `fvOptions` | `fvModels` |
| Numerical constraints | folded into `fvOptions` | separate `fvConstraints` |
| Pressure reference | `setRefCell`, `pRefCell`, `pRefValue` variables | `pressureReference` object |
| Pressure field | physical `p` in the P solver | physical `p`, retained |
| Hydrostatic helpers | not needed in P solver | no `hRef`, `gh`, `ghf`, `p_rgh` |
| Gravity | `+rho*g` | `+rho*g` |
| Flux correction | OF7 include/custom `adjustCorrPhi` | OF9 `CorrectPhi` and `adjustPhi` |
| Multiphase limiter | old `MULES::limitSum(alphaPhiCorrs)` | `MULES::limitSum(alphas, alphaPhis, phi_)` |
| Dictionary reread | older transport read path | `regIOobject::read()` |
| Constitutive library | customized RheoTool 5.0 `of70_plus` | official RheoTool `of90` |
| External sparse solve | OF7 RheoTool interfaces | OF90 `sparseSolver` API |
| Build libraries | OF7 transport/turbulence/fvOptions names | OF9 `transportModels`, `fvModels`, `fvConstraints` |

## Workflow retained in the port

For each PIMPLE outer iteration:

1. update the mesh through the native OF9 dynamic-mesh sequence;
2. correct `fvModels`;
3. advance all phase fractions using MULES;
4. normalize the phase sum and build `rhoPhi`;
5. update each RheoTool constitutive equation;
6. update mixture density;
7. assemble and solve the momentum equation;
8. run SIMPLEC/PIMPLE pressure corrections using physical `p`;
9. correct `U`, `phi`, boundary conditions and constraints.

This ordering preserves the published phase-fraction → constitutive → momentum
→ pressure sequence.  It is segregated, so constitutive and velocity fields
remain iteratively lagged within a time step in the usual finite-volume manner.

## Features retained

- arbitrary number of incompressible phases;
- MULES phase-fraction transport and phase-sum limiting;
- artificial interface compression using the phase normal;
- phase-specific surface-tension coefficients;
- optional face-area-weighted Laplacian smoothing for curvature only;
- raw transported alpha for the phase-normal compression velocity;
- SIMPLEC diagonal correction;
- dynamic-mesh compilation path;
- one RheoTool equation per phase;
- GNF and non-GNF stress assembly paths.

## Features intentionally changed

- no active OpenFOAM turbulence contribution;
- no `p_rgh` or hydrostatic-pressure helper fields;
- no bundled/customized OF7 Herschel-Bulkley source replacement;
- inconsistent `sigmas`/`sigmasPh` dictionaries now fail early by default.

## High-risk items still requiring runtime checks

1. Dynamic contact angle with phase-specific curvature.
2. Differential viscoelastic stress transport.
3. Mesh motion and topology changes.
4. Three-phase junction force balance.
5. Static hydrostatic balance in physical-pressure form.
6. Parallel cyclic decomposition and reconstruction.
