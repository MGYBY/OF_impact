#!/bin/sh
set -e

script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RHEOTOOL_SRC=${RHEOTOOL_SRC:-${FOAM_USER_SRC:-}/libs/libRheoTool}

target="$RHEOTOOL_SRC/constitutiveEquations/constitutiveEqs/GNF/HerschelBulkley/HerschelBulkley.C"

if [ ! -f "$target" ]; then
    echo "ERROR: cannot find legacy HerschelBulkley.C at:" >&2
    echo "  $target" >&2
    echo "Set RHEOTOOL_SRC to the OF70+ RheoTool src/libs directory." >&2
    exit 1
fi

backup="$target.before-rheoMultiFluidInterFoamP-v3.$(date +%Y%m%d-%H%M%S)"
cp -pv "$target" "$backup"
cp -pv "$script_dir/HerschelBulkley.C" "$target"

echo "Backup: $backup"
echo "Rebuilding libconstitutiveEquations..."
(
    cd "$RHEOTOOL_SRC/constitutiveEquations"
    wmake libso
)

echo "Legacy HerschelBulkley patch installed. Rebuild rheoMultiFluidInterFoamP."
