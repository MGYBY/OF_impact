# Package verification record

Prepared: 2026-08-03

## Completed checks

| Check | Result |
|---|---|
| Expanded OF9/pressure/rheology/PLIC static audit | **66/66 passed** |
| `HerschelBulkleySafe.C` translation unit against actual OF9 headers | passed |
| `phase.C` translation unit | passed |
| contact-angle translation unit | passed |
| `multiphaseMixture.C` translation unit | passed |
| main solver translation unit | passed |
| independent HB-safe scalar reference | 6/6 passed |
| pressure/gravity manufactured identity | passed |
| analytical power-law normal-flow reference | passed |
| shell-script syntax | passed |
| Python syntax | passed |
| six-way VOF selector round-trip | passed |
| geometric dictionaries omit legacy `cAlpha` | passed |
| every `div(phirb,alpha)` template uses `Gauss linear` | passed |
| package manifest and ZIP integrity | passed during packaging |
| build artifacts removed | passed during packaging |

## Translation-unit qualification

The OpenFOAM side used the actual OpenFOAM Foundation 9 source headers.  The
RheoTool side used declaration-only headers matching the official OF90 public
signatures because a compiled OF90 installation was unavailable in the
packaging runtime.  No stub implementation is included or linked.

## Deliberate claim boundary

Final shared-library/executable linking, `ldd`, case execution, parallel tests
and quantitative CFD validation remain local acceptance gates.  The package is
an audited source release, not a production-validation certificate.
