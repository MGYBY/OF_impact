# rheoMultiFluidInterFoamP for OpenFOAM Foundation 9

This directory contains a **source-level OpenFOAM Foundation 9 port** of the
physical-pressure solver `rheoMultiFluidInterFoamP`.  The solver is intended
for streamwise-periodic free-surface roll-wave calculations in which ordinary
`cyclic` conditions are required at the two streamwise ends.

The target stack is:

```text
OpenFOAM Foundation 9
+ official RheoTool OF90
+ rheoMultiFluidInterFoamP
```

The port is rebased on the OpenFOAM-9 `multiphaseInterFoam` API rather than
being a blind search-and-replace conversion of the OpenFOAM-7 source.

## Verification status

| Check | Status |
|---|---|
| Static API/source audit | **52/52 passed** |
| Custom mixture translation units compiled against actual OF9 headers | **Passed** |
| Solver translation unit compiled against actual OF9 headers | **Passed** |
| RheoTool interfaces in the header check | Signature-compatible OF90 stubs, cross-checked with official OF90 source |
| Final shared-library and executable link | **Not performed here** |
| Tutorial CFD execution | **Not performed here** |
| Numerical equivalence to the OF7 solver | **Not yet established** |

The object-compilation checks establish C++/OpenFOAM-9 header compatibility of
the modified translation units.  They do **not** replace a final build against
your compiled RheoTool OF90 installation or CFD validation on your machine.
See `docs/VERIFICATION_STATUS.md`.

## Principal changes

1. The application advances mechanical pressure `p`, not `p_rgh`.
2. Gravity enters the momentum equation as `+rho*g`.
3. The main loop uses `pimple.run(runTime)`.
4. OF7 `fvOptions` has been replaced by OF9 `fvModels` and `fvConstraints`.
5. Pressure referencing uses the OF9 `pressureReference` object.
6. Multiphase limiting uses the OF9 `MULES::limitSum(alphas, alphaPhis, phi)` API.
7. Every phase owns an official RheoTool OF90 constitutive equation.
8. The generalized-Newtonian stress is protected against double assembly:
   `divTauS()` supplies the complete GNF stress and `tau()` is added only for
   non-GNF differential equations.
9. The bundled OF7 `HerschelBulkley.C` override is deliberately not ported.
10. The phase-specific surface-tension decomposition, curvature-only VOF
    smoothing, phase-normal compression and SIMPLEC correction are retained.
11. Pairwise and phase-specific surface tensions are checked at runtime using
    `sigma_ij = Sigma_i + Sigma_j`.
12. The supplied tutorial uses ordinary cyclic streamwise pressure patches and
    a genuine open atmospheric upper boundary.
13. OF9 `PLIC`, `PLICU`, `MPLIC`, and `MPLICU` are integrated explicitly:
    geometric schemes bypass the separate legacy pairwise-compression flux,
    `cAlpha` is optional, PLIC fallback receives a phase-specific `nHatf`, and
    MPLIC always resolves the common velocity field `U`.
14. The custom library and executable link `libtwoPhaseMixture` explicitly so
    the OF9 geometric interpolation run-time constructors are loaded.

## Build

Source OpenFOAM 9 and the same RheoTool OF90 environment used for your working
`rheoInterFoam` build:

```bash
source /path/to/OpenFOAM-9/etc/bashrc

export RHEOTOOL_SRC=/path/to/rheoTool/of90/src/libs
export EIGEN_RHEO=/path/to/eigen
export PETSC_DIR=/path/to/petsc
export PETSC_ARCH=<your-petsc-arch>

./tools/check_environment.sh
./Allwclean
./Allwmake 2>&1 | tee log.Allwmake
```

Successful completion should create:

```text
$FOAM_USER_LIBBIN/librheoMultiFluidInterFoamP9.so
$FOAM_USER_APPBIN/rheoMultiFluidInterFoamP
```

Then check linking:

```bash
ldd "$FOAM_USER_APPBIN/rheoMultiFluidInterFoamP" | tee log.ldd
! grep -q 'not found' log.ldd
```

Detailed instructions are in `docs/BUILD_AND_RUN.md`.

## Tutorials

Legacy/published phase-normal compression branch:

```bash
cd tutorials/periodicSteadyUniformPowerLaw
./Allrun
```

OF9 geometric-interface branch, with MPLIC active by default:

```bash
cd tutorials/periodicSteadyUniformPowerLawMPLIC
./selectVoFScheme MPLIC       # or PLIC, PLICU, MPLICU, interfaceCompression
./Allrun
```

The geometric case deliberately omits `cAlpha`; the solver reads it only for
an algebraic scheme such as `vanLeer01`.  Full syntax and the implementation
policy are documented in `docs/PLIC_MPLIC_COMPATIBILITY.md`.

Both cases are two-phase periodic power-law film smoke/regression cases.  Their
analytical values are

```text
mean liquid velocity       0.242975383711 m/s
free-surface velocity      0.283471280996 m/s
```

The supplied initialization uses the analytical mean velocity uniformly, so a
strict profile validation requires replacing the initial `U` by the exact
vertical power-law profile.  See the tutorial README and
`docs/LOCAL_ACCEPTANCE_TESTS.md`.

## Important scope

The current application is intentionally **laminar**.  The active stress is
provided by RheoTool phase constitutive equations; an OpenFOAM turbulence model
is not added on top.  GNF roll-wave use is the primary target.  Differential
viscoelastic models, dynamic meshes, contact-angle problems and three-phase
junctions still require dedicated local regression tests before scientific use.
For three or more phases, OF9 PLIC/MPLIC is applied independently to each alpha
field and is not claimed to be a coupled multi-material geometric
reconstruction.
