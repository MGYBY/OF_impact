#!/usr/bin/env python3
"""Static source and case audit for the OpenFOAM 9 port.

This script does not replace compilation or CFD validation.  It verifies the
high-risk migration invariants that can be checked directly from the source.
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

checks: list[tuple[str, bool, str]] = []


def text(rel: str) -> str:
    return (ROOT / rel).read_text(encoding="utf-8")


def check(name: str, condition: bool, detail: str) -> None:
    checks.append((name, bool(condition), detail))


main = text("rheoMultiFluidInterFoamP.C")
fields = text("createFields.H")
ueqn = text("UEqn.H")
peqn = text("pEqn.H")
mixture_c = text("multiphaseMixture/multiphaseMixture.C")
mixture_h = text("multiphaseMixture/multiphaseMixture.H")
phase_c = text("multiphaseMixture/phase/phase.C")
phase_h = text("multiphaseMixture/phase/phase.H")
app_options = text("Make/options")
allwmake = text("Allwmake")
lib_options = text("multiphaseMixture/Make/options")
case_transport = text("tutorials/periodicSteadyUniformPowerLaw/constant/transportProperties")
case_solution = text("tutorials/periodicSteadyUniformPowerLaw/system/fvSolution")
case_p = text("tutorials/periodicSteadyUniformPowerLaw/0.orig/p")
case_u = text("tutorials/periodicSteadyUniformPowerLaw/0.orig/U")
case_alpha_mud = text("tutorials/periodicSteadyUniformPowerLaw/0.orig/alpha.mud")
case_mesh = text("tutorials/periodicSteadyUniformPowerLaw/system/blockMeshDict")
case_schemes = text("tutorials/periodicSteadyUniformPowerLaw/system/fvSchemes")
geo_solution = text("tutorials/periodicSteadyUniformPowerLawMPLIC/system/fvSolution")
geo_schemes = text("tutorials/periodicSteadyUniformPowerLawMPLIC/system/fvSchemes")
geo_plic = text("tutorials/periodicSteadyUniformPowerLawMPLIC/system/fvSchemes.PLIC")
geo_plicu = text("tutorials/periodicSteadyUniformPowerLawMPLIC/system/fvSchemes.PLICU")
geo_mplicu = text("tutorials/periodicSteadyUniformPowerLawMPLIC/system/fvSchemes.MPLICU")
geo_interface = text("tutorials/periodicSteadyUniformPowerLawMPLIC/system/fvSchemes.interfaceCompression")
geo_legacy = text("tutorials/periodicSteadyUniformPowerLawMPLIC/system/fvSchemes.legacy")
geo_selector = text("tutorials/periodicSteadyUniformPowerLawMPLIC/selectVoFScheme")
geo_transport = text("tutorials/periodicSteadyUniformPowerLawMPLIC/constant/transportProperties")
hb_h = text("multiphaseMixture/constitutiveEqs/HerschelBulkleySafe/HerschelBulkleySafe.H")
hb_c = text("multiphaseMixture/constitutiveEqs/HerschelBulkleySafe/HerschelBulkleySafe.C")
lib_files = text("multiphaseMixture/Make/files")
api_checker = text("tools/check_rheotool_api.sh")
hb_guide = text("docs/HERSCHELBULKLEY_SAFE.md")

# OpenFOAM-9 application/API invariants
check("OF9 pimple.run loop", "while (pimple.run(runTime))" in main,
      "Main loop uses the OpenFOAM-9 solution-control API.")
check("fvModels migration", "fvModels.preUpdateMesh()" in main and "fvModels.correct()" in main,
      "OF9 fvModels replaces OF7 fvOptions source handling.")
check("fvConstraints migration", "fvConstraints.constrain(UEqn)" in ueqn and "fvConstraints.constrain(U)" in peqn,
      "Equation and field constraints use the OF9 interface.")
check("pressureReference object", "pressureReference pressureReference(p, pimple.dict())" in fields,
      "Physical pressure reference uses the OF9 pressureReference class.")
check("OF9 MULES limitSum", "MULES::limitSum(alphas, alphaPhis, phi_)" in mixture_c,
      "Multi-phase limiting uses the OF9 signature.")
check("OF9 dictionary read", "regIOobject::read()" in mixture_c,
      "Mixture re-read uses the OF9 IOdictionary/regIOobject path.")
check("OF9 libraries", all(token in app_options for token in ("-lfvModels", "-lfvConstraints", "-ltransportModels")),
      "Make/options references the OF9 model and transport libraries.")

# Physical-pressure formulation
all_solver_source = "\n".join((main, fields, ueqn, peqn))
active_source = re.sub(r"/\*.*?\*/|//[^\n]*", "", all_solver_source, flags=re.S)
check("no p_rgh field", "p_rgh" not in active_source,
      "The application advances p directly; explanatory comments are ignored.")
check("no gh/hRef fields", not re.search(r"\bghf?\b|readhRef|ghRef", active_source),
      "Hydrostatic helper fields are absent from active code.")
check("positive gravity source", "+ rho*g" in ueqn,
      "Momentum uses +rho*g under the OpenFOAM physical-acceleration convention.")
check("cyclic physical pressure tutorial", "type cyclic" in case_p and "object      p;" in case_p,
      "Tutorial pressure field uses ordinary cyclic patches.")

# RheoTool coupling and stress semantics
check("one constitutive equation per phase", "autoPtr<constitutiveEq> constitutiveEq_" in phase_h,
      "Each phase owns an OF90 constitutive equation.")
check("phase colour passed to RheoTool", "constitutiveEq_->correct(this)" in phase_c,
      "The alpha field is passed to OF90 correct(alpha,gradU).")
check("GNF stress double-count guard", "if (!iter().isGNF())" in mixture_c and "divTauS() is already" in mixture_c,
      "tau() is not added on top of the complete GNF divTauS stress.")
check("local Safe class registered",
      'TypeName("HerschelBulkleySafe")' in hb_h
      and "addToRunTimeSelectionTable" in hb_c,
      "The package-local model is available through the OF90 constitutive table.")
check("OF90 correct signature",
      "const volScalarField* alpha = nullptr" in hb_h
      and "const volTensorField* gradU = nullptr" in hb_h,
      "The model uses the two-pointer RheoTool OF90 correction API.")
check("Safe class remains GNF",
      "virtual bool isGNF() const" in hb_h and "return true;" in hb_h,
      "The complete stress remains owned by the OF90 GNF divTauS path.")
check("cancellation-safe Papanastasiou",
      "std::expm1" in hb_c and "1. - exp(" not in hb_c,
      "The regularized numerator avoids catastrophic cancellation at startup.")
check("overflow-safe power law",
      "logPowerLaw" in hb_c and "std::log" in hb_c and "std::exp" in hb_c,
      "Strong shear thinning is evaluated in logarithmic form before capping.")
check("finite zero-shear bound",
      "max(gammaDot, VSMALL)" in hb_c and "return etaCap" in hb_c,
      "The closure returns a finite low-shear cap instead of zero or infinity.")
check("HB parameter validation",
      all(token in hb_c for token in
          ("rho must be positive", "eta0 must be positive", "tau0 must be non-negative",
           "k must be non-negative", "n must be positive", "m must be positive")),
      "Material ranges and dimensions are checked before time integration.")
check("OF90 thermal multiplier retained",
      'thermoFunction::New("thermoEta"' in hb_c
      and "thermoEtaPtr_->multiply(eta_)" in hb_c,
      "The local model preserves RheoTool non-isothermal viscosity support.")
check("HB diagnostics available",
      all(token in hb_c for token in
          ('"gammaDot" + name', '"tauTotal" + name', '"IItauD" + name')),
      "Optional strain-rate, total-stress and stress-invariant fields are supplied.")
check("Safe source compiled into custom library",
      "constitutiveEqs/HerschelBulkleySafe/HerschelBulkleySafe.C" in lib_files,
      "The class is built with librheoMultiFluidInterFoamP9 rather than patching RheoTool.")
check("OF90 API checker supplied",
      r"const volTensorField\* gradU" in api_checker
      and "RheoTool OF90 API/header consistency check passed" in api_checker,
      "The build can reject an OF70/of70_plus header tree before compilation.")
check("Allwmake enforces OF90 API check",
      "./tools/check_rheotool_api.sh" in allwmake,
      "The top-level build stops before compilation when the wrong RheoTool API is selected.")
check("Safe documentation supplied",
      "HerschelBulkleySafe" in hb_guide and "Papanastasiou" in hb_guide,
      "The runtime dictionary, formulas, diagnostics and acceptance tests are documented.")
check("RheoTool include root configurable", "RHEOTOOL_SRC ?=" in app_options and "RHEOTOOL_SRC ?=" in lib_options,
      "The OF90 source location can be overridden without editing Make/options.")

# Published multiFluidInterFoam interface treatment
check("phase-specific surface tension", "sigmasPh_" in mixture_h and "fvc::interpolate(Kn(alpha))" in mixture_c,
      "Surface force uses Sigma_i kappa_i grad(alpha_i).")
check("runtime sigma decomposition validation", "validateSigmaDecomposition()" in mixture_c and "checkSigmaDecomposition" in mixture_c,
      "Pairwise and phase-specific surface tensions are checked at startup and on dictionary re-read.")
check("optional curvature smoothing", "smoothCurvature" in mixture_c and "numSmoothingIterations" in mixture_c,
      "The Laplacian VOF filter is runtime-controlled.")
check("smoothing restricted to curvature",
      "nHatfvn(alpha, false)" in mixture_c and "nHatfvn(alpha, true)" in mixture_c,
      "Compression uses raw alpha; only curvature may use the smoothed VOF field.")
check("phase-normal compression", "phic*nHatfn(alpha)" in mixture_c,
      "Artificial compression follows the phase-normal form of the paper.")
check("SIMPLEC branch", "if (simplec)" in peqn and "UEqn.H1()" in peqn,
      "Pressure correction contains the SIMPLEC diagonal correction.")

# OF9 PLIC/MPLIC integration
for scheme in ("PLIC", "PLICU", "MPLIC", "MPLICU"):
    check(f"scheme detection: {scheme}", f'alphaSchemeType == "{scheme}"' in mixture_c,
          "The OF9 geometric scheme is identified explicitly.")
check("self-contained VOF branch", "if (!selfContainedVoFScheme)" in mixture_c,
      "Legacy pairwise compression is bypassed for self-contained OF9 schemes.")
check("geometric cAlpha optional",
      'lookupOrDefault<scalar>("cAlpha", 0.0)' in mixture_c
      and ': alphaControls.lookup<scalar>("cAlpha")' in mixture_c,
      "cAlpha is optional for geometric schemes but mandatory for algebraic schemes.")
check("ungrouped geometric flux", '"phiAlpha"' in mixture_c
      and "fvc::flux(phiAlpha, alpha, alphaScheme)" in mixture_c,
      "MPLIC receives an ungrouped common flux and therefore resolves common U.")
check("PLIC nHatf registration", '"nHatf"' in mixture_c
      and "foundObject<surfaceScalarField>" in mixture_c
      and "nHatfPLIC" in mixture_c,
      "PLIC fallback receives the current phase-specific registered nHatf.")
check("reject geometric phir scheme", "The scheme " in mixture_c
      and "cannot be used for" in mixture_c
      and 'div(phirb,alpha)' in mixture_c,
      "A PLIC-family scheme cannot be applied to the temporary compression flux.")
check("explicit twoPhaseMixture link",
      "-ltwoPhaseMixture" in app_options and "-ltwoPhaseMixture" in lib_options,
      "The PLIC/MPLIC run-time constructors are linked explicitly.")

# Tutorial dictionary invariants
check("tutorial p reference", "pRefCell" in case_solution and "pRefValue" in case_solution,
      "A fallback pressure reference is present for closed variants of the periodic case.")
check("tutorial open upper boundary", all(token in case_u + case_alpha_mud + case_mesh for token in
      ("pressureInletOutletVelocity", "inletOutlet", "type patch")),
      "The atmospheric top is an open patch rather than a wall carrying a pressure boundary condition.")
check("tutorial phase models",
      case_transport.count("parameters") >= 2
      and "type        HerschelBulkleySafe;" in case_transport,
      "The legacy-VOF tutorial selects the package-local safe rheology.")
check("geometric tutorial Safe model",
      "type        HerschelBulkleySafe;" in geo_transport,
      "The PLIC/MPLIC tutorial selects the same safe rheology.")
check("tutorial HB diagnostics",
      all(token in case_transport and token in geo_transport for token in
          ("writeShearRate", "writeStress", "writeSecondInvariantTauDev")),
      "Both tutorials enable the Safe-model diagnostic fields.")
check("legacy phir interpolation is linear",
      "div(phirb,alpha)                    Gauss linear;" in case_schemes,
      "The already-compressive temporary flux uses a conventional interpolation.")
check("MPLIC tutorial active", "div(phi,alpha)                      Gauss MPLIC;" in geo_schemes,
      "The geometric smoke case activates MPLIC.")
check("geometric tutorial omits cAlpha", "cAlpha" not in re.sub(r"//[^\n]*", "", geo_solution),
      "The MPLIC case proves that cAlpha is not required by the geometric branch.")
check("PLIC fallback syntax", "Gauss PLIC interfaceCompression vanLeer 1;" in geo_plic,
      "The standard OF9 PLIC fallback syntax is supplied.")
check("PLICU fallback syntax", "Gauss PLICU interfaceCompression vanLeer 1;" in geo_plicu,
      "The standard OF9 PLICU fallback syntax is supplied.")
check("MPLICU syntax", "Gauss MPLICU;" in geo_mplicu,
      "The velocity-weighted MPLIC template is supplied.")
check("direct interfaceCompression syntax", "Gauss interfaceCompression vanLeer 1;" in geo_interface,
      "The complete OF9 interfaceCompression syntax is supplied.")
check("legacy selector restores cAlpha", "Gauss vanLeer01;" in geo_legacy
      and "fvSolution.legacy" in geo_selector,
      "The selector restores the legacy algebraic branch and its cAlpha dictionary.")
all_geo_schemes = (geo_schemes, geo_plic, geo_plicu, geo_mplicu, geo_interface, geo_legacy)
check("all phir templates linear", all("div(phirb,alpha)                    Gauss linear;" in item for item in all_geo_schemes),
      "No supplied case applies a geometric/compression scheme to phirb.")

# Check the two-phase sigma decomposition in the supplied case.
pair = re.search(r"\(mud air\)\s+([0-9.eE+-]+)", case_transport)
mud = re.search(r"\(mud mud\)\s+([0-9.eE+-]+)", case_transport)
air = re.search(r"\(air air\)\s+([0-9.eE+-]+)", case_transport)
consistent_sigma = False
if pair and mud and air:
    pair_v = float(pair.group(1))
    phasic_sum = float(mud.group(1)) + float(air.group(1))
    consistent_sigma = abs(pair_v - phasic_sum) <= 1e-12 * max(1.0, abs(pair_v))
check("tutorial sigma decomposition", consistent_sigma,
      "Sigma_mud + Sigma_air equals sigma_mud-air.")

# Reject known OF7-only API tokens in active source/Make files.
legacy_tokens = {
    "turbulentTransportModel.H": all_solver_source + app_options,
    "incompressible::turbulenceModel": all_solver_source,
    "createFvOptions.H": all_solver_source,
    "fvOptions(": all_solver_source,
    "setRefCell": all_solver_source,
    "MULES::limitSum(alphaPhi": mixture_c,
    "transportModel::read()": mixture_c,
}
for token, haystack in legacy_tokens.items():
    check(f"legacy token absent: {token}", token not in haystack,
          "OF7-only syntax is not present in active port files.")

passed = sum(ok for _, ok, _ in checks)
failed = len(checks) - passed

print("rheoMultiFluidInterFoamP OF9 HBSAFE/PLIC/MPLIC static audit")
print(f"root: {ROOT}")
print(f"checks: {len(checks)}  passed: {passed}  failed: {failed}\n")

for name, ok, detail in checks:
    status = "PASS" if ok else "FAIL"
    print(f"[{status}] {name}\n       {detail}")

sys.exit(1 if failed else 0)
