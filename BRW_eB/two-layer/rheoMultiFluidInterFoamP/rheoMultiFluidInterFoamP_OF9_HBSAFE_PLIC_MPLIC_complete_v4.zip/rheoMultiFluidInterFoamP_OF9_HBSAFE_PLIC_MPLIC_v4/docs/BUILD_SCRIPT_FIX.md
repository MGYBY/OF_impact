# Build-script correction

The original distributed `Allwmake` enabled POSIX shell nounset mode with
`set -eu` before sourcing OpenFOAM 9's `AllwmakeParseArguments`.

OpenFOAM 9's parser intentionally leaves variables such as `targetType` and
`targetSpace` unset when the default target is requested. Under the normal
OpenFOAM build scripts, an unset variable expands to an empty string. With
`set -u`, however, the parser aborts with:

```text
AllwmakeParseArguments: targetType: parameter not set
```

The correction is to use:

```sh
set -e
```

rather than:

```sh
set -eu
```

No solver C++ source, equations, or build options are changed by this fix.
