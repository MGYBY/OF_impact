# PLIC, PLICU, MPLIC and MPLICU compatibility

## Scope

This note describes the OpenFOAM Foundation 9 compatibility layer added to
`rheoMultiFluidInterFoamP`.  It applies to the phase-fraction interpolation
entry named:

```foam
div(phi,alpha)
```

The implementation supports:

```text
interfaceCompression
noInterfaceCompression
PLIC
PLICU
MPLIC
MPLICU
```

as self-contained OpenFOAM 9 interface-capturing schemes.  The historical
`multiFluidInterFoam` algebraic branch remains available for schemes such as
`vanLeer` and `vanLeer01`.

## Why the previous OF9 port failed

The first OF9 port inherited the stock `multiphaseInterFoam` n-phase transport
pattern:

```text
advective phase flux from div(phi,alpha)
+ a separate pairwise artificial-compression flux from div(phirb,alpha)
+ MULES limiting of every phase
+ MULES::limitSum for the n-phase flux sum
```

That pattern predates the integration of the OF9 PLIC-family interpolation
schemes into the two-phase VOF framework.  It causes three distinct problems.

### 1. A PLIC-family scheme could be applied to the temporary compression flux

The nested pairwise term evaluates `fvc::flux` with a temporary flux called
`phirb`.  OF9 MPLIC reconstructs the velocity-field name from the group of the
flux passed to it.  A grouped or expression-derived temporary flux can
therefore make MPLIC search for a non-existent field such as `U.<expression>`.

The corrected solver permits PLIC/MPLIC only on `div(phi,alpha)`.  If a
PLIC-family or `interfaceCompression` scheme is selected for
`div(phirb,alpha)`, the solver stops immediately with an explanatory error.
The safe legacy entry is:

```foam
div(phirb,alpha)    Gauss linear;
```

### 2. Two interface-sharpening methods were combined

PLIC, PLICU, MPLIC and MPLICU calculate the complete phase face interpolation
for the physical flux.  Adding the old pairwise compression flux afterward
would sharpen the same interface a second time.  The updated solver disables
its separate pairwise compression branch whenever a self-contained OF9 VOF
scheme is selected.

The published phase-normal pairwise compression remains active only for an
algebraic base scheme such as `vanLeer01`.

### 3. PLIC fallback requires `nHatf`

The normal OF9 PLIC syntax uses `interfaceCompression` as a fallback:

```foam
div(phi,alpha)    Gauss PLIC interfaceCompression vanLeer 1;
```

The OF9 `interfaceCompression` interpolation looks up a registered
`surfaceScalarField` named exactly `nHatf`.  The n-phase custom mixture has one
normal per phase and did not previously register this field.

During construction of each PLIC/PLICU phase flux, the compatibility layer now
registers that phase's raw-alpha normal temporarily as `nHatf`, constructs the
flux, and then removes the temporary object before proceeding to the next
phase.

## Implemented policy

| `div(phi,alpha)` scheme | Separate published pairwise compression | `cAlpha` in `fvSolution` |
|---|---:|---:|
| algebraic scheme, e.g. `vanLeer01` | enabled | required |
| `interfaceCompression` | disabled | not required; coefficient is in `fvSchemes` |
| `noInterfaceCompression` | disabled | not required |
| `PLIC`, `PLICU`, `MPLIC`, `MPLICU` | disabled | not required |

All branches retain:

```text
MULES::limit(...)
MULES::limitSum(alphas, alphaPhis, phi_)
MULES::explicitSolve(...)
```

and the post-solve phase-sum drift correction.

## Recommended `fvSchemes` entries

### MPLIC

```foam
divSchemes
{
    div(phi,alpha)      Gauss MPLIC;
    div(phirb,alpha)    Gauss linear;
}
```

### MPLICU

```foam
divSchemes
{
    div(phi,alpha)      Gauss MPLICU;
    div(phirb,alpha)    Gauss linear;
}
```

### PLIC

```foam
divSchemes
{
    div(phi,alpha)      Gauss PLIC interfaceCompression vanLeer 1;
    div(phirb,alpha)    Gauss linear;
}
```

### PLICU

```foam
divSchemes
{
    div(phi,alpha)      Gauss PLICU interfaceCompression vanLeer 1;
    div(phirb,alpha)    Gauss linear;
}
```

### Direct OF9 interface compression

```foam
divSchemes
{
    div(phi,alpha)      Gauss interfaceCompression vanLeer 1;
    div(phirb,alpha)    Gauss linear;
}
```

### Historical multiFluidInterFoam branch

```foam
divSchemes
{
    div(phi,alpha)      Gauss vanLeer01;
    div(phirb,alpha)    Gauss linear;
}
```

with:

```foam
"alpha.*"
{
    nAlphaSubCycles    4;
    cAlpha             1;
}
```

Do **not** write:

```foam
div(phirb,alpha)    Gauss PLIC;
div(phirb,alpha)    Gauss MPLIC;
div(phirb,alpha)    Gauss interfaceCompression;
```

The last entry is both incomplete OF9 syntax and conceptually wrong: `phirb`
already represents the explicitly constructed compression velocity.

## Supplied test case and selector

The case:

```text
tutorials/periodicSteadyUniformPowerLawMPLIC
```

is delivered with MPLIC active and with no `cAlpha` keyword.  Switch schemes
with:

```bash
./selectVoFScheme MPLIC
./selectVoFScheme MPLICU
./selectVoFScheme PLIC
./selectVoFScheme PLICU
./selectVoFScheme interfaceCompression
./selectVoFScheme legacy
```

The selector also installs the matching `fvSolution`: geometric choices omit
`cAlpha`, while the legacy branch restores it.

## What appears in the solver log

When the active scheme changes, the solver prints a line such as:

```text
Phase-fraction advection scheme: MPLIC (self-contained OF9 VOF scheme; separate pairwise compression disabled)
```

or:

```text
Phase-fraction advection scheme: vanLeer01 (algebraic advection with pairwise compression, cAlpha = 1)
```

This line should be retained in every validation log.

## Scientific limitation for three or more phases

The compatibility layer applies the OF9 geometric interpolation independently
to every transported phase fraction and subsequently enforces the common flux
sum with `MULES::limitSum`.  This is not a single coupled multi-material PLIC
reconstruction of a triple-junction cell.

Consequently:

- two-phase mud-air roll-wave use is the primary supported target;
- three-phase calculations are source-compatible, but triple-junction geometry,
  contact angles, parasitic currents, phase-volume conservation and convergence
  must be tested before scientific use;
- no claim of geometrically exact n-material reconstruction is made.
