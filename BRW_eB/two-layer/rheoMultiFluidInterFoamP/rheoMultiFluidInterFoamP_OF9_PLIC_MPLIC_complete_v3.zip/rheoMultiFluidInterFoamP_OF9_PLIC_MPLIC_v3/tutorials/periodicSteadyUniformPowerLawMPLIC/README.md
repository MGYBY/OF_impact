# Periodic power-law film with OF9 PLIC/MPLIC

This is the geometric-interface smoke/regression companion to
`periodicSteadyUniformPowerLaw`.  It uses the same two-phase physical-pressure
periodic film, but exercises the new OpenFOAM 9 PLIC-family compatibility
branch.

MPLIC is active by default:

```foam
div(phi,alpha)      Gauss MPLIC;
div(phirb,alpha)    Gauss linear;
```

The active alpha solver block deliberately omits `cAlpha`.  The corrected
solver requires `cAlpha` only when an algebraic scheme such as `vanLeer01`
activates the separate published n-phase pairwise-compression branch.

## Select a VOF scheme

Use the supplied selector:

```bash
./selectVoFScheme MPLIC
./selectVoFScheme MPLICU
./selectVoFScheme PLIC
./selectVoFScheme PLICU
./selectVoFScheme interfaceCompression
./selectVoFScheme legacy
```

The selector copies both the matching `fvSchemes` and `fvSolution` files.  The
PLIC variants use the standard OF9 fallback syntax:

```foam
div(phi,alpha)    Gauss PLIC interfaceCompression vanLeer 1;
```

## Run

```bash
./selectVoFScheme MPLIC
./Allrun
```

The solver log should include:

```text
Phase-fraction advection scheme: MPLIC (self-contained OF9 VOF scheme; separate pairwise compression disabled)
```

For the legacy selection, it should instead report that pairwise compression
is enabled and print the active `cAlpha` value.

## Required checks

At minimum, compare all selected schemes using:

- boundedness of every phase fraction;
- `min(sum(alpha_i))` and `max(sum(alpha_i))`;
- integrated volume of each phase;
- phase-weighted liquid discharge and maximum velocity;
- cyclic face-flux matching;
- interface thickness and spurious currents;
- timestep and grid convergence.

Do not put PLIC, MPLIC or `interfaceCompression` under
`div(phirb,alpha)`.  `phirb` is already the explicit compression flux used by
the legacy branch; its safe interpolation is `Gauss linear`.

This remains a smoke/regression case, not a completed CFD validation of the
geometric scheme.  See `../../docs/PLIC_MPLIC_COMPATIBILITY.md` and
`../../docs/LOCAL_ACCEPTANCE_TESTS.md`.
