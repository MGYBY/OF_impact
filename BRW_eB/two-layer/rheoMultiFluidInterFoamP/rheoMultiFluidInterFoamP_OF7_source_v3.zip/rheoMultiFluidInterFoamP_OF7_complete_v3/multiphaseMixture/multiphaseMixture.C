/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     | Website:  https://openfoam.org
    \\  /    A nd           | Copyright (C) 2011-2019 OpenFOAM Foundation
     \\/     M anipulation  |
-------------------------------------------------------------------------------
License
    This file is distributed under the GNU General Public License v3 or later.

\*---------------------------------------------------------------------------*/

#include "multiphaseMixture.H"
#include "alphaContactAngleFvPatchScalarField.H"
#include "Time.H"
#include "subCycle.H"
#include "MULES.H"
#include "surfaceInterpolate.H"
#include "fvcGrad.H"
#include "fvcSnGrad.H"
#include "fvcDiv.H"
#include "fvcFlux.H"
#include "upwind.H"
#include "calculatedFvPatchFields.H"
#include <cmath>

namespace Foam
{

const scalar multiphaseMixture::convertToRad =
    constant::mathematical::pi/180.0;


void multiphaseMixture::calcAlphas()
{
    scalar level = 0.0;
    alphas_ == 0.0;

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        alphas_ += level*iter();
        level += 1.0;
    }
}


bool multiphaseMixture::hasContactAngleBoundary() const
{
    forAllConstIter(PtrDictionary<phase>, phases_, iter)
    {
        const volScalarField::Boundary& boundary = iter().boundaryField();

        forAll(boundary, patchi)
        {
            if (isA<alphaContactAngleFvPatchScalarField>(boundary[patchi]))
            {
                return true;
            }
        }
    }

    return false;
}


scalar multiphaseMixture::physicalSigma
(
    const phase& alpha1,
    const phase& alpha2
) const
{
    const interfacePair pair(alpha1, alpha2);
    const sigmaTable::const_iterator sigma = sigmas_.find(pair);

    if (sigma == sigmas_.end())
    {
        FatalErrorInFunction
            << "Missing physical surface tension for interface "
            << pair << " in sigmas."
            << exit(FatalError);
    }

    return sigma();
}


void multiphaseMixture::decomposeSurfaceTensions()
{
    sigmasPh_.clear();

    List<const phase*> phaseList(phases_.size());
    label phasei = 0;

    forAllConstIter(PtrDictionary<phase>, phases_, iter)
    {
        phaseList[phasei++] = &iter();
    }

    if (phaseList.size() == 1)
    {
        sigmasPh_.insert
        (
            interfacePair(*phaseList[0], *phaseList[0]),
            0.0
        );
        return;
    }

    List<scalar> phaseSigma(phaseList.size(), 0.0);

    if (phaseList.size() == 2)
    {
        const scalar halfSigma =
            0.5*physicalSigma(*phaseList[0], *phaseList[1]);

        phaseSigma[0] = halfSigma;
        phaseSigma[1] = halfSigma;
    }
    else
    {
        const scalar sigma01 =
            physicalSigma(*phaseList[0], *phaseList[1]);
        const scalar sigma02 =
            physicalSigma(*phaseList[0], *phaseList[2]);
        const scalar sigma12 =
            physicalSigma(*phaseList[1], *phaseList[2]);

        phaseSigma[0] = 0.5*(sigma01 + sigma02 - sigma12);
        phaseSigma[1] = sigma01 - phaseSigma[0];
        phaseSigma[2] = sigma02 - phaseSigma[0];

        for (label i = 3; i < phaseList.size(); ++i)
        {
            phaseSigma[i] =
                physicalSigma(*phaseList[0], *phaseList[i])
              - phaseSigma[0];
        }
    }

    forAll(phaseSigma, i)
    {
        sigmasPh_.insert
        (
            interfacePair(*phaseList[i], *phaseList[i]),
            phaseSigma[i]
        );
    }

    Info<< "Automatically decomposed physical surface tensions into "
        << "phase-specific coefficients:" << nl;

    forAll(phaseSigma, i)
    {
        Info<< "    Sigma_" << phaseList[i]->name()
            << " = " << phaseSigma[i] << nl;
    }
}


void multiphaseMixture::validateSurfaceTensions() const
{
    if
    (
        surfaceTensionModel_ != "phaseSpecific"
     && surfaceTensionModel_ != "pairwise"
    )
    {
        FatalErrorInFunction
            << "Unknown surfaceTensionModel '" << surfaceTensionModel_ << "'." << nl
            << "Valid choices are phaseSpecific and pairwise."
            << exit(FatalError);
    }

    if (surfaceTensionTolerance_ < 0)
    {
        FatalErrorInFunction
            << "surfaceTensionConsistencyTolerance must be non-negative"
            << exit(FatalError);
    }

    forAllConstIter(PtrDictionary<phase>, phases_, iter1)
    {
        const phase& alpha1 = iter1();

        PtrDictionary<phase>::const_iterator iter2 = iter1;
        ++iter2;

        for (; iter2 != phases_.end(); ++iter2)
        {
            const phase& alpha2 = iter2();
            const interfacePair pair(alpha1, alpha2);

            const sigmaTable::const_iterator sigma = sigmas_.find(pair);

            if (sigma == sigmas_.end())
            {
                FatalErrorInFunction
                    << "Missing physical surface tension for interface "
                    << pair << " in sigmas."
                    << exit(FatalError);
            }

            if (!std::isfinite(sigma()) || sigma() < 0.0)
            {
                FatalErrorInFunction
                    << "Physical surface tension for interface " << pair
                    << " must be finite and non-negative, but is "
                    << sigma() << '.'
                    << exit(FatalError);
            }

            if (surfaceTensionModel_ == "phaseSpecific")
            {
                const sigmaTable::const_iterator sigma1 =
                    sigmasPh_.find(interfacePair(alpha1, alpha1));
                const sigmaTable::const_iterator sigma2 =
                    sigmasPh_.find(interfacePair(alpha2, alpha2));

                if (sigma1 == sigmasPh_.end() || sigma2 == sigmasPh_.end())
                {
                    FatalErrorInFunction
                        << "The phaseSpecific model requires one self-pair "
                        << "entry in sigmasPh for every phase." << nl
                        << "Missing an entry for phase " << alpha1.name()
                        << " or " << alpha2.name() << '.'
                        << exit(FatalError);
                }

                const scalar sigmaPair = sigma();
                const scalar sigmaDecomposed = sigma1() + sigma2();
                const scalar scale = max
                (
                    max(mag(sigmaPair), mag(sigmaDecomposed)),
                    scalar(VSMALL)
                );

                if
                (
                    mag(sigmaPair - sigmaDecomposed)
                  > surfaceTensionTolerance_*scale
                )
                {
                    FatalErrorInFunction
                        << "Inconsistent surface-tension decomposition for "
                        << pair << '.' << nl
                        << "    sigmas pair value      = " << sigmaPair << nl
                        << "    sigmasPh self-pair sum = "
                        << sigmaDecomposed << nl
                        << "The phase-specific formulation requires "
                        << "sigma_ij = Sigma_i + Sigma_j."
                        << exit(FatalError);
                }
            }
        }
    }

    if
    (
        surfaceTensionModel_ == "phaseSpecific"
     && hasContactAngleBoundary()
    )
    {
        WarningInFunction
            << "Pair-resolved alphaContactAngle boundary conditions were "
            << "detected while surfaceTensionModel is phaseSpecific.  The "
            << "phase-specific curvature has no unique pair at a wall.  "
            << "Use surfaceTensionModel pairwise when pair-resolved contact "
            << "angles are essential." << nl;
    }
}


multiphaseMixture::multiphaseMixture
(
    const volVectorField& U,
    const surfaceScalarField& phi
)
:
    IOdictionary
    (
        IOobject
        (
            "transportProperties",
            U.time().constant(),
            U.db(),
            IOobject::MUST_READ_IF_MODIFIED,
            IOobject::NO_WRITE
        )
    ),
    phases_(lookup("phases"), phase::iNew(U, phi)),
    mesh_(U.mesh()),
    U_(U),
    phi_(phi),
    rhoPhi_
    (
        IOobject
        (
            "rhoPhi",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        mesh_,
        dimensionedScalar(dimMass/dimTime, 0)
    ),
    alphas_
    (
        IOobject
        (
            "alphas",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::AUTO_WRITE
        ),
        mesh_,
        dimensionedScalar(dimless, 0)
    ),
    nu_
    (
        IOobject
        (
            "nu",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        mu()/rho()
    ),
    sigmas_(),
    dimSigma_(1, 0, -2, 0, 0),
    sigmasPh_(),
    dimSigmaPh_(1, 0, -2, 0, 0),
    surfaceTensionModel_
    (
        lookupOrDefault<word>("surfaceTensionModel", "phaseSpecific")
    ),
    surfaceTensionTolerance_
    (
        lookupOrDefault<scalar>("surfaceTensionConsistencyTolerance", 1e-8)
    ),
    deltaN_
    (
        "deltaN",
        1e-8/pow(average(mesh_.V()), 1.0/3.0)
    ),
    tauMF_
    (
        IOobject
        (
            "tauMF",
            U.time().timeName(),
            U.mesh(),
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        U.mesh(),
        dimensionedSymmTensor
        (
            "zero",
            dimensionSet(1, -1, -2, 0, 0, 0, 0),
            symmTensor::zero
        ),
        calculatedFvPatchField<symmTensor>::typeName
    )
{
    if (phases_.empty())
    {
        FatalErrorInFunction
            << "The phases list is empty."
            << exit(FatalError);
    }

    lookup("sigmas") >> sigmas_;

    if (found("sigmasPh"))
    {
        lookup("sigmasPh") >> sigmasPh_;
    }
    else if (surfaceTensionModel_ == "phaseSpecific")
    {
        decomposeSurfaceTensions();
    }

    validateSurfaceTensions();
    calcAlphas();

    // Constitutive constructors initialise themselves, but a common explicit
    // correction keeps all phase and compatibility viscosity fields aligned.
    correct();
    nu_ = mu()/rho();
}


tmp<fvVectorMatrix> multiphaseMixture::divTauMF(volVectorField& U)
{
    tauMF_ = dimensionedSymmTensor
    (
        "zero",
        tauMF_.dimensions(),
        symmTensor::zero
    );

    bool hasDifferentialExtraStress = false;

    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<volScalarField> tAlpha = min(max(iter(), scalar(0)), scalar(1));
    tmp<fvVectorMatrix> tDivTau = iter().divTauS(U, tAlpha());
    fvVectorMatrix& divTau = tDivTau.ref();

    if (!iter().isGNF())
    {
        tauMF_ += tAlpha()*iter().tau();
        hasDifferentialExtraStress = true;
    }

    for (++iter; iter != phases_.end(); ++iter)
    {
        tAlpha = min(max(iter(), scalar(0)), scalar(1));
        divTau += iter().divTauS(U, tAlpha());

        if (!iter().isGNF())
        {
            tauMF_ += tAlpha()*iter().tau();
            hasDifferentialExtraStress = true;
        }
    }

    tauMF_.correctBoundaryConditions();

    if (hasDifferentialExtraStress && U.time().outputTime())
    {
        tauMF_.write();
    }

    if (hasDifferentialExtraStress)
    {
        return tDivTau + fvc::div(tauMF_, "div(Sum(tau))");
    }

    return tDivTau;
}


tmp<volSymmTensorField> multiphaseMixture::tauTotalMF() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<volScalarField> tAlpha = min(max(iter(), scalar(0)), scalar(1));
    tmp<volSymmTensorField> tTau = tAlpha()*iter().tauTotal();
    volSymmTensorField& tau = tTau.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        tAlpha = min(max(iter(), scalar(0)), scalar(1));
        tau += tAlpha()*iter().tauTotal();
    }

    return tTau;
}


tmp<volScalarField> multiphaseMixture::rho() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<volScalarField> tRho = iter()*iter().rho();
    volScalarField& mixtureRho = tRho.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        mixtureRho += iter()*iter().rho();
    }

    return tRho;
}


tmp<scalarField> multiphaseMixture::rho(const label patchi) const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<scalarField> tRho =
        iter().boundaryField()[patchi]*iter().rho().value();
    scalarField& mixtureRho = tRho.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        mixtureRho +=
            iter().boundaryField()[patchi]*iter().rho().value();
    }

    return tRho;
}


tmp<volScalarField> multiphaseMixture::mu() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<volScalarField> tMu = iter()*iter().rho()*iter().nu();
    volScalarField& mixtureMu = tMu.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        mixtureMu += iter()*iter().rho()*iter().nu();
    }

    return tMu;
}


tmp<scalarField> multiphaseMixture::mu(const label patchi) const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<scalarField> tMu =
        iter().boundaryField()[patchi]
       *iter().rho().value()
       *iter().nu(patchi);
    scalarField& mixtureMu = tMu.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        mixtureMu +=
            iter().boundaryField()[patchi]
           *iter().rho().value()
           *iter().nu(patchi);
    }

    return tMu;
}


tmp<surfaceScalarField> multiphaseMixture::muf() const
{
    PtrDictionary<phase>::const_iterator iter = phases_.begin();

    tmp<surfaceScalarField> tMuf =
        fvc::interpolate(iter())
       *iter().rho()
       *fvc::interpolate(iter().nu());
    surfaceScalarField& mixtureMuf = tMuf.ref();

    for (++iter; iter != phases_.end(); ++iter)
    {
        mixtureMuf +=
            fvc::interpolate(iter())
           *iter().rho()
           *fvc::interpolate(iter().nu());
    }

    return tMuf;
}


tmp<volScalarField> multiphaseMixture::nu() const
{
    return nu_;
}


tmp<scalarField> multiphaseMixture::nu(const label patchi) const
{
    return nu_.boundaryField()[patchi];
}


tmp<surfaceScalarField> multiphaseMixture::nuf() const
{
    return muf()/fvc::interpolate(rho());
}


void multiphaseMixture::smoothen(volScalarField& field) const
{
    const dictionary& alphaControls = mesh_.solverDict("alpha");

    const label nIterations = alphaControls.lookupOrDefault<label>
    (
        "nSmoothingIterations",
        alphaControls.lookupOrDefault<label>
        (
            "numSmoothingIterations_",
            0
        )
    );

    const Switch smoothCurvature = alphaControls.lookupOrDefault<Switch>
    (
        "smoothCurvature",
        alphaControls.lookupOrDefault<Switch>("smoothKn_", false)
    );

    if (!smoothCurvature || nIterations <= 0)
    {
        return;
    }

    const labelList& owner = mesh_.faceOwner();
    const labelList& neighbour = mesh_.faceNeighbour();
    const surfaceScalarField& magSf = mesh_.magSf();

    for (label iteration = 0; iteration < nIterations; ++iteration)
    {
        scalarField weightedSum(mesh_.nCells(), 0.0);
        scalarField areaSum(mesh_.nCells(), 0.0);

        const surfaceScalarField faceField(fvc::interpolate(field));

        forAll(neighbour, facei)
        {
            const scalar area = magSf[facei];
            const scalar value = faceField[facei];

            weightedSum[owner[facei]] += value*area;
            areaSum[owner[facei]] += area;

            weightedSum[neighbour[facei]] += value*area;
            areaSum[neighbour[facei]] += area;
        }

        forAll(mesh_.boundary(), patchi)
        {
            const unallocLabelList& faceCells =
                mesh_.boundary()[patchi].faceCells();
            const fvsPatchScalarField& patchField =
                faceField.boundaryField()[patchi];
            const fvsPatchScalarField& patchArea =
                magSf.boundaryField()[patchi];

            forAll(faceCells, facei)
            {
                const label celli = faceCells[facei];
                weightedSum[celli] += patchField[facei]*patchArea[facei];
                areaSum[celli] += patchArea[facei];
            }
        }

        forAll(field, celli)
        {
            if (areaSum[celli] > VSMALL)
            {
                field[celli] = weightedSum[celli]/areaSum[celli];
            }
        }

        field.correctBoundaryConditions();
    }
}


tmp<surfaceVectorField> multiphaseMixture::pairNormalfv
(
    const volScalarField& alpha1,
    const volScalarField& alpha2
) const
{
    surfaceVectorField gradAlphaf
    (
        fvc::interpolate(alpha2)*fvc::interpolate(fvc::grad(alpha1))
      - fvc::interpolate(alpha1)*fvc::interpolate(fvc::grad(alpha2))
    );

    return gradAlphaf/(mag(gradAlphaf) + deltaN_);
}


tmp<surfaceScalarField> multiphaseMixture::phaseNormalFlux
(
    const volScalarField& alpha
) const
{
    // Published Eq. (23)-(24): compression uses the raw phase normal n_i.
    const surfaceVectorField gradAlphaf
    (
        fvc::interpolate(fvc::grad(alpha))
    );

    return (gradAlphaf/(mag(gradAlphaf) + deltaN_)) & mesh_.Sf();
}


tmp<surfaceVectorField> multiphaseMixture::phaseCurvatureNormalfv
(
    const volScalarField& alpha
) const
{
    volScalarField alphaForCurvature(alpha);
    smoothen(alphaForCurvature);

    const surfaceVectorField gradAlphaf
    (
        fvc::interpolate(fvc::grad(alphaForCurvature))
    );

    return gradAlphaf/(mag(gradAlphaf) + deltaN_);
}


void multiphaseMixture::correctContactAngle
(
    const phase& alpha1,
    const phase& alpha2,
    surfaceVectorField::Boundary& nHatb
) const
{
    const volScalarField::Boundary& boundary1 = alpha1.boundaryField();
    const volScalarField::Boundary& boundary2 = alpha2.boundaryField();

    forAll(boundary1, patchi)
    {
        const alphaContactAngleFvPatchScalarField* acapPtr = nullptr;

        if (isA<alphaContactAngleFvPatchScalarField>(boundary1[patchi]))
        {
            acapPtr =
                &refCast<const alphaContactAngleFvPatchScalarField>
                (
                    boundary1[patchi]
                );
        }
        else if (isA<alphaContactAngleFvPatchScalarField>(boundary2[patchi]))
        {
            acapPtr =
                &refCast<const alphaContactAngleFvPatchScalarField>
                (
                    boundary2[patchi]
                );
        }

        if (acapPtr == nullptr)
        {
            continue;
        }

        const alphaContactAngleFvPatchScalarField& acap = *acapPtr;
        vectorField& nHatPatch = nHatb[patchi];

        const vectorField AfHatPatch
        (
            mesh_.Sf().boundaryField()[patchi]
           /mesh_.magSf().boundaryField()[patchi]
        );

        alphaContactAngleFvPatchScalarField::thetaPropsTable::const_iterator tp =
            acap.thetaProps().find(interfacePair(alpha1, alpha2));

        if (tp == acap.thetaProps().end())
        {
            FatalErrorInFunction
                << "Cannot find interface " << interfacePair(alpha1, alpha2)
                << " in thetaProperties for patch " << acap.patch().name()
                << exit(FatalError);
        }

        const bool matched = (tp.key().first() == alpha1.name());

        const scalar theta0 = convertToRad*tp().theta0(matched);
        scalarField theta(boundary1[patchi].size(), theta0);

        const scalar uTheta = tp().uTheta();

        if (uTheta > small)
        {
            const scalar thetaA = convertToRad*tp().thetaA(matched);
            const scalar thetaR = convertToRad*tp().thetaR(matched);

            vectorField Uwall
            (
                U_.boundaryField()[patchi].patchInternalField()
              - U_.boundaryField()[patchi]
            );
            Uwall -= (AfHatPatch & Uwall)*AfHatPatch;

            vectorField nWall
            (
                nHatPatch - (AfHatPatch & nHatPatch)*AfHatPatch
            );
            nWall /= (mag(nWall) + small);

            const scalarField uwall(nWall & Uwall);
            theta += (thetaA - thetaR)*tanh(uwall/uTheta);
        }

        scalarField a12(nHatPatch & AfHatPatch);
        a12 = max(min(a12, scalar(1) - small), -scalar(1) + small);

        const scalarField b1(cos(theta));
        scalarField b2(nHatPatch.size());

        forAll(b2, facei)
        {
            b2[facei] = cos(acos(a12[facei]) - theta[facei]);
        }

        const scalarField det(max(1.0 - a12*a12, scalar(small)));
        const scalarField a((b1 - a12*b2)/det);
        const scalarField b((b2 - a12*b1)/det);

        nHatPatch = a*AfHatPatch + b*nHatPatch;
        nHatPatch /= (mag(nHatPatch) + deltaN_.value());
    }
}


tmp<volScalarField> multiphaseMixture::pairCurvature
(
    const phase& alpha1,
    const phase& alpha2
) const
{
    tmp<surfaceVectorField> tNormal = pairNormalfv(alpha1, alpha2);

    correctContactAngle
    (
        alpha1,
        alpha2,
        tNormal.ref().boundaryFieldRef()
    );

    return -fvc::div(tNormal & mesh_.Sf());
}


tmp<volScalarField> multiphaseMixture::phaseCurvature
(
    const phase& alpha
) const
{
    tmp<surfaceVectorField> tNormal = phaseCurvatureNormalfv(alpha);
    return -fvc::div(tNormal & mesh_.Sf());
}


tmp<surfaceScalarField> multiphaseMixture::surfaceTensionForce() const
{
    tmp<surfaceScalarField> tForce
    (
        surfaceScalarField::New
        (
            "surfaceTensionForce",
            mesh_,
            dimensionedScalar(dimensionSet(1, -2, -2, 0, 0), 0)
        )
    );

    surfaceScalarField& force = tForce.ref();

    if (surfaceTensionModel_ == "phaseSpecific")
    {
        forAllConstIter(PtrDictionary<phase>, phases_, iter)
        {
            const phase& alpha = iter();
            const sigmaTable::const_iterator sigma =
                sigmasPh_.find(interfacePair(alpha, alpha));

            if (sigma == sigmasPh_.end())
            {
                FatalErrorInFunction
                    << "Missing phase-specific surface tension for phase "
                    << alpha.name() << exit(FatalError);
            }

            force +=
                dimensionedScalar(dimSigmaPh_, sigma())
               *fvc::interpolate(phaseCurvature(alpha))
               *fvc::snGrad(alpha);
        }
    }
    else
    {
        forAllConstIter(PtrDictionary<phase>, phases_, iter1)
        {
            const phase& alpha1 = iter1();

            PtrDictionary<phase>::const_iterator iter2 = iter1;
            ++iter2;

            for (; iter2 != phases_.end(); ++iter2)
            {
                const phase& alpha2 = iter2();
                const sigmaTable::const_iterator sigma =
                    sigmas_.find(interfacePair(alpha1, alpha2));

                if (sigma == sigmas_.end())
                {
                    FatalErrorInFunction
                        << "Missing surface tension for interface "
                        << interfacePair(alpha1, alpha2)
                        << exit(FatalError);
                }

                force +=
                    dimensionedScalar(dimSigma_, sigma())
                   *fvc::interpolate(pairCurvature(alpha1, alpha2))
                   *
                    (
                        fvc::interpolate(alpha2)*fvc::snGrad(alpha1)
                      - fvc::interpolate(alpha1)*fvc::snGrad(alpha2)
                    );
            }
        }
    }

    return tForce;
}


tmp<volScalarField> multiphaseMixture::nearInterface() const
{
    tmp<volScalarField> tNear
    (
        volScalarField::New
        (
            "nearInterface",
            mesh_,
            dimensionedScalar(dimless, 0)
        )
    );

    forAllConstIter(PtrDictionary<phase>, phases_, iter)
    {
        tNear.ref() =
            max(tNear(), pos0(iter() - 0.01)*pos0(0.99 - iter()));
    }

    return tNear;
}


void multiphaseMixture::solve()
{
    const Time& runTime = mesh_.time();
    volScalarField& alpha = phases_.first();

    const dictionary& alphaControls = mesh_.solverDict("alpha");
    const label nAlphaSubCycles
    (
        alphaControls.lookupOrDefault<label>("nAlphaSubCycles", 1)
    );
    const scalar cAlpha
    (
        alphaControls.lookupOrDefault<scalar>("cAlpha", 1.0)
    );

    if (nAlphaSubCycles < 1)
    {
        FatalErrorInFunction
            << "nAlphaSubCycles must be at least 1, but is "
            << nAlphaSubCycles << exit(FatalError);
    }

    if (cAlpha < 0.0 || cAlpha > 4.0)
    {
        FatalErrorInFunction
            << "cAlpha must lie in the published range [0, 4], but is "
            << cAlpha << exit(FatalError);
    }

    if (nAlphaSubCycles > 1)
    {
        surfaceScalarField rhoPhiSum
        (
            IOobject
            (
                "rhoPhiSum",
                runTime.timeName(),
                mesh_,
                IOobject::NO_READ,
                IOobject::NO_WRITE
            ),
            mesh_,
            dimensionedScalar(rhoPhi_.dimensions(), 0)
        );

        const dimensionedScalar totalDeltaT = runTime.deltaT();

        for
        (
            subCycle<volScalarField> alphaSubCycle(alpha, nAlphaSubCycles);
            !(++alphaSubCycle).end();
        )
        {
            solveAlphas(cAlpha);
            rhoPhiSum += (runTime.deltaT()/totalDeltaT)*rhoPhi_;
        }

        rhoPhi_ = rhoPhiSum;
    }
    else
    {
        solveAlphas(cAlpha);
    }

    // Published segregated order: alpha transport first, then constitutive
    // stresses/properties, followed by momentum and pressure in the solver.
    correct();
    nu_ = mu()/rho();
}


void multiphaseMixture::correct()
{
    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        iter().correct();
    }
}


void multiphaseMixture::solveAlphas(const scalar cAlpha)
{
    const word alphaScheme("div(phi,alpha)");
    const word alpharScheme("div(phirb,alpha)");

    surfaceScalarField phic(mag(phi_/mesh_.magSf()));
    phic = min(cAlpha*phic, max(phic));

    PtrList<surfaceScalarField> alphaPhiCorrs(phases_.size());
    label phasei = 0;

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        phase& alpha = iter();

        alphaPhiCorrs.set
        (
            phasei,
            new surfaceScalarField
            (
                "phi" + alpha.name() + "Corr",
                fvc::flux(phi_, alpha, alphaScheme)
            )
        );

        surfaceScalarField& alphaPhiCorr = alphaPhiCorrs[phasei];

        const surfaceScalarField phir
        (
            "phir." + alpha.name(),
            phic*phaseNormalFlux(alpha)
        );

        forAllIter(PtrDictionary<phase>, phases_, iter2)
        {
            phase& alpha2 = iter2();

            if (&alpha2 == &alpha)
            {
                continue;
            }

            alphaPhiCorr += fvc::flux
            (
                -fvc::flux(-phir, alpha2, alpharScheme),
                alpha,
                alpharScheme
            );
        }

        MULES::limit
        (
            1.0/mesh_.time().deltaT().value(),
            geometricOneField(),
            alpha,
            phi_,
            alphaPhiCorr,
            zeroField(),
            zeroField(),
            oneField(),
            zeroField(),
            true
        );

        ++phasei;
    }

    MULES::limitSum(alphaPhiCorrs);

    rhoPhi_ = dimensionedScalar(dimensionSet(1, 0, -1, 0, 0), 0);

    volScalarField sumAlpha
    (
        IOobject
        (
            "sumAlpha",
            mesh_.time().timeName(),
            mesh_,
            IOobject::NO_READ,
            IOobject::NO_WRITE
        ),
        mesh_,
        dimensionedScalar(dimless, 0)
    );

    phasei = 0;

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        phase& alpha = iter();
        surfaceScalarField& alphaPhi = alphaPhiCorrs[phasei];

        alphaPhi += upwind<scalar>(mesh_, phi_).flux(alpha);

        MULES::explicitSolve
        (
            geometricOneField(),
            alpha,
            alphaPhi
        );

        rhoPhi_ += alphaPhi*alpha.rho();

        Info<< alpha.name() << " volume fraction, average, min, max = "
            << alpha.weightedAverage(mesh_.V()).value() << ' '
            << min(alpha).value() << ' '
            << max(alpha).value() << endl;

        sumAlpha += alpha;
        ++phasei;
    }

    Info<< "Phase-sum volume fraction, average, min, max = "
        << sumAlpha.weightedAverage(mesh_.V()).value() << ' '
        << min(sumAlpha).value() << ' '
        << max(sumAlpha).value() << endl;

    // Retain the OpenFOAM-7 multiphaseInterFoam drift correction.
    const volScalarField sumCorr(1.0 - sumAlpha);

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        phase& alpha = iter();
        alpha += alpha*sumCorr;
    }

    calcAlphas();
}


bool multiphaseMixture::read()
{
    if (!transportModel::read())
    {
        return false;
    }

    PtrList<entry> phaseData(lookup("phases"));

    if (phaseData.size() != phases_.size())
    {
        FatalErrorInFunction
            << "Changing the number of phases while the solver is running is "
            << "not supported."
            << exit(FatalError);
    }

    bool readOK = true;
    label phasei = 0;

    forAllIter(PtrDictionary<phase>, phases_, iter)
    {
        if (phaseData[phasei].keyword() != iter().name())
        {
            FatalErrorInFunction
                << "Changing phase names or ordering while the solver is "
                << "running is not supported." << nl
                << "Expected phase '" << iter().name() << "' but read '"
                << phaseData[phasei].keyword() << "'."
                << exit(FatalError);
        }

        readOK = iter().read(phaseData[phasei].dict()) && readOK;
        ++phasei;
    }

    sigmas_.clear();
    lookup("sigmas") >> sigmas_;

    surfaceTensionModel_ =
        lookupOrDefault<word>("surfaceTensionModel", "phaseSpecific");

    sigmasPh_.clear();
    if (found("sigmasPh"))
    {
        lookup("sigmasPh") >> sigmasPh_;
    }
    else if (surfaceTensionModel_ == "phaseSpecific")
    {
        decomposeSurfaceTensions();
    }

    surfaceTensionTolerance_ = lookupOrDefault<scalar>
    (
        "surfaceTensionConsistencyTolerance",
        1e-8
    );

    validateSurfaceTensions();
    nu_ = mu()/rho();

    return readOK;
}

} // End namespace Foam

// ************************************************************************* //
